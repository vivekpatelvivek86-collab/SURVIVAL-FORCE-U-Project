using System.Collections.Generic;
using UnityEngine;

namespace SurvivalForce
{
    /// <summary>Small prefab pool for repeated bullet impacts, shell casings and temporary effects.</summary>
    public sealed class SceneObjectPool : MonoBehaviour
    {
        [SerializeField] GameObject prefab;
        [SerializeField, Min(0)] int prewarm = 8;
        [SerializeField, Min(1)] int maxSize = 64;
        readonly Queue<GameObject> available = new Queue<GameObject>();
        int created;
        void Awake() { for (int i = 0; i < prewarm; i++) { GameObject item = Create(); if (item) Release(item); } }
        GameObject Create()
        {
            if (!prefab || created >= maxSize) return null;
            GameObject item = Instantiate(prefab, transform); item.SetActive(false); created++;
            PooledObject marker = item.GetComponent<PooledObject>(); if (!marker) marker = item.AddComponent<PooledObject>(); marker.Owner = this;
            return item;
        }
        public GameObject Get(Vector3 position, Quaternion rotation)
        {
            GameObject item = null;
            while (available.Count > 0 && !item) item = available.Dequeue();
            if (!item) item = Create();
            if (!item) return null;
            item.transform.SetPositionAndRotation(position, rotation); item.SetActive(true); return item;
        }
        public void Release(GameObject item)
        {
            if (!item) return;
            item.SetActive(false); item.transform.SetParent(transform, false);
            if (available.Count >= maxSize) { Destroy(item); created = Mathf.Max(0, created - 1); return; }
            available.Enqueue(item);
        }
        public void ClearPool() { while (available.Count > 0) { GameObject item = available.Dequeue(); if (item) Destroy(item); } created = 0; }
    }
    public sealed class PooledObject : MonoBehaviour
    {
        public SceneObjectPool Owner;
        public void Release() { if (Owner) Owner.Release(gameObject); else Destroy(gameObject); }
    }
}
