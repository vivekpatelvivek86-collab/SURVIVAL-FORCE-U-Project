using System.Collections.Generic;
using UnityEngine;

namespace SurvivalForce
{
    /// <summary>Optional low-cost runtime diagnostics for profiling the offline prototype.</summary>
    public sealed class RuntimeDiagnostics : MonoBehaviour
    {
        [SerializeField] bool visible;
        [SerializeField, Min(.1f)] float sampleInterval = .5f;
        readonly Queue<float> frameTimes = new Queue<float>();
        float nextSample;
        float averageFps;
        int lastFrameCount;
        float lastSampleTime;
        public float AverageFps => averageFps;
        public int ActiveObjects { get; private set; }
        void Update()
        {
            if (Time.unscaledTime < nextSample) return;
            nextSample = Time.unscaledTime + sampleInterval;
            float dt = Time.unscaledDeltaTime;
            if (dt > 0) frameTimes.Enqueue(dt);
            while (frameTimes.Count > 30) frameTimes.Dequeue();
            float total = 0; foreach (float t in frameTimes) total += t;
            averageFps = total > 0 ? frameTimes.Count / total : 0;
            ActiveObjects = FindObjectsOfType<GameObject>().Length;
            lastFrameCount = Time.frameCount; lastSampleTime = Time.unscaledTime;
        }
        void OnGUI()
        {
            if (!visible) return;
            GUI.Box(new Rect(10, 10, 220, 86), "SURVIVAL FORCE DIAGNOSTICS");
            GUI.Label(new Rect(20, 34, 200, 20), "FPS: " + averageFps.ToString("0"));
            GUI.Label(new Rect(20, 52, 200, 20), "Scene objects: " + ActiveObjects);
            GUI.Label(new Rect(20, 70, 200, 20), "Frame: " + lastFrameCount + " / " + lastSampleTime.ToString("0.0") + "s");
        }
    }
}
