using UnityEngine;

namespace SurvivalForce
{
    /// <summary>Reusable perception checks for bots: distance, field of view and occlusion.</summary>
    public sealed class BotPerception : MonoBehaviour
    {
        [SerializeField, Min(1)] float viewDistance = 45f;
        [SerializeField, Range(10, 180)] float fieldOfView = 110f;
        [SerializeField] LayerMask obstructionMask = ~0;
        [SerializeField] Transform eye;
        public Transform CurrentTarget { get; private set; }
        public float LastSeenTime { get; private set; } = -999f;
        public Vector3 LastKnownPosition { get; private set; }
        public bool CanSee(Transform target)
        {
            if (!target) return false;
            Vector3 origin = eye ? eye.position : transform.position + Vector3.up * 1.5f;
            Vector3 point = target.position + Vector3.up;
            Vector3 delta = point - origin;
            if (delta.sqrMagnitude > viewDistance * viewDistance) return false;
            if (Vector3.Angle(transform.forward, delta) > fieldOfView * .5f) return false;
            if (Physics.Raycast(origin, delta.normalized, out RaycastHit hit, delta.magnitude, obstructionMask, QueryTriggerInteraction.Ignore))
                if (hit.transform != target && !hit.transform.IsChildOf(target)) return false;
            return true;
        }
        public Transform FindBestTarget(Transform[] candidates)
        {
            Transform best = null; float bestScore = float.MaxValue;
            if (candidates == null) return null;
            for (int i = 0; i < candidates.Length; i++)
            {
                Transform candidate = candidates[i];
                if (!candidate || candidate == transform || !CanSee(candidate)) continue;
                float score = (candidate.position - transform.position).sqrMagnitude;
                if (score >= bestScore) continue;
                best = candidate; bestScore = score;
            }
            if (best) { CurrentTarget = best; LastKnownPosition = best.position; LastSeenTime = Time.time; }
            return best;
        }
        public bool HasRecentContact(float memorySeconds) => Time.time - LastSeenTime <= Mathf.Max(0, memorySeconds);
        public void ClearTarget() { CurrentTarget = null; }
    }
}
