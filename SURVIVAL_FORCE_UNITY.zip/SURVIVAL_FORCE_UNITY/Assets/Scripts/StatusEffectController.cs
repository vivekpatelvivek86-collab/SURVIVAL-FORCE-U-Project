using System;
using System.Collections.Generic;
using UnityEngine;

namespace SurvivalForce
{
    public enum StatusEffectType { HealOverTime, DamageOverTime, SpeedBoost, Slow, DamageReduction }
    [Serializable]
    public class StatusEffect
    {
        public StatusEffectType Type;
        public float RemainingSeconds;
        public float Magnitude;
        public string SourceId;
    }
    /// <summary>Small timed status effect container. Effects are intentionally local/offline.</summary>
    public sealed class StatusEffectController : MonoBehaviour
    {
        [SerializeField] List<StatusEffect> effects = new List<StatusEffect>();
        PlayerVitals vitals;
        public IReadOnlyList<StatusEffect> Effects => effects;
        public event Action<StatusEffectType, bool> EffectChanged;
        void Awake() { vitals = GetComponent<PlayerVitals>(); }
        void Update()
        {
            float dt = Time.deltaTime;
            for (int i = effects.Count - 1; i >= 0; i--)
            {
                StatusEffect effect = effects[i];
                effect.RemainingSeconds -= dt;
                if (effect.Type == StatusEffectType.HealOverTime && vitals) vitals.Heal(effect.Magnitude * dt);
                if (effect.Type == StatusEffectType.DamageOverTime && vitals) vitals.Damage(effect.Magnitude * dt);
                if (effect.RemainingSeconds > 0) continue;
                effects.RemoveAt(i); EffectChanged?.Invoke(effect.Type, false);
            }
        }
        public void Apply(StatusEffectType type, float seconds, float magnitude, string sourceId = "")
        {
            if (seconds <= 0 || magnitude < 0) return;
            for (int i = effects.Count - 1; i >= 0; i--)
                if (effects[i].Type == type && effects[i].SourceId == sourceId) effects.RemoveAt(i);
            effects.Add(new StatusEffect { Type = type, RemainingSeconds = seconds, Magnitude = magnitude, SourceId = sourceId });
            EffectChanged?.Invoke(type, true);
        }
        public float GetMultiplier(StatusEffectType type)
        {
            float value = 1f;
            for (int i = 0; i < effects.Count; i++)
                if (effects[i].Type == type) value *= Mathf.Max(0, effects[i].Magnitude);
            return value;
        }
        public bool Has(StatusEffectType type) { for (int i = 0; i < effects.Count; i++) if (effects[i].Type == type) return true; return false; }
        public void ClearAll() { for (int i = 0; i < effects.Count; i++) EffectChanged?.Invoke(effects[i].Type, false); effects.Clear(); }
    }
}
