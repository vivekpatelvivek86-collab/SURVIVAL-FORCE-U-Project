using UnityEngine;

namespace SurvivalForce
{
    // Keeps world-space POI names readable from the active gameplay camera.
    public class LocationLabelBillboard : MonoBehaviour
    {
        Camera targetCamera;
        void LateUpdate()
        {
            if (!targetCamera) targetCamera = Camera.main;
            if (!targetCamera) return;
            transform.rotation = Quaternion.LookRotation(transform.position - targetCamera.transform.position);
        }
    }
}
