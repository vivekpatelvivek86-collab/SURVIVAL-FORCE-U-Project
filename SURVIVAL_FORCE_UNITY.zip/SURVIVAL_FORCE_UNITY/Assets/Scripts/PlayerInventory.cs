using System;
using UnityEngine;

namespace SurvivalForce
{
    public enum InventoryItemKind { Ammo, Medkit, Armor, AssaultAmmo, SmgAmmo, MarksmanAmmo }

    /// <summary>Small, save-ready local inventory model for the offline prototype.</summary>
    [Serializable]
    public class InventoryStack
    {
        public InventoryItemKind Kind;
        public int Count;
        public InventoryStack(InventoryItemKind kind, int count) { Kind = kind; Count = count; }
    }

    public class PlayerInventory : MonoBehaviour
    {
        public const int DefaultCapacity = 12;
        public int Capacity = DefaultCapacity;
        public int Medkits { get; private set; }
        public int ArmorPoints { get; private set; }
        public int UsedSlots { get { return (Medkits > 0 ? 1 : 0) + (ArmorPoints > 0 ? 1 : 0) + (GetComponent<PlayerVitals>() && GetComponent<PlayerVitals>().ReserveAmmo > 0 ? 1 : 0); } }
        public event Action Changed;

        void Awake()
        {
            Medkits = Mathf.Clamp(PlayerPrefs.GetInt("SF_MEDKITS", 1), 0, 9);
            ArmorPoints = Mathf.Clamp(PlayerPrefs.GetInt("SF_ARMOR", 0), 0, 100);
            var vitals = GetComponent<PlayerVitals>(); if (vitals) vitals.SetArmor(ArmorPoints);
        }

        public bool AddMedkits(int amount)
        {
            if (amount <= 0 || UsedSlots >= Capacity) return false;
            Medkits = Mathf.Clamp(Medkits + amount, 0, 9);
            Save(); return true;
        }

        public bool AddArmor(int amount)
        {
            if (amount <= 0 || UsedSlots >= Capacity) return false;
            ArmorPoints = Mathf.Clamp(ArmorPoints + amount, 0, 100);
            var vitals = GetComponent<PlayerVitals>();
            if (vitals) vitals.SetArmor(ArmorPoints);
            Save(); return true;
        }

        public bool UseMedkit()
        {
            var vitals = GetComponent<PlayerVitals>();
            if (!vitals || Medkits <= 0 || vitals.Health >= vitals.MaxHealth) return false;
            Medkits--; vitals.Heal(75f); Save(); return true;
        }

        public void SyncArmor(int value)
        {
            ArmorPoints = Mathf.Clamp(value, 0, 100);
            Save();
        }

        void Save()
        {
            PlayerPrefs.SetInt("SF_MEDKITS", Medkits);
            PlayerPrefs.SetInt("SF_ARMOR", ArmorPoints);
            PlayerPrefs.Save();
            if (Changed != null) Changed();
        }
    }
}
