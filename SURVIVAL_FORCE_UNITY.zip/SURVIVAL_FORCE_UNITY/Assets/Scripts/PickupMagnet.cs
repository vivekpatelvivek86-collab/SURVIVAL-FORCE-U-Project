using UnityEngine;

namespace SurvivalForce
{
    /// <summary>Optional pickup attraction for nearby loot. Disabled by default for classic-style feel.</summary>
    public sealed class PickupMagnet : MonoBehaviour
    {
        [SerializeField] Transform target;
        [SerializeField, Min(0)] float radius = 1.25f;
        [SerializeField, Min(0)] float pullSpeed = 4f;
        [SerializeField] bool enabledAtStart;
        bool active;
        void Awake() { active = enabledAtStart; }
        void Update()
        {
            if (!active || !target) return;
            Vector3 delta = target.position - transform.position;
            if (delta.sqrMagnitude > radius * radius) return;
            transform.position = Vector3.MoveTowards(transform.position, target.position, pullSpeed * Time.deltaTime);
        }
        public void SetTarget(Transform value) { target = value; }
        public void SetActive(bool value) { active = value; }
    }
}
