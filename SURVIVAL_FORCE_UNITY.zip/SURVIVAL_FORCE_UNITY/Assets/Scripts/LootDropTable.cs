using System;
using UnityEngine;

namespace SurvivalForce
{
    [Serializable]
    public struct LootDropEntry
    {
        public string Id;
        public GameObject Prefab;
        [Min(0)] public float Weight;
        [Min(1)] public int MinCount;
        [Min(1)] public int MaxCount;
    }

    /// <summary>Weighted loot selection; empty or zero-weight tables fail safely.</summary>
    public sealed class LootDropTable : MonoBehaviour
    {
        [SerializeField] LootDropEntry[] entries;
        public bool TryRoll(out LootDropEntry selected, out int count)
        {
            selected = default; count = 0;
            if (entries == null || entries.Length == 0) return false;
            float total = 0;
            for (int i = 0; i < entries.Length; i++) total += Mathf.Max(0, entries[i].Weight);
            if (total <= 0) return false;
            float roll = UnityEngine.Random.value * total;
            for (int i = 0; i < entries.Length; i++)
            {
                roll -= Mathf.Max(0, entries[i].Weight);
                if (roll > 0) continue;
                selected = entries[i];
                count = UnityEngine.Random.Range(Mathf.Max(1, selected.MinCount), Mathf.Max(selected.MinCount, selected.MaxCount) + 1);
                return true;
            }
            return false;
        }
        public bool TrySpawn(Vector3 position, Quaternion rotation, out GameObject spawned)
        {
            spawned = null;
            if (!TryRoll(out LootDropEntry entry, out int count) || !entry.Prefab) return false;
            spawned = Instantiate(entry.Prefab, position, rotation);
            LootPickup pickup = spawned.GetComponent<LootPickup>();
            if (pickup) pickup.Amount = count;
            return true;
        }
    }
}
