using System.Collections.Generic;
using UnityEngine;

namespace SurvivalForce
{
    /// <summary>Deterministic spawn-point selector with spacing and occupancy checks.</summary>
    public sealed class SpawnDirector : MonoBehaviour
    {
        [SerializeField] Transform[] spawnPoints;
        [SerializeField, Min(0)] float minimumSpacing = 8f;
        readonly List<Vector3> used = new List<Vector3>();
        public void ResetRound() { used.Clear(); }
        public bool TryGetSpawn(out Vector3 position, out Quaternion rotation)
        {
            position = transform.position; rotation = transform.rotation;
            if (spawnPoints == null || spawnPoints.Length == 0) return false;
            int best = -1; float bestScore = float.MinValue;
            for (int i = 0; i < spawnPoints.Length; i++)
            {
                Transform point = spawnPoints[i]; if (!point) continue;
                float score = float.MaxValue;
                for (int j = 0; j < used.Count; j++) score = Mathf.Min(score, Vector3.Distance(point.position, used[j]));
                if (used.Count == 0) score = Random.value;
                if (score > bestScore) { bestScore = score; best = i; }
            }
            if (best < 0) return false;
            Transform selected = spawnPoints[best];
            if (used.Count > 0 && bestScore < minimumSpacing) return false;
            position = selected.position; rotation = selected.rotation; used.Add(position); return true;
        }
    }
}
