using UnityEngine;

namespace SurvivalForce
{
    /// <summary>Provides zone state for HUD/audio listeners without coupling to a specific UI.</summary>
    public sealed class SafeZoneWarning : MonoBehaviour
    {
        [SerializeField] SafeZoneController zone;
        [SerializeField] Transform trackedActor;
        [SerializeField, Min(0)] float warningDistance = 8f;
        public bool OutsideZone { get; private set; }
        public bool NearBoundary { get; private set; }
        public float TimeOutside { get; private set; }
        public event System.Action<bool> OutsideChanged;
        bool previousOutside;
        void Update()
        {
            if (!zone || !trackedActor) return;
            // SafeZoneController exposes its center/radius through public properties in this project.
            float distance = Vector3.Distance(new Vector3(trackedActor.position.x, 0, trackedActor.position.z), new Vector3(SafeZoneController.CurrentCenter.x, 0, SafeZoneController.CurrentCenter.z));
            float radius = SafeZoneController.CurrentRadius;
            OutsideZone = distance > radius;
            NearBoundary = !OutsideZone && distance > radius - warningDistance;
            if (OutsideZone) TimeOutside += Time.deltaTime; else TimeOutside = 0;
            if (previousOutside != OutsideZone) { previousOutside = OutsideZone; OutsideChanged?.Invoke(OutsideZone); }
        }
        public void Track(Transform actor) { trackedActor = actor; }
    }
}
