using UnityEngine;

namespace SurvivalForce
{
    public struct MatchEndDecision
    {
        public bool ShouldEnd;
        public bool PlayerWon;
        public int AliveCount;
        public string Reason;
    }
    /// <summary>Pure match-end rules separated from UI and reward presentation.</summary>
    public static class MatchEndEvaluator
    {
        public static MatchEndDecision Evaluate(bool playerAlive, int botsAlive, bool timerExpired, bool objectiveComplete = false)
        {
            int alive = Mathf.Max(0, botsAlive) + (playerAlive ? 1 : 0);
            if (!playerAlive) return new MatchEndDecision { ShouldEnd = true, PlayerWon = false, AliveCount = alive, Reason = "player_eliminated" };
            if (botsAlive <= 0) return new MatchEndDecision { ShouldEnd = true, PlayerWon = true, AliveCount = alive, Reason = "last_survivor" };
            if (objectiveComplete) return new MatchEndDecision { ShouldEnd = true, PlayerWon = true, AliveCount = alive, Reason = "objective_complete" };
            if (timerExpired) return new MatchEndDecision { ShouldEnd = true, PlayerWon = false, AliveCount = alive, Reason = "time_limit" };
            return new MatchEndDecision { ShouldEnd = false, PlayerWon = false, AliveCount = alive, Reason = "in_progress" };
        }
    }
}
