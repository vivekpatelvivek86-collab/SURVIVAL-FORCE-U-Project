using System;
using UnityEngine;

namespace SurvivalForce
{
    /// <summary>Typed, local-only event hub. Avoids hard references between independent gameplay systems.</summary>
    public static class GameEventBus
    {
        public static event Action<Transform, Transform, float> DamageApplied;
        public static event Action<Transform, Transform> ActorEliminated;
        public static event Action<string, int> ItemCollected;
        public static event Action<int> MatchPhaseChanged;
        public static event Action<string> ObjectiveCompleted;
        public static event Action<string> Notice;

        public static void RaiseDamage(Transform source, Transform target, float amount) { DamageApplied?.Invoke(source, target, amount); }
        public static void RaiseElimination(Transform source, Transform target) { ActorEliminated?.Invoke(source, target); }
        public static void RaiseItemCollected(string id, int count) { ItemCollected?.Invoke(id, count); }
        public static void RaisePhase(int phase) { MatchPhaseChanged?.Invoke(phase); }
        public static void RaiseObjective(string id) { ObjectiveCompleted?.Invoke(id); }
        public static void RaiseNotice(string message) { Notice?.Invoke(message); }
    }
}
