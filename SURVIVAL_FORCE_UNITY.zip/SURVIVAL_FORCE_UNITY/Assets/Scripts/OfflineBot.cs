using UnityEngine;
namespace SurvivalForce
{
    [RequireComponent(typeof(CharacterController))]
    public class OfflineBot : MonoBehaviour
    {
        public Transform Target;
        [Range(.5f, 1.5f)] public float Skill = 1f;
        public float Speed = 3.4f, NoticeRange = 75f, FireRange = 24f, DamagePerShot = 7f, FireDelay = 1.05f;
        public float StrafeChangeSeconds = 2.4f;
        CharacterController controller;
        float nextShot, fireAnimUntil, nextWander, nextStrafeChange, lastSeenAt;
        Vector3 wanderDirection;
        int strafeSign = 1;
        bool dead, lootDropped;
        public bool IsDead { get { return dead; } }
        public bool IsAiming { get; private set; }
        public bool IsFiring { get; private set; }

        void Awake() { controller = GetComponent<CharacterController>(); PickWander(); }

        void Update()
        {
            IsFiring = Time.time < fireAnimUntil;
            if (dead || !Target || !controller) { IsAiming = false; return; }
            Vector3 toTarget = Target.position - transform.position; toTarget.y = 0f;
            float distance = toTarget.magnitude;
            bool seesTarget = distance <= NoticeRange && HasLineOfSight();
            if (seesTarget) lastSeenAt = Time.time;

            Vector3 moveDirection;
            if (seesTarget)
            {
                IsAiming = true;
                Vector3 forward = distance > .01f ? toTarget.normalized : transform.forward;
                transform.rotation = Quaternion.Slerp(transform.rotation, Quaternion.LookRotation(forward), Time.deltaTime * (4.5f + Skill * 2f));
                if (Time.time >= nextStrafeChange) { strafeSign = Random.value > .5f ? 1 : -1; nextStrafeChange = Time.time + StrafeChangeSeconds * Random.Range(.65f, 1.4f); }
                Vector3 lateral = Vector3.Cross(Vector3.up, forward) * strafeSign;
                if (distance > FireRange * 1.1f) moveDirection = forward + lateral * .25f;
                else if (distance < FireRange * .48f) moveDirection = -forward + lateral * .35f;
                else moveDirection = lateral * .45f;
                if (distance <= FireRange && Time.time >= nextShot) ShootAtPlayer();
            }
            else if (Time.time - lastSeenAt < 4f)
            {
                IsAiming = true;
                Vector3 pursuit = Target.position - transform.position; pursuit.y = 0f;
                moveDirection = pursuit.sqrMagnitude > 2f ? pursuit.normalized : Vector3.zero;
            }
            else
            {
                IsAiming = false;
                if (Time.time > nextWander) PickWander();
                moveDirection = wanderDirection;
                if (SafeZoneController.CurrentRadius > 0f)
                {
                    Vector3 fromCenter = transform.position - SafeZoneController.CurrentCenter; fromCenter.y = 0f;
                    if (fromCenter.magnitude > SafeZoneController.CurrentRadius * .82f) moveDirection = -fromCenter.normalized;
                }
            }
            if (moveDirection.sqrMagnitude > 1f) moveDirection.Normalize();
            controller.SimpleMove(moveDirection * Speed * Skill);
        }

        bool HasLineOfSight()
        {
            Vector3 from = transform.position + Vector3.up * 1.25f;
            Vector3 to = Target.position + Vector3.up * 1.1f;
            Vector3 direction = to - from;
            if (!Physics.Raycast(from, direction.normalized, out RaycastHit hit, direction.magnitude, ~0, QueryTriggerInteraction.Ignore)) return true;
            return hit.transform == Target || hit.transform.IsChildOf(Target);
        }

        void ShootAtPlayer()
        {
            nextShot = Time.time + FireDelay / Mathf.Max(.5f, Skill);
            fireAnimUntil = Time.time + .18f; IsFiring = true;
            Vector3 from = transform.position + Vector3.up * 1.25f;
            Vector3 to = Target.position + Vector3.up * 1.1f;
            if (!Physics.Linecast(from, to, out RaycastHit hit, ~0, QueryTriggerInteraction.Ignore) || hit.transform == Target || hit.transform.IsChildOf(Target))
            {
                var vitals = Target.GetComponent<PlayerVitals>();
                if (vitals) vitals.Damage(DamagePerShot * Skill);
            }
        }

        void PickWander()
        {
            wanderDirection = new Vector3(Random.Range(-1f, 1f), 0f, Random.Range(-1f, 1f)).normalized;
            nextWander = Time.time + Random.Range(2f, 5f);
        }

        public void Kill()
        {
            if (dead) return;
            dead = true;
            if (SurvivalForceBootstrap.Instance)
            {
                SurvivalForceBootstrap.Instance.AddKill();
                if (!lootDropped) { lootDropped = true; SurvivalForceBootstrap.Instance.SpawnBotLoot(transform.position); }
            }
            StartCoroutine(DeathFall());
        }

        System.Collections.IEnumerator DeathFall()
        {
            if (controller) controller.enabled = false;
            Quaternion start = transform.rotation;
            Quaternion finish = start * Quaternion.Euler(0f, 0f, 78f);
            float elapsed = 0f;
            while (elapsed < .55f)
            {
                elapsed += Time.deltaTime;
                transform.rotation = Quaternion.Slerp(start, finish, Mathf.Clamp01(elapsed / .55f));
                yield return null;
            }
            yield return new WaitForSeconds(.75f);
            Destroy(gameObject);
        }
    }
}
