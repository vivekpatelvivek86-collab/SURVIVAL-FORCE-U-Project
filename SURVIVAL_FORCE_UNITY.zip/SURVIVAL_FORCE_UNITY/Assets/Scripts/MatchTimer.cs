using System;
using UnityEngine;

namespace SurvivalForce
{
    public sealed class MatchTimer : MonoBehaviour
    {
        [SerializeField] bool countDown;
        [SerializeField, Min(0)] float initialSeconds = 900f;
        [SerializeField] bool startOnAwake = true;
        public float ElapsedSeconds { get; private set; }
        public float RemainingSeconds => Mathf.Max(0, initialSeconds - ElapsedSeconds);
        public bool Running { get; private set; }
        public event Action<float> Tick;
        public event Action Finished;
        bool finishedRaised;
        void Awake() { if (startOnAwake) StartTimer(); }
        void Update()
        {
            if (!Running) return;
            ElapsedSeconds += Time.deltaTime; Tick?.Invoke(countDown ? RemainingSeconds : ElapsedSeconds);
            if (countDown && RemainingSeconds <= 0 && !finishedRaised) { finishedRaised = true; Running = false; Finished?.Invoke(); }
        }
        public void StartTimer() { ElapsedSeconds = 0; finishedRaised = false; Running = true; }
        public void Pause() { Running = false; }
        public void Resume() { if (!finishedRaised) Running = true; }
        public void ResetTimer() { ElapsedSeconds = 0; finishedRaised = false; Running = false; }
    }
}
