using UnityEngine;

namespace SurvivalForce
{
    /// <summary>Small coordination helper for bots assigned the same squad identifier.</summary>
    public sealed class BotSquadBrain : MonoBehaviour
    {
        [SerializeField] string squadId = "offline_alpha";
        [SerializeField] float regroupRadius = 18f;
        [SerializeField] Transform rallyPoint;
        public string SquadId => squadId;
        public Transform RallyPoint => rallyPoint;
        public void SetRallyPoint(Transform value) { rallyPoint = value; }
        public bool ShouldRegroup(Transform member)
        {
            if (!member || !rallyPoint) return false;
            return Vector3.Distance(member.position, rallyPoint.position) > Mathf.Max(1f, regroupRadius);
        }
        public Vector3 GetRegroupDestination(Transform member)
        {
            if (!rallyPoint) return member ? member.position : transform.position;
            Vector2 offset = Random.insideUnitCircle * Mathf.Min(4f, regroupRadius * .25f);
            return rallyPoint.position + new Vector3(offset.x, 0, offset.y);
        }
    }
}
