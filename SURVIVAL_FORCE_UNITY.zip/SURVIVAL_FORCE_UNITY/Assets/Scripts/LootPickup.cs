using UnityEngine;
namespace SurvivalForce
{
    public enum LootKind { Ammo, Medkit, Armor, RifleAmmo, SmgAmmo, MarksmanAmmo }
    public class LootPickup : MonoBehaviour
    {
        public bool Healing; // Backward-compatible field used by older project scenes.
        public LootKind Kind = LootKind.Ammo;
        public int Amount = 30;
        bool collected;
        Vector3 startPosition;
        void Start() { startPosition = transform.position; }
        void Update()
        {
            transform.Rotate(0f, 65f * Time.deltaTime, 0f, Space.World);
            Vector3 p = transform.position; p.y = startPosition.y + Mathf.Sin(Time.time * 2f + startPosition.x) * .06f; transform.position = p;
        }
        public bool Collect(PlayerVitals player)
        {
            if (collected || !player) return false;
            bool accepted = true;
            PlayerInventory inventory = player.GetComponent<PlayerInventory>();
            if (Healing || Kind == LootKind.Medkit)
            {
                if (inventory) accepted = inventory.AddMedkits(Mathf.Max(1, Amount / 1));
                else player.Heal(45f);
                if (accepted && inventory && player.Health < player.MaxHealth * .65f) inventory.UseMedkit();
            }
            else if (Kind == LootKind.Armor)
            {
                if (inventory) accepted = inventory.AddArmor(Amount); else player.SetArmor(player.Armor + Amount);
            }
            else player.AddAmmo(Amount);
            if (!accepted) return false;
            collected = true; Destroy(gameObject); return true;
        }
    }
}
