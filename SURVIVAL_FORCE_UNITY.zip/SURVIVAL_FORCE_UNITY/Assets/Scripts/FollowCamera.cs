using UnityEngine;

namespace SurvivalForce
{
    public class FollowCamera : MonoBehaviour
    {
        public Transform target;
        public Vector3 offset = new Vector3(0f, 3.2f, -6.5f);
        public float smooth = 12f;
        public float pitch = 10f;
        public float collisionRadius = .22f;
        public float collisionPadding = .12f;
        public float minDistance = 1.1f;

        void LateUpdate()
        {
            if (!target) return;
            Quaternion orbit = Quaternion.Euler(pitch, target.eulerAngles.y, 0f);
            Vector3 lookPoint = target.position + Vector3.up * 1.25f;
            Vector3 desired = target.position + orbit * offset;
            Vector3 fromLook = desired - lookPoint;
            float desiredDistance = fromLook.magnitude;
            if (desiredDistance > .001f)
            {
                Vector3 direction = fromLook / desiredDistance;
                RaycastHit[] hits = Physics.SphereCastAll(lookPoint, collisionRadius, direction, desiredDistance, ~0, QueryTriggerInteraction.Ignore);
                float allowedDistance = desiredDistance;
                for (int i = 0; i < hits.Length; i++)
                {
                    Transform hitTransform = hits[i].collider ? hits[i].collider.transform : null;
                    if (!hitTransform || hitTransform == target || hitTransform.IsChildOf(target)) continue;
                    allowedDistance = Mathf.Min(allowedDistance, Mathf.Max(minDistance, hits[i].distance - collisionPadding));
                }
                desired = lookPoint + direction * allowedDistance;
            }
            transform.position = Vector3.Lerp(transform.position, desired, Time.deltaTime * smooth);
            Quaternion look = Quaternion.LookRotation(lookPoint - transform.position, Vector3.up);
            transform.rotation = Quaternion.Slerp(transform.rotation, look, Time.deltaTime * smooth);
        }
    }
}
