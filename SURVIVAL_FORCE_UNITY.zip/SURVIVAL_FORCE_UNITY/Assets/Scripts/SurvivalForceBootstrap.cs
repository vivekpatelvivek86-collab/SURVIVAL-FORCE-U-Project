using System;
using UnityEngine;
using UnityEngine.UI;
using UnityEngine.EventSystems;
using System.Collections.Generic;

namespace SurvivalForce
{
    // Builds an original, asset-free playable prototype at runtime. No Garena assets are included.
    public class SurvivalForceBootstrap : MonoBehaviour
    {
        public static SurvivalForceBootstrap Instance;
        public Transform Player { get; private set; }
        public PlayerVitals Vitals { get; private set; }
        public int Kills { get; private set; }
        public int AliveBots { get { return FindObjectsOfType<OfflineBot>().Length; } }
        public string MapName = "Bermuda";
        readonly List<Transform> spawnPoints = new List<Transform>();
        Text hudText, hintText;
        float matchTime;
        bool gameOver;
        bool gameStarted;
        string profileName = "";
        string loginMessage = "Create a local profile or continue as guest.";
        int selectedLoginMap;
        int lobbyPage;
        int localCoins;
        int ownedOutfitMask;
        string lobbyNotice = "Welcome back, survivor. Your profile is stored on this device.";
        string popupTitle = "OFFLINE FEATURE";
        string popupBody = "This feature is not connected to an online service.";
        bool showLobbyPopup;
        float splashTimer;
        float loadingTimer;
        float loadingDuration = 2.8f;
        FrontendStage loadingTarget = FrontendStage.Login;
        string loadingMessage = "PREPARING GAME FILES";
        enum FrontendStage { Splash, Loading, Login, Lobby }
        FrontendStage frontendStage = FrontendStage.Splash;
        GUIStyle loginTitleStyle, loginBodyStyle, loginButtonStyle, loginFieldStyle;
        Camera lobbyPreviewCamera;
        Texture2D brandingLogo;
        AudioSource lobbyMusicSource;
        AudioClip lobbyMusicClip;
        bool lobbyMusicEnabled = true;
        float lobbyMusicVolume = 0.55f;
        int settingsCategory;
        float lookSensitivity = 2.1f;
        float redDotSensitivity = 1.8f;
        float scope2xSensitivity = 1.6f;
        float scope4xSensitivity = 1.35f;
        float sniperSensitivity = 0.9f;
        bool highFrameRate = true;
        bool shadowsEnabled = true;
        bool autoPickupEnabled = false;
        int graphicsPreset = 1;
        string[] settingsCategories = { "BASIC", "SENS", "CONTROLS", "PICKUP", "SOUND", "GRAPHICS" };
        RenderTexture lobbyPreviewTexture;
        Transform lobbyPreviewRoot;
        int selectedOutfit;
        int selectedWeapon;
        string[] outfitNames = { "FIELD RECRUIT", "DESERT SCOUT", "NIGHT OPS", "URBAN RAIDER" };
        string[] weaponNames = { "ASSAULT RIFLE", "SMG", "MARKSMAN RIFLE", "SHOTGUN", "SNIPER RIFLE" };

        [RuntimeInitializeOnLoadMethod(RuntimeInitializeLoadType.AfterSceneLoad)]
        static void AutoStart()
        {
            if (FindObjectOfType<SurvivalForceBootstrap>() == null)
                new GameObject("SURVIVAL FORCE Runtime Bootstrap").AddComponent<SurvivalForceBootstrap>();
        }

        void Awake()
        {
            if (Instance != null && Instance != this) { Destroy(gameObject); return; }
            Instance = this;
            brandingLogo = Resources.Load<Texture2D>("Branding/SURVIVAL_FORCE_Logo");
            lobbyMusicClip = Resources.Load<AudioClip>("Audio/SURVIVAL_FORCE_Lobby_Ringtone");
            lobbyMusicEnabled = PlayerPrefs.GetInt("SF_LOBBY_MUSIC", 1) == 1;
            lobbyMusicVolume = PlayerPrefs.GetFloat("SF_LOBBY_MUSIC_VOLUME", 0.55f);
            lookSensitivity = PlayerPrefs.GetFloat("SF_SENS_GENERAL", 2.1f);
            redDotSensitivity = PlayerPrefs.GetFloat("SF_SENS_RED_DOT", 1.8f);
            scope2xSensitivity = PlayerPrefs.GetFloat("SF_SENS_2X", 1.6f);
            scope4xSensitivity = PlayerPrefs.GetFloat("SF_SENS_4X", 1.35f);
            sniperSensitivity = PlayerPrefs.GetFloat("SF_SENS_SNIPER", 0.9f);
            highFrameRate = PlayerPrefs.GetInt("SF_HIGH_FPS", 1) == 1;
            shadowsEnabled = PlayerPrefs.GetInt("SF_SHADOWS", 1) == 1;
            autoPickupEnabled = PlayerPrefs.GetInt("SF_AUTO_PICKUP", 0) == 1;
            graphicsPreset = Mathf.Clamp(PlayerPrefs.GetInt("SF_GRAPHICS_PRESET", 1), 0, 2);
            ApplyGraphicsSettings();
            lobbyMusicSource = gameObject.AddComponent<AudioSource>();
            lobbyMusicSource.playOnAwake = false; lobbyMusicSource.loop = true; lobbyMusicSource.volume = lobbyMusicVolume;
            lobbyMusicSource.clip = lobbyMusicClip;
            Application.targetFrameRate = highFrameRate ? 60 : 30;
            Screen.orientation = ScreenOrientation.LandscapeLeft;
            Screen.autorotateToPortrait = false; Screen.autorotateToPortraitUpsideDown = false;
            Screen.autorotateToLandscapeLeft = true; Screen.autorotateToLandscapeRight = true;
            MapName = PlayerPrefs.GetInt("SF_MAP", 0) == 1 ? "Purgatory" : "Bermuda";
            selectedOutfit = Mathf.Clamp(PlayerPrefs.GetInt("SF_OUTFIT", 0), 0, 3);
            localCoins = PlayerPrefs.GetInt("SF_LOCAL_COINS", 1200);
            ownedOutfitMask = PlayerPrefs.GetInt("SF_OWNED_OUTFITS", 1);
            // Preserve older local profiles that already had one of the original three outfits selected.
            ownedOutfitMask |= 1 << selectedOutfit;
            PlayerPrefs.SetInt("SF_OWNED_OUTFITS", ownedOutfitMask);
            PlayerPrefs.SetInt("SF_LOCAL_COINS", localCoins);
            PlayerPrefs.Save();
            selectedWeapon = Mathf.Clamp(PlayerPrefs.GetInt("SF_WEAPON", 0), 0, 4);
            profileName = PlayerPrefs.GetString("SF_PROFILE_NAME", "");
            selectedLoginMap = PlayerPrefs.GetInt("SF_MAP", 0);
            frontendStage = FrontendStage.Splash;
        }
        void BeginLoading(FrontendStage destination, string message, float duration = 2.8f)
        {
            loadingTarget = destination;
            loadingMessage = message;
            loadingDuration = Mathf.Max(.8f, duration);
            loadingTimer = 0f;
            frontendStage = FrontendStage.Loading;
        }
        void EnterLobby()
        {
            if (string.IsNullOrWhiteSpace(profileName)) { loginMessage = "Enter a player name first."; frontendStage = FrontendStage.Login; return; }
            profileName = profileName.Trim();
            PlayerPrefs.SetString("SF_PROFILE_NAME", profileName);
            PlayerPrefs.SetInt("SF_LOCAL_LOGIN_OK", 1);
            PlayerPrefs.SetInt("SF_MAP", selectedLoginMap);
            PlayerPrefs.Save();
            BeginLoading(FrontendStage.Lobby, "SAVING PROFILE  •  PREPARING LOBBY", 2.0f);
        }
        void StartMatch()
        {
            if (gameStarted) return;
            if (string.IsNullOrWhiteSpace(profileName)) profileName = "Guest_" + Random.Range(1000, 9999);
            profileName = profileName.Trim();
            PlayerPrefs.SetString("SF_PROFILE_NAME", profileName);
            PlayerPrefs.SetInt("SF_LOCAL_LOGIN_OK", 1);
            PlayerPrefs.SetInt("SF_MAP", selectedLoginMap);
            PlayerPrefs.Save();
            MapName = selectedLoginMap == 1 ? "Purgatory" : "Bermuda";
            PlayerPrefs.SetInt("SF_MATCHES", PlayerPrefs.GetInt("SF_MATCHES", 0) + 1);
            PlayerPrefs.Save();
            DestroyLobbyPreview();
            gameStarted = true;
            BuildWorld(); BuildPlayer(); BuildBots(22); BuildLoot(42); BuildZone(); BuildHud();
        }
        void Update()
        {
            if (!gameStarted)
            {
                UpdateLobbyMusic();
                if (frontendStage == FrontendStage.Lobby && lobbyPreviewRoot != null) lobbyPreviewRoot.Rotate(Vector3.up, 12f * Time.unscaledDeltaTime, Space.World);
                if (frontendStage == FrontendStage.Splash)
                {
                    splashTimer += Time.deltaTime;
                    if (splashTimer >= 2.2f)
                    {
                        bool hasSavedProfile = PlayerPrefs.GetInt("SF_LOCAL_LOGIN_OK", 0) == 1 && !string.IsNullOrWhiteSpace(PlayerPrefs.GetString("SF_PROFILE_NAME", ""));
                        if (hasSavedProfile)
                        {
                            profileName = PlayerPrefs.GetString("SF_PROFILE_NAME", "Survivor");
                            BeginLoading(FrontendStage.Lobby, "RESTORING SAVED PROFILE  •  LOADING LOBBY", 2.8f);
                        }
                        else BeginLoading(FrontendStage.Login, "CHECKING LOCAL GAME FILES", 2.4f);
                    }
                }
                else if (frontendStage == FrontendStage.Lobby && lobbyPreviewCamera == null) CreateLobbyPreview();
                else if (frontendStage == FrontendStage.Loading)
                {
                    loadingTimer += Time.deltaTime;
                    if (loadingTimer >= loadingDuration)
                    {
                        frontendStage = loadingTarget;
                        if (frontendStage == FrontendStage.Lobby) loginMessage = "Local profile ready. Offline mode enabled.";
                    }
                }
                return;
            }
            if (lobbyMusicSource != null && lobbyMusicSource.isPlaying) lobbyMusicSource.Stop();
            if (gameOver) return;
            matchTime += Time.deltaTime;
            if (Vitals != null && Vitals.Health <= 0 && !gameOver) { gameOver = true; int reward = MatchProgression.FinishMatch(false, Kills, matchTime); if(hintText) hintText.text = "ELIMINATED — +" + reward + " coins | press R to restart"; SaveBestKills(); }
            if (AliveBots == 0 && !gameOver) { gameOver = true; int reward = MatchProgression.FinishMatch(true, Kills, matchTime); if(hintText) hintText.text = "BOOYAH! +" + reward + " coins — press R to restart"; SaveBestKills(); }
            if (Input.GetKeyDown(KeyCode.R) && gameOver) UnityEngine.SceneManagement.SceneManager.LoadScene(UnityEngine.SceneManagement.SceneManager.GetActiveScene().buildIndex);
            if (Input.GetKeyDown(KeyCode.F1)) SwitchMap(0);
            if (Input.GetKeyDown(KeyCode.F2)) SwitchMap(1);
            if (hudText && Vitals) { var inv = Player ? Player.GetComponent<PlayerInventory>() : null; var gun = Player ? Player.GetComponent<PlayerShooter>() : null; hudText.text = "SURVIVAL FORCE  |  " + profileName + "  |  " + MapName + "\nHP " + Mathf.CeilToInt(Vitals.Health) + "  ARMOR " + Mathf.CeilToInt(Vitals.Armor) + "  AMMO " + Vitals.Ammo + "/" + Vitals.ReserveAmmo + "  KILLS " + Kills + "\n" + (gun ? gun.WeaponType.ToString() : "WEAPON") + "  MEDKITS " + (inv ? inv.Medkits : 0) + "  ALIVE " + (AliveBots+1) + "  TIME " + Mathf.FloorToInt(matchTime/60).ToString("00") + ":" + Mathf.FloorToInt(matchTime%60).ToString("00"); }
        }
        void SaveBestKills()
        {
            if (Kills > PlayerPrefs.GetInt("SF_BEST_KILLS", 0))
            {
                PlayerPrefs.SetInt("SF_BEST_KILLS", Kills);
                PlayerPrefs.Save();
            }
        }

        void OnGUI()
        {
            if (gameStarted) return;
            if (loginTitleStyle == null)
            {
                loginTitleStyle = new GUIStyle(GUI.skin.label); loginTitleStyle.alignment = TextAnchor.MiddleCenter; loginTitleStyle.fontSize = Mathf.Clamp(Screen.width / 22, 25, 54); loginTitleStyle.fontStyle = FontStyle.Bold; loginTitleStyle.normal.textColor = Color.white;
                loginBodyStyle = new GUIStyle(GUI.skin.label); loginBodyStyle.alignment = TextAnchor.MiddleCenter; loginBodyStyle.wordWrap = true; loginBodyStyle.fontSize = Mathf.Clamp(Screen.width / 70, 14, 22); loginBodyStyle.normal.textColor = new Color(.78f,.88f,.94f);
                loginButtonStyle = new GUIStyle(GUI.skin.button); loginButtonStyle.fontSize = Mathf.Clamp(Screen.width / 65, 16, 25); loginButtonStyle.fontStyle = FontStyle.Bold; loginButtonStyle.fixedHeight = Mathf.Clamp(Screen.height * .058f, 38, 60);
                loginFieldStyle = new GUIStyle(GUI.skin.textField); loginFieldStyle.fontSize = Mathf.Clamp(Screen.width / 70, 16, 24); loginFieldStyle.fixedHeight = Mathf.Clamp(Screen.height * .05f, 38, 56);
            }
            if (frontendStage == FrontendStage.Splash) { DrawSplash(); return; }
            if (frontendStage == FrontendStage.Loading) { DrawLoading(); return; }
            if (frontendStage == FrontendStage.Lobby) { DrawLobby(); return; }
            float panelW = Mathf.Min(Screen.width * .88f, 680f), panelH = Mathf.Min(Screen.height * .82f, 720f);
            Rect panel = new Rect((Screen.width-panelW)/2, (Screen.height-panelH)/2, panelW, panelH);
            GUI.color = new Color(.025f,.07f,.105f,.96f); GUI.Box(panel, GUIContent.none); GUI.color = Color.white;
            float x = panel.x + panelW*.09f, w = panelW*.82f, y = panel.y + panelH*.06f;
            GUI.Label(new Rect(x,y,w,panelH*.10f), "SURVIVAL FORCE", loginTitleStyle); y += panelH*.11f;
            GUI.Label(new Rect(x,y,w,panelH*.055f), "OFFLINE BATTLE ROYALE  •  CLASSIC ISLANDS", loginBodyStyle); y += panelH*.06f;
            GUI.Label(new Rect(x,y,w,panelH*.05f), "LOCAL PROFILE LOGIN", loginBodyStyle); y += panelH*.06f;
            GUI.Label(new Rect(x,y,w,panelH*.04f), "Player name", loginBodyStyle); y += panelH*.045f;
            profileName = GUI.TextField(new Rect(x,y,w,loginFieldStyle.fixedHeight), profileName, 20, loginFieldStyle); y += loginFieldStyle.fixedHeight + panelH*.018f;
            GUI.Label(new Rect(x,y,w,panelH*.04f), "Choose your battlefield", loginBodyStyle); y += panelH*.045f;
            float gap = 12f, bw = (w-gap)/2f;
            if (GUI.Button(new Rect(x,y,bw,loginButtonStyle.fixedHeight), selectedLoginMap==0 ? "✓  BERMUDA" : "BERMUDA", loginButtonStyle)) selectedLoginMap=0;
            if (GUI.Button(new Rect(x+bw+gap,y,bw,loginButtonStyle.fixedHeight), selectedLoginMap==1 ? "✓  PURGATORY" : "PURGATORY", loginButtonStyle)) selectedLoginMap=1;
            y += loginButtonStyle.fixedHeight + panelH*.025f;
            if (GUI.Button(new Rect(x,y,w,loginButtonStyle.fixedHeight), "CREATE / SIGN IN ON THIS DEVICE", loginButtonStyle))
            {
                if (string.IsNullOrWhiteSpace(profileName)) loginMessage = "Enter a player name first.";
                else { EnterLobby(); }
            }
            y += loginButtonStyle.fixedHeight + panelH*.02f;
            if (GUI.Button(new Rect(x,y,w,loginButtonStyle.fixedHeight), "CONTINUE AS GUEST", loginButtonStyle)) { profileName = "Guest_" + Random.Range(1000,9999); EnterLobby(); }
            y += loginButtonStyle.fixedHeight + panelH*.02f;
            GUI.Label(new Rect(x,y,w,panelH*.11f), loginMessage + "\nAfter your first sign-in, this device can restore your profile automatically. Offline local profile only; no password or online account is collected.", loginBodyStyle);
        }
        void UpdateLobbyMusic()
        {
            if (lobbyMusicSource == null) return;
            bool shouldPlay = !gameStarted && frontendStage == FrontendStage.Lobby && lobbyMusicEnabled && lobbyMusicClip != null;
            if (shouldPlay && !lobbyMusicSource.isPlaying) lobbyMusicSource.Play();
            else if (!shouldPlay && lobbyMusicSource.isPlaying) lobbyMusicSource.Stop();
        }

        void DrawSplash()
        {
            GUI.color = new Color(.018f,.028f,.045f,1f); GUI.DrawTexture(new Rect(0,0,Screen.width,Screen.height), Texture2D.whiteTexture); GUI.color = Color.white;
            // Original SURVIVAL FORCE identity: a bold emblem and cinematic colour bands, without Garena branding.
            GUI.color = new Color(.10f,.22f,.25f,.94f); GUI.DrawTexture(new Rect(0,Screen.height*.61f,Screen.width,Screen.height*.39f), Texture2D.whiteTexture); GUI.color = Color.white;
            GUI.color = new Color(.88f,.39f,.12f,1f); GUI.DrawTexture(new Rect(Screen.width*.43f,Screen.height*.19f,Screen.width*.14f,Screen.height*.012f),Texture2D.whiteTexture); GUI.color=Color.white;
            float w = Mathf.Min(Screen.width*.38f, Screen.height*.72f), h = Mathf.Min(Screen.height*.68f, Screen.width*.52f);
            Rect logoRect = new Rect((Screen.width-w)*.5f, Screen.height*.015f, w, h);
            if (brandingLogo != null) GUI.DrawTexture(logoRect, brandingLogo, ScaleMode.ScaleToFit, false);
            else GUI.Label(new Rect(Screen.width*.05f,Screen.height*.25f,Screen.width*.9f,Screen.height*.16f), "SURVIVAL FORCE", loginTitleStyle);
            GUI.Label(new Rect(Screen.width*.05f,Screen.height*.685f,Screen.width*.9f,Screen.height*.07f), "DROP IN. SURVIVE. BE THE LAST ONE STANDING.", loginBodyStyle);
            GUI.Label(new Rect(Screen.width*.05f,Screen.height*.80f,Screen.width*.9f,Screen.height*.06f), "INITIALIZING...", loginButtonStyle);
            float footerX = (Screen.width-w)*.5f;
            GUI.Label(new Rect(footerX,Screen.height*.89f,w,Screen.height*.04f), "CLASSIC ISLANDS  •  OFFLINE BATTLE ROYALE", loginBodyStyle);
        }
        void DrawLoading()
        {
            GUI.color = new Color(.018f,.032f,.05f,1f); GUI.DrawTexture(new Rect(0,0,Screen.width,Screen.height),Texture2D.whiteTexture); GUI.color=Color.white;
            GUI.color = new Color(.09f,.19f,.22f,1f); GUI.DrawTexture(new Rect(0,Screen.height*.60f,Screen.width,Screen.height*.40f),Texture2D.whiteTexture); GUI.color=Color.white;
            float sw=Screen.width, sh=Screen.height, w=Mathf.Min(sw*.72f,760f), x=(sw-w)*.5f;
            if (brandingLogo != null) GUI.DrawTexture(new Rect((sw-Mathf.Min(sw*.22f,sh*.36f))*.5f,sh*.015f,Mathf.Min(sw*.22f,sh*.36f),sh*.34f),brandingLogo,ScaleMode.ScaleToFit,false);
            else GUI.Label(new Rect(x,sh*.25f,w,sh*.12f),"SURVIVAL FORCE",loginTitleStyle);
            GUI.Label(new Rect(x,sh*.37f,w,sh*.07f),""+loadingMessage,loginBodyStyle);
            float progress=Mathf.Clamp01(loadingTimer/Mathf.Max(.01f,loadingDuration));
            Rect track=new Rect(x,sh*.51f,w,Mathf.Clamp(sh*.025f,12f,24f));
            GUI.color=new Color(.02f,.045f,.055f,1f); GUI.DrawTexture(track,Texture2D.whiteTexture);
            GUI.color=new Color(.93f,.43f,.13f,1f); GUI.DrawTexture(new Rect(track.x,track.y,track.width*progress,track.height),Texture2D.whiteTexture); GUI.color=Color.white;
            GUI.Label(new Rect(x,sh*.56f,w,sh*.06f),Mathf.RoundToInt(progress*100f)+"%",loginBodyStyle);
            GUI.Label(new Rect(x,sh*.74f,w,sh*.06f),"RESTORING LOCAL SESSION",loginBodyStyle);
            GUI.Label(new Rect(x,sh*.83f,w,sh*.05f),"OFFLINE PROFILE  •  NO ONLINE SERVER REQUIRED",loginBodyStyle);
        }
        void DrawLobby()
        {
            // Responsive offline lobby. Every visible tab has a local page; online-only features
            // are clearly identified rather than pretending a server connection exists.
            float sw = Screen.width, sh = Screen.height;
            Color oldColor = GUI.color;
            GUI.color = new Color(.022f, .038f, .052f, 1f);
            GUI.DrawTexture(new Rect(0, 0, sw, sh), Texture2D.whiteTexture);
            GUI.color = new Color(.045f, .085f, .10f, 1f);
            GUI.DrawTexture(new Rect(0, 0, sw, sh * .145f), Texture2D.whiteTexture);
            GUI.color = new Color(.92f, .40f, .12f, 1f);
            GUI.DrawTexture(new Rect(0, sh * .14f, sw, Mathf.Max(2f, sh * .004f)), Texture2D.whiteTexture);
            GUI.color = Color.white;

            GUI.Label(new Rect(sw * .025f, sh * .012f, sw * .48f, sh * .075f), "SURVIVAL FORCE", loginTitleStyle);
            GUI.Label(new Rect(sw * .03f, sh * .085f, sw * .48f, sh * .035f), "CLASSIC ISLANDS  /  OFFLINE SURVIVAL", loginBodyStyle);

            GUI.color = new Color(.075f, .14f, .16f, 1f);
            GUI.Box(new Rect(sw * .69f, sh * .022f, sw * .285f, sh * .105f), GUIContent.none);
            GUI.color = Color.white;
            GUI.Label(new Rect(sw * .705f, sh * .032f, sw * .25f, sh * .043f), "SURVIVOR  " + profileName, loginBodyStyle);
            GUI.Label(new Rect(sw * .705f, sh * .078f, sw * .25f, sh * .035f), "LV. " + MatchProgression.Level + "      COINS  " + localCoins + "      GEMS  0", loginBodyStyle);

            // Compact left rail keeps the complete lobby navigation available on landscape phones.
            GUI.color = new Color(.03f, .055f, .065f, 1f);
            GUI.DrawTexture(new Rect(0, sh * .16f, sw * .175f, sh * .77f), Texture2D.whiteTexture);
            GUI.color = Color.white;
            string[] tabs = { "HOME", "PROFILE", "INVENTORY", "WEAPONS", "COLLECTION", "FRIENDS", "SQUAD", "RANK", "MAIL", "EVENTS", "STORE", "SETTINGS" };
            float tabH = sh * .046f;
            float tabGap = sh * .008f;
            for (int i = 0; i < tabs.Length; i++)
            {
                Rect tabRect = new Rect(sw * .012f, sh * .178f + i * (tabH + tabGap), sw * .151f, tabH);
                GUI.color = lobbyPage == i ? new Color(.77f, .32f, .09f, 1f) : new Color(.065f, .12f, .135f, 1f);
                if (GUI.Button(tabRect, tabs[i], loginButtonStyle)) { lobbyPage = i; showLobbyPopup = false; }
                GUI.color = Color.white;
            }
            GUI.Label(new Rect(sw * .018f, sh * .865f, sw * .145f, sh * .045f), "BUILD 1.0 / LOCAL", loginBodyStyle);

            GUI.color = new Color(.055f, .095f, .105f, 1f);
            GUI.Box(new Rect(sw * .19f, sh * .16f, sw * .50f, sh * .71f), GUIContent.none);
            GUI.color = Color.white;
            if (lobbyPage == 11)
            {
                DrawSettingsPanel(sw, sh);
            }
            else
            {
                string title = lobbyPage == 12 ? "DAILY REWARDS" : tabs[Mathf.Clamp(lobbyPage, 0, tabs.Length - 1)];
                GUI.Label(new Rect(sw * .215f, sh * .175f, sw * .45f, sh * .065f), title, loginTitleStyle);

                if (lobbyPage <= 4 && lobbyPreviewTexture != null)
                {
                    GUI.DrawTexture(new Rect(sw * .31f, sh * .255f, sw * .25f, sh * .35f), lobbyPreviewTexture, ScaleMode.ScaleToFit, false);
                    GUI.Label(new Rect(sw * .22f, sh * .61f, sw * .44f, sh * .04f), outfitNames[selectedOutfit] + "  /  " + weaponNames[selectedWeapon], loginBodyStyle);
                }

                float px = sw * .22f, pw = sw * .44f;
                if (lobbyPage == 0)
                {
                    GUI.Label(new Rect(px, sh * .67f, pw, sh * .11f), "BATTLE ROYALE  •  SOLO OFFLINE\n22 AI opponents  /  Loot, combat and shrinking safe zone", loginBodyStyle);
                }
                else if (lobbyPage == 1)
                {
                    GUI.Label(new Rect(px, sh * .67f, pw, sh * .10f), "LOCAL SURVIVOR PROFILE\nName: " + profileName + "\nLevel: 1  •  Coins: " + localCoins + "\nSaved on this device; no online account is used.", loginBodyStyle);
                    if (GUI.Button(new Rect(px, sh * .80f, pw * .45f, sh * .05f), "CHANGE PLAYER NAME", loginButtonStyle)) { frontendStage = FrontendStage.Login; loginMessage = "Enter a player name for this device."; }
                }
                else if (lobbyPage == 2)
                {
                    GUI.Label(new Rect(px, sh * .67f, pw, sh * .08f), "INVENTORY / OUTFITS\nOwned outfits are saved locally. Use the button to equip the next owned outfit.", loginBodyStyle);
                    if (GUI.Button(new Rect(px, sh * .79f, pw * .75f, sh * .055f), "EQUIP OUTFIT  /  " + outfitNames[selectedOutfit], loginButtonStyle)) CycleOwnedOutfit();
                }
                else if (lobbyPage == 3)
                {
                    GUI.Label(new Rect(px, sh * .67f, pw, sh * .08f), "WEAPON PRESET\nChoose a preset for the next offline match. This is a prototype loadout, not a full attachment inventory.", loginBodyStyle);
                    if (GUI.Button(new Rect(px, sh * .79f, pw * .75f, sh * .055f), "CHANGE LOADOUT  /  " + weaponNames[selectedWeapon], loginButtonStyle))
                    { selectedWeapon = (selectedWeapon + 1) % weaponNames.Length; PlayerPrefs.SetInt("SF_WEAPON", selectedWeapon); PlayerPrefs.Save(); RefreshLobbyPreview(); }
                }
                else if (lobbyPage == 4)
                {
                    GUI.Label(new Rect(px, sh * .67f, pw, sh * .12f), "COLLECTION\nField Recruit is available by default. Desert Scout, Night Ops and Urban Raider can be unlocked in Store.\nOnline collection sync and cloud rewards are not available offline.", loginBodyStyle);
                }
                else if (lobbyPage == 5 || lobbyPage == 6)
                {
                    GUI.Label(new Rect(px, sh * .29f, pw, sh * .14f), lobbyPage == 5 ? "FRIENDS\nThis build runs completely offline. Friend invites, chat and online presence need a multiplayer service." : "SQUAD\nSquad matchmaking is not implemented yet. You can play the current solo offline match.", loginBodyStyle);
                    GUI.color = new Color(.09f, .16f, .17f, 1f);
                    if (GUI.Button(new Rect(px + pw * .1f, sh * .49f, pw * .8f, sh * .065f), "OFFLINE MODE  •  SOLO ONLY", loginButtonStyle)) ShowLobbyPopup("OFFLINE MODE", "No network connection or fake player list is used. Squad and friends require a real multiplayer backend.");
                    GUI.color = Color.white;
                }
                else if (lobbyPage == 7)
                {
                    GUI.Label(new Rect(px, sh * .29f, pw, sh * .13f), "LOCAL RANK\nRookie I\nRanked matchmaking and seasonal leaderboard are not connected in this offline build.", loginBodyStyle);
                    GUI.Label(new Rect(px, sh * .48f, pw, sh * .08f), "BEST RESULT: " + PlayerPrefs.GetInt("SF_BEST_KILLS", 0) + " eliminations\nTOTAL MATCHES: " + PlayerPrefs.GetInt("SF_MATCHES", 0), loginBodyStyle);
                }
                else if (lobbyPage == 8)
                {
                    GUI.Label(new Rect(px, sh * .29f, pw, sh * .13f), "MAILBOX\nWelcome to SURVIVAL FORCE!\nYour local profile is ready. Explore the island, collect loot and survive the safe zone.\n\nSystem mail only; server rewards are not available.", loginBodyStyle);
                    if (GUI.Button(new Rect(px, sh * .52f, pw * .60f, sh * .055f), "MARK LOCAL MAIL READ", loginButtonStyle)) { PlayerPrefs.SetInt("SF_MAIL_READ", 1); PlayerPrefs.Save(); lobbyNotice = "Local mailbox marked as read."; }
                }
                else if (lobbyPage == 9)
                {
                    GUI.Label(new Rect(px, sh * .29f, pw, sh * .13f), "FIELD EVENT  /  SURVIVOR TRAINING\nPlay an offline match and try to survive as long as possible.\nDaily login bonus is available from the Rewards button.", loginBodyStyle);
                    if (GUI.Button(new Rect(px, sh * .49f, pw * .65f, sh * .06f), "OPEN DAILY REWARD", loginButtonStyle)) lobbyPage = 12;
                }
                else if (lobbyPage == 10)
                {
                    GUI.Label(new Rect(px, sh * .27f, pw, sh * .075f), "FIELD STORE  •  LOCAL COSMETICS", loginBodyStyle);
                    DrawStoreItem(1, "DESERT SCOUT", 400, px, sh * .37f, pw, sh);
                    DrawStoreItem(2, "NIGHT OPS", 700, px, sh * .49f, pw, sh);
                    DrawStoreItem(3, "URBAN RAIDER", 900, px, sh * .61f, pw, sh);
                    GUI.Label(new Rect(px, sh * .76f, pw, sh * .06f), "Coins are local prototype currency and have no real-money value.", loginBodyStyle);
                }
                else if (lobbyPage == 12)
                {
                    string today = DateTime.Now.ToString("yyyyMMdd");
                    bool claimed = PlayerPrefs.GetString("SF_DAILY_REWARD_DATE", "") == today;
                    GUI.Label(new Rect(px, sh * .30f, pw, sh * .11f), "DAILY SURVIVOR REWARD\nReward: 200 local coins\n" + (claimed ? "Today's reward has already been claimed." : "Claim once today on this device."), loginBodyStyle);
                    GUI.color = claimed ? new Color(.09f, .13f, .14f, 1f) : new Color(.77f, .32f, .09f, 1f);
                    if (GUI.Button(new Rect(px + pw * .12f, sh * .49f, pw * .76f, sh * .075f), claimed ? "REWARD CLAIMED" : "CLAIM 200 COINS", loginButtonStyle) && !claimed)
                    {
                        localCoins += 200; PlayerPrefs.SetInt("SF_LOCAL_COINS", localCoins); PlayerPrefs.SetString("SF_DAILY_REWARD_DATE", today); PlayerPrefs.Save();
                        lobbyNotice = "Daily reward claimed: +200 coins.";
                    }
                    GUI.color = Color.white;
                    if (GUI.Button(new Rect(px + pw * .12f, sh * .60f, pw * .76f, sh * .06f), "BACK TO HOME", loginButtonStyle)) lobbyPage = 0;
                }
            }

            // Match panel remains present across all pages, so the player can start a match anywhere.
            GUI.color = new Color(.055f, .095f, .105f, 1f);
            GUI.Box(new Rect(sw * .705f, sh * .16f, sw * .275f, sh * .71f), GUIContent.none);
            GUI.color = Color.white;
            GUI.Label(new Rect(sw * .725f, sh * .18f, sw * .24f, sh * .05f), "MATCH SETUP", loginTitleStyle);
            GUI.Label(new Rect(sw * .725f, sh * .235f, sw * .24f, sh * .035f), "MODE  /  SOLO BATTLE ROYALE", loginBodyStyle);
            GUI.color = selectedLoginMap == 0 ? new Color(.77f, .32f, .09f, 1f) : new Color(.08f, .15f, .16f, 1f);
            if (GUI.Button(new Rect(sw * .725f, sh * .285f, sw * .235f, sh * .065f), selectedLoginMap == 0 ? "✓  BERMUDA" : "BERMUDA", loginButtonStyle)) SelectLobbyMap(0);
            GUI.color = selectedLoginMap == 1 ? new Color(.77f, .32f, .09f, 1f) : new Color(.08f, .15f, .16f, 1f);
            if (GUI.Button(new Rect(sw * .725f, sh * .36f, sw * .235f, sh * .065f), selectedLoginMap == 1 ? "✓  PURGATORY" : "PURGATORY", loginButtonStyle)) SelectLobbyMap(1);
            GUI.color = new Color(.08f, .15f, .16f, 1f);
            if (GUI.Button(new Rect(sw * .725f, sh * .445f, sw * .235f, sh * .055f), "DAILY REWARDS  +200", loginButtonStyle)) lobbyPage = 12;
            GUI.color = new Color(.77f, .28f, .06f, 1f);
            float pulse = 1f + Mathf.Sin(Time.unscaledTime * 3.2f) * .018f;
            if (GUI.Button(new Rect(sw * .725f, sh * .52f, sw * .235f * pulse, sh * .09f), "START MATCH  ▶", loginButtonStyle)) StartMatch();
            GUI.color = new Color(.08f, .15f, .16f, 1f);
            if (GUI.Button(new Rect(sw * .725f, sh * .63f, sw * .235f, sh * .055f), "CHANGE PLAYER", loginButtonStyle)) { PlayerPrefs.SetInt("SF_LOCAL_LOGIN_OK", 0); PlayerPrefs.Save(); frontendStage = FrontendStage.Login; }
            if (GUI.Button(new Rect(sw * .725f, sh * .70f, sw * .235f, sh * .055f), "LOG OUT", loginButtonStyle)) Logout();
            GUI.color = new Color(.09f, .16f, .17f, 1f);
            GUI.Box(new Rect(sw * .205f, sh * .885f, sw * .77f, sh * .055f), GUIContent.none);
            GUI.color = new Color(.98f, .67f, .29f, 1f);
            GUI.Label(new Rect(sw * .22f, sh * .89f, sw * .12f, sh * .04f), "FIELD NOTE", loginBodyStyle);
            GUI.color = Color.white;
            GUI.Label(new Rect(sw * .34f, sh * .89f, sw * .62f, sh * .04f), lobbyNotice, loginBodyStyle);

            if (showLobbyPopup)
            {
                GUI.color = new Color(.015f, .025f, .03f, .94f);
                GUI.Box(new Rect(sw * .30f, sh * .27f, sw * .40f, sh * .42f), GUIContent.none);
                GUI.color = Color.white;
                GUI.Label(new Rect(sw * .32f, sh * .30f, sw * .36f, sh * .07f), popupTitle, loginTitleStyle);
                GUI.Label(new Rect(sw * .33f, sh * .39f, sw * .34f, sh * .17f), popupBody, loginBodyStyle);
                if (GUI.Button(new Rect(sw * .42f, sh * .59f, sw * .16f, sh * .06f), "CLOSE", loginButtonStyle)) showLobbyPopup = false;
            }
            GUI.color = oldColor;
        }

        void SelectLobbyMap(int map)
        {
            selectedLoginMap = Mathf.Clamp(map, 0, 1);
            PlayerPrefs.SetInt("SF_MAP", selectedLoginMap);
            PlayerPrefs.Save();
            lobbyNotice = "Map selected: " + (selectedLoginMap == 0 ? "Bermuda" : "Purgatory") + ".";
        }

        void ShowLobbyPopup(string title, string body)
        {
            popupTitle = title;
            popupBody = body;
            showLobbyPopup = true;
        }

        void CycleOwnedOutfit()
        {
            for (int step = 1; step <= outfitNames.Length; step++)
            {
                int candidate = (selectedOutfit + step) % outfitNames.Length;
                if ((ownedOutfitMask & (1 << candidate)) != 0)
                {
                    selectedOutfit = candidate;
                    PlayerPrefs.SetInt("SF_OUTFIT", selectedOutfit);
                    PlayerPrefs.Save();
                    RefreshLobbyPreview();
                    lobbyNotice = "Equipped outfit: " + outfitNames[selectedOutfit] + ".";
                    return;
                }
            }
        }

        void DrawStoreItem(int outfit, string label, int price, float x, float y, float width, float sh)
        {
            bool owned = (ownedOutfitMask & (1 << outfit)) != 0;
            GUI.color = new Color(.08f, .14f, .15f, 1f);
            GUI.Box(new Rect(x, y, width, sh * .095f), GUIContent.none);
            GUI.color = Color.white;
            GUI.Label(new Rect(x + width * .025f, y + sh * .012f, width * .48f, sh * .06f), label + "\n" + (owned ? "OWNED" : price + " COINS"), loginBodyStyle);
            GUI.color = owned ? new Color(.08f, .14f, .15f, 1f) : new Color(.77f, .32f, .09f, 1f);
            if (GUI.Button(new Rect(x + width * .61f, y + sh * .02f, width * .35f, sh * .055f), owned ? "EQUIP" : "BUY", loginButtonStyle))
            {
                if (owned)
                {
                    selectedOutfit = outfit;
                    PlayerPrefs.SetInt("SF_OUTFIT", selectedOutfit);
                    PlayerPrefs.Save();
                    RefreshLobbyPreview();
                    lobbyNotice = "Equipped " + label + ".";
                }
                else if (localCoins < price) ShowLobbyPopup("NOT ENOUGH COINS", "You need " + price + " coins to unlock " + label + ". Earn more from daily rewards and matches.");
                else
                {
                    localCoins -= price;
                    ownedOutfitMask |= 1 << outfit;
                    selectedOutfit = outfit;
                    PlayerPrefs.SetInt("SF_LOCAL_COINS", localCoins);
                    PlayerPrefs.SetInt("SF_OWNED_OUTFITS", ownedOutfitMask);
                    PlayerPrefs.SetInt("SF_OUTFIT", selectedOutfit);
                    PlayerPrefs.Save();
                    RefreshLobbyPreview();
                    lobbyNotice = label + " unlocked and equipped.";
                }
            }
            GUI.color = Color.white;
        }

        void DrawSettingsPanel(float sw, float sh)
        {
            GUI.Label(new Rect(sw*.235f,sh*.215f,sw*.44f,sh*.065f), "SETTINGS", loginTitleStyle);
            float tabY=sh*.292f, tabW=sw*.071f, gap=sw*.004f;
            for(int i=0;i<settingsCategories.Length;i++)
            {
                GUI.color = settingsCategory==i ? new Color(.83f,.43f,.13f,1f) : new Color(.08f,.15f,.17f,1f);
                if(GUI.Button(new Rect(sw*.232f+i*(tabW+gap),tabY,tabW,sh*.055f),settingsCategories[i],loginButtonStyle)) settingsCategory=i;
            }
            GUI.color=Color.white;
            float lx=sw*.25f, rx=sw*.49f, y=sh*.37f, row=sh*.075f;
            if(settingsCategory==0)
            {
                SettingToggle("HIGH FPS (60)", ref highFrameRate, "SF_HIGH_FPS", lx, y, sw, sh); y+=row;
                GUI.Label(new Rect(lx,y,sw*.40f,row),"LANGUAGE: ENGLISH (prototype)",loginBodyStyle); y+=row;
                GUI.Label(new Rect(lx,y,sw*.40f,row),"Account: Local offline profile",loginBodyStyle);
            }
            else if(settingsCategory==1)
            {
                DrawSensitivityRow("GENERAL",ref lookSensitivity,"SF_SENS_GENERAL",0.2f,3.5f,lx,y,sw,sh); y+=row;
                DrawSensitivityRow("RED DOT",ref redDotSensitivity,"SF_SENS_RED_DOT",0.2f,3.5f,lx,y,sw,sh); y+=row;
                DrawSensitivityRow("2X SCOPE",ref scope2xSensitivity,"SF_SENS_2X",0.2f,3.5f,lx,y,sw,sh); y+=row;
                DrawSensitivityRow("4X SCOPE",ref scope4xSensitivity,"SF_SENS_4X",0.2f,3.5f,lx,y,sw,sh); y+=row;
                DrawSensitivityRow("SNIPER SCOPE",ref sniperSensitivity,"SF_SENS_SNIPER",0.2f,3.5f,lx,y,sw,sh);
                GUI.Label(new Rect(lx,sh*.78f,sw*.43f,sh*.04f),"Scope sensitivity applies while aiming with the selected scope.",loginBodyStyle);
            }
            else if(settingsCategory==2)
            {
                GUI.Label(new Rect(lx,y,sw*.42f,row),"AIM: V / touch AIM (camera zoom)",loginBodyStyle); y+=row;
                GUI.Label(new Rect(lx,y,sw*.42f,row),"SCOPE: touch SCOPE to cycle optics",loginBodyStyle); y+=row;
                GUI.Label(new Rect(lx,y,sw*.42f,row),"FIRE: hold mouse / touch FIRE",loginBodyStyle); y+=row;
                GUI.Label(new Rect(lx,y,sw*.42f,row),"RELOAD: R / touch RELOAD | JUMP: Space",loginBodyStyle); y+=row;
                GUI.Label(new Rect(lx,y,sw*.42f,row),"CROUCH: C / touch CROUCH | PRONE: Z / touch PRONE",loginBodyStyle); y+=row;
                GUI.Label(new Rect(lx,y,sw*.42f,row),"PICKUP: E | SPRINT: Shift / touch SPRINT | mouse-look: hold RMB",loginBodyStyle);
            }
            else if(settingsCategory==3)
            {
                SettingToggle("AUTO PICKUP",ref autoPickupEnabled,"SF_AUTO_PICKUP",lx,y,sw,sh); y+=row;
                GUI.Label(new Rect(lx,y,sw*.43f,row*1.4f),"When enabled, nearby loot is collected automatically. Advanced item priority rules are not implemented yet.",loginBodyStyle);
            }
            else if(settingsCategory==4)
            {
                GUI.color=new Color(.08f,.15f,.17f,1f);
                if(GUI.Button(new Rect(lx,y,sw*.23f,row*.72f),lobbyMusicEnabled?"LOBBY MUSIC: ON":"LOBBY MUSIC: OFF",loginButtonStyle))
                { lobbyMusicEnabled=!lobbyMusicEnabled; PlayerPrefs.SetInt("SF_LOBBY_MUSIC",lobbyMusicEnabled?1:0); PlayerPrefs.Save(); UpdateLobbyMusic(); } y+=row;
                GUI.color=Color.white;
                GUI.Label(new Rect(lx,y,sw*.18f,row),"MUSIC VOLUME",loginBodyStyle);
                float nv=GUI.HorizontalSlider(new Rect(rx,y+row*.30f,sw*.15f,row*.20f),lobbyMusicVolume,0f,1f);
                if(!Mathf.Approximately(nv,lobbyMusicVolume)){lobbyMusicVolume=nv;if(lobbyMusicSource!=null)lobbyMusicSource.volume=nv;PlayerPrefs.SetFloat("SF_LOBBY_MUSIC_VOLUME",nv);PlayerPrefs.Save();}
                GUI.Label(new Rect(sw*.64f,y,sw*.05f,row),Mathf.RoundToInt(lobbyMusicVolume*100)+"%",loginBodyStyle); y+=row;
                GUI.Label(new Rect(lx,y,sw*.42f,row),"Halloween lobby track loops only in lobby.",loginBodyStyle);
            }
            else
            {
                GUI.Label(new Rect(lx,y,sw*.40f,row),"GRAPHICS PRESET",loginBodyStyle); y+=row;
                string[] presets={"SMOOTH","BALANCED","ULTRA"};
                for(int i=0;i<presets.Length;i++)
                {
                    GUI.color=graphicsPreset==i?new Color(.83f,.43f,.13f,1f):new Color(.08f,.15f,.17f,1f);
                    if(GUI.Button(new Rect(lx+i*sw*.105f,y,sw*.10f,row*.72f),presets[i],loginButtonStyle)){graphicsPreset=i;PlayerPrefs.SetInt("SF_GRAPHICS_PRESET",i);PlayerPrefs.Save();ApplyGraphicsSettings();}
                }
                GUI.color=Color.white; y+=row;
                SettingToggle("DYNAMIC SHADOWS",ref shadowsEnabled,"SF_SHADOWS",lx,y,sw,sh); y+=row;
                GUI.Label(new Rect(lx,y,sw*.42f,row*1.2f),"Smooth is recommended for lower-end phones. Ultra may reduce FPS.",loginBodyStyle);
            }
            GUI.color=new Color(.10f,.20f,.23f,1f);
            if(GUI.Button(new Rect(sw*.52f,sh*.775f,sw*.14f,sh*.045f),"RESET SETTINGS",loginButtonStyle)) ResetSettings();
            GUI.color=Color.white;
        }
        void SettingToggle(string label, ref bool value, string key, float x, float y, float sw, float sh)
        {
            GUI.color=new Color(.08f,.15f,.17f,1f);
            if(GUI.Button(new Rect(x,y,sw*.39f,sh*.055f),label+"   [ "+(value?"ON":"OFF")+" ]",loginButtonStyle))
            { value=!value; PlayerPrefs.SetInt(key,value?1:0); PlayerPrefs.Save(); if(key=="SF_HIGH_FPS")Application.targetFrameRate=value?60:30; if(key=="SF_SHADOWS")ApplyGraphicsSettings(); }
            GUI.color=Color.white;
        }
        void DrawSensitivityRow(string label, ref float value, string key, float min, float max, float x, float y, float sw, float sh)
        {
            GUI.Label(new Rect(x,y,sw*.15f,sh*.05f),label,loginBodyStyle);
            float nv=GUI.HorizontalSlider(new Rect(x+sw*.15f,y+sh*.017f,sw*.19f,sh*.025f),value,min,max);
            if(!Mathf.Approximately(nv,value)){value=nv;PlayerPrefs.SetFloat(key,value);PlayerPrefs.Save();}
            GUI.Label(new Rect(x+sw*.35f,y,sw*.06f,sh*.05f),value.ToString("0.0"),loginBodyStyle);
        }
        void ApplyGraphicsSettings()
        {
            int level=graphicsPreset==0?0:graphicsPreset==1?1:2;
            QualitySettings.SetQualityLevel(level,true);
            QualitySettings.shadows=shadowsEnabled&&graphicsPreset>0?ShadowQuality.All:ShadowQuality.Disable;
            QualitySettings.shadowDistance=graphicsPreset==0?35f:graphicsPreset==1?85f:145f;
            QualitySettings.shadowResolution=graphicsPreset==2?ShadowResolution.High:ShadowResolution.Medium;
            QualitySettings.antiAliasing=graphicsPreset==2?2:0;
        }
        void ResetSettings()
        {
            lookSensitivity=2.1f;redDotSensitivity=1.8f;scope2xSensitivity=1.6f;scope4xSensitivity=1.35f;sniperSensitivity=.9f;
            lobbyMusicEnabled=true;lobbyMusicVolume=.55f;highFrameRate=true;shadowsEnabled=true;autoPickupEnabled=false;graphicsPreset=1;
            PlayerPrefs.SetFloat("SF_SENS_GENERAL",lookSensitivity);PlayerPrefs.SetFloat("SF_SENS_RED_DOT",redDotSensitivity);PlayerPrefs.SetFloat("SF_SENS_2X",scope2xSensitivity);PlayerPrefs.SetFloat("SF_SENS_4X",scope4xSensitivity);PlayerPrefs.SetFloat("SF_SENS_SNIPER",sniperSensitivity);
            PlayerPrefs.SetInt("SF_LOBBY_MUSIC",1);PlayerPrefs.SetFloat("SF_LOBBY_MUSIC_VOLUME",lobbyMusicVolume);PlayerPrefs.SetInt("SF_HIGH_FPS",1);PlayerPrefs.SetInt("SF_SHADOWS",1);PlayerPrefs.SetInt("SF_AUTO_PICKUP",0);PlayerPrefs.SetInt("SF_GRAPHICS_PRESET",1);PlayerPrefs.Save();
            if(lobbyMusicSource!=null)lobbyMusicSource.volume=lobbyMusicVolume;Application.targetFrameRate=60;ApplyGraphicsSettings();
        }
        void CreateLobbyPreview()
        {
            DestroyLobbyPreview();
            lobbyPreviewTexture = new RenderTexture(512, 512, 16, RenderTextureFormat.ARGB32);
            lobbyPreviewTexture.name = "SURVIVAL FORCE Lobby Character Preview";
            GameObject camObject = new GameObject("Lobby Preview Camera");
            lobbyPreviewCamera = camObject.AddComponent<Camera>();
            lobbyPreviewCamera.targetTexture = lobbyPreviewTexture;
            lobbyPreviewCamera.clearFlags = CameraClearFlags.SolidColor;
            lobbyPreviewCamera.backgroundColor = new Color(.10f,.17f,.18f,1f);
            lobbyPreviewCamera.fieldOfView = 32f;
            lobbyPreviewCamera.nearClipPlane = .1f; lobbyPreviewCamera.farClipPlane = 30f;
            lobbyPreviewCamera.cullingMask = 1 << 30;
            camObject.transform.position = new Vector3(0,1.25f,-5.4f);
            camObject.transform.rotation = Quaternion.LookRotation(new Vector3(0,1.05f,0)-camObject.transform.position);
            GameObject lightObject = new GameObject("Lobby Preview Light");
            Light previewLight = lightObject.AddComponent<Light>(); previewLight.type=LightType.Directional; previewLight.intensity=1.35f; previewLight.cullingMask=1<<30;
            lightObject.transform.rotation=Quaternion.Euler(35,-25,0);
            lobbyPreviewRoot = new GameObject("Lobby Survivor 3D Preview").transform;
            lobbyPreviewRoot.gameObject.layer = 30;
            lobbyPreviewRoot.position = Vector3.zero;
            Color[] outfitColors = { new Color(.12f,.38f,.62f), new Color(.62f,.39f,.18f), new Color(.20f,.24f,.30f), new Color(.36f,.43f,.28f) };
            Color cloth=outfitColors[selectedOutfit];
            PreviewPart("Preview Torso",PrimitiveType.Capsule,new Vector3(0,1.03f,0),new Vector3(.58f,.60f,.34f),cloth);
            PreviewPart("Preview Head",PrimitiveType.Sphere,new Vector3(0,1.82f,0),new Vector3(.34f,.36f,.34f),new Color(.70f,.52f,.39f));
            PreviewPart("Preview Hair",PrimitiveType.Sphere,new Vector3(0,1.98f,0),new Vector3(.35f,.18f,.35f),new Color(.12f,.10f,.08f));
            PreviewPart("Preview Tactical Vest",PrimitiveType.Cube,new Vector3(0,1.12f,.025f),new Vector3(.60f,.44f,.37f),new Color(.13f,.18f,.19f));
            PreviewPart("Preview Left Arm",PrimitiveType.Capsule,new Vector3(-.39f,1.13f,0),new Vector3(.19f,.47f,.19f),cloth);
            PreviewPart("Preview Right Arm",PrimitiveType.Capsule,new Vector3(.39f,1.13f,0),new Vector3(.19f,.47f,.19f),cloth);
            PreviewPart("Preview Left Leg",PrimitiveType.Capsule,new Vector3(-.17f,.47f,0),new Vector3(.22f,.47f,.23f),new Color(.12f,.13f,.15f));
            PreviewPart("Preview Right Leg",PrimitiveType.Capsule,new Vector3(.17f,.47f,0),new Vector3(.22f,.47f,.23f),new Color(.12f,.13f,.15f));
            PreviewPart("Preview Belt",PrimitiveType.Cube,new Vector3(0,.77f,.01f),new Vector3(.48f,.12f,.30f),new Color(.12f,.10f,.08f));
            Color gun = selectedWeapon==1 ? new Color(.18f,.20f,.18f) : selectedWeapon==2 ? new Color(.35f,.31f,.25f) : new Color(.07f,.08f,.08f);
            PreviewPart("Preview Weapon Stock",PrimitiveType.Cube,new Vector3(.32f,1.19f,.26f),new Vector3(.12f,.12f,.42f),gun);
            PreviewPart("Preview Weapon Barrel",PrimitiveType.Cylinder,new Vector3(.34f,1.19f,.53f),new Vector3(.035f,.035f,.30f),gun);
        }
        void PreviewPart(string partName, PrimitiveType type, Vector3 localPos, Vector3 localScale, Color color)
        {
            GameObject part=GameObject.CreatePrimitive(type); part.name=partName; part.layer=30;
            part.transform.SetParent(lobbyPreviewRoot,false); part.transform.localPosition=localPos; part.transform.localScale=localScale;
            Collider col=part.GetComponent<Collider>(); if(col) Destroy(col);
            Renderer r=part.GetComponent<Renderer>(); if(r){ Shader sh=Shader.Find("Standard"); if(sh==null) sh=Shader.Find("Universal Render Pipeline/Lit"); if(sh!=null){Material m=new Material(sh);m.color=color;r.material=m;} }
        }
        void RefreshLobbyPreview()
        {
            if (lobbyPreviewCamera != null) CreateLobbyPreview();
        }
        void DestroyLobbyPreview()
        {
            if (lobbyPreviewCamera != null) { if(lobbyPreviewCamera.targetTexture) lobbyPreviewCamera.targetTexture=null; Destroy(lobbyPreviewCamera.gameObject); lobbyPreviewCamera=null; }
            if (lobbyPreviewRoot != null) { Destroy(lobbyPreviewRoot.gameObject); lobbyPreviewRoot=null; }
            GameObject oldLight=GameObject.Find("Lobby Preview Light"); if(oldLight) Destroy(oldLight);
            if (lobbyPreviewTexture != null) { lobbyPreviewTexture.Release(); Destroy(lobbyPreviewTexture); lobbyPreviewTexture=null; }
        }
        void LateUpdate()
        {
            if (!gameStarted && frontendStage==FrontendStage.Lobby && lobbyPreviewRoot!=null)
                lobbyPreviewRoot.rotation=Quaternion.Euler(0,Mathf.Sin(Time.unscaledTime*.65f)*13f,0);
        }

        void SwitchMap(int map)
        {
            if (PlayerPrefs.GetInt("SF_MAP",0)==map && MapName==(map==0?"Bermuda":"Purgatory")) return;
            PlayerPrefs.SetInt("SF_MAP",map); PlayerPrefs.Save();
            StartCoroutine(RebuildForMap(map));
        }
        System.Collections.IEnumerator RebuildForMap(int map)
        {
            Transform[] all = FindObjectsOfType<Transform>();
            foreach (Transform t in all)
                if (t && t.parent == null && t.gameObject != gameObject) Destroy(t.gameObject);
            yield return null;
            MapName = map == 1 ? "Purgatory" : "Bermuda";
            Player = null; Vitals = null; Kills = 0; matchTime = 0; gameOver = false; gameStarted = true;
            spawnPoints.Clear(); hudText = null; hintText = null;
            BuildWorld(); BuildPlayer(); BuildBots(22); BuildLoot(42); BuildZone(); BuildHud();
        }
        public void AddKill() { Kills++; MatchProgression.RecordKill(); }
        public void SpawnBotLoot(Vector3 position)
        {
            int roll = Random.Range(0, 100);
            LootKind kind = roll < 52 ? LootKind.Ammo : roll < 76 ? LootKind.Medkit : roll < 91 ? LootKind.Armor : LootKind.MarksmanAmmo;
            int amount = kind == LootKind.Medkit ? 1 : kind == LootKind.Armor ? 25 : kind == LootKind.MarksmanAmmo ? 12 : 30;
            Vector3 p = position + new Vector3(Random.Range(-1.1f,1.1f), .5f, Random.Range(-1.1f,1.1f));
            var item = Create(PrimitiveType.Cube, "Bot drop - " + kind, p, new Vector3(.65f,.65f,.65f), kind == LootKind.Medkit ? new Color(.15f,.85f,.35f) : kind == LootKind.Armor ? new Color(.25f,.55f,.95f) : new Color(.95f,.7f,.18f));
            var loot = item.AddComponent<LootPickup>(); loot.Kind = kind; loot.Healing = kind == LootKind.Medkit; loot.Amount = amount;
        }
        void Logout()
        {
            PlayerPrefs.SetInt("SF_LOCAL_LOGIN_OK", 0);
            PlayerPrefs.Save();
            UnityEngine.SceneManagement.SceneManager.LoadScene(UnityEngine.SceneManagement.SceneManager.GetActiveScene().buildIndex);
        }
        void BuildWorld()
        {
            // Mobile-friendly visual pass: brighter outdoor lighting, soft shadows, sky and atmospheric depth.
            RenderSettings.ambientLight = new Color(.68f,.72f,.76f);
            RenderSettings.ambientMode = UnityEngine.Rendering.AmbientMode.Trilight;
            RenderSettings.ambientSkyColor = new Color(.48f,.62f,.78f);
            RenderSettings.ambientEquatorColor = new Color(.48f,.52f,.40f);
            RenderSettings.ambientGroundColor = new Color(.22f,.24f,.18f);
            RenderSettings.fog = true; RenderSettings.fogMode = FogMode.Exponential; RenderSettings.fogColor = new Color(.57f,.70f,.78f); RenderSettings.fogDensity = .00115f;
            RenderSettings.skybox = MakeProceduralSky();
            QualitySettings.shadows = ShadowQuality.All; QualitySettings.shadowResolution = ShadowResolution.Medium;
            QualitySettings.shadowDistance = 145f; QualitySettings.shadowCascades = 2;
            var light = new GameObject("Sun - outdoor key light").AddComponent<Light>(); light.type=LightType.Directional; light.intensity=1.18f; light.color=new Color(1f,.94f,.82f); light.shadows=LightShadows.Soft; light.shadowStrength=.72f; light.transform.rotation=Quaternion.Euler(48,-35,0);
            var ground=Create(PrimitiveType.Cylinder,"Island terrain",new Vector3(0,-1.2f,0),new Vector3(460,2,460),new Color(.24f,.43f,.22f));
            ground.GetComponent<Renderer>().material.mainTexture = MakeGroundTexture(256, 256, false);
            Create(PrimitiveType.Cylinder,"Coastline sand",new Vector3(0,-.95f,0),new Vector3(470,1.7f,470),new Color(.72f,.65f,.43f)).transform.SetSiblingIndex(0);
            // Large grass island top is layered above coastline.
            ground.transform.position=new Vector3(0,-.5f,0); ground.transform.localScale=new Vector3(450,1,450);
            Create(PrimitiveType.Cylinder,"Ocean",new Vector3(0,-3.5f,0),new Vector3(1500,1,1500),new Color(.08f,.31f,.48f));
            BuildDistantHills();
            // Two selectable original classic-style island layouts. These are recreations/inspired layouts, not extracted Garena map data.
            bool purgatory = MapName == "Purgatory";
            // Classic-era location roster. These are recognizable named POIs, not extracted
            // proprietary coordinates or geometry; positions are approximate recreations.
            string[] names = purgatory
                ? new string[]{"Brasilia","Central","Marbleworks","Golf Course","Mt. Villa","Quarry","Lumber Mill","Fields","Crossroads","Fire Brigade","Forge","Campsite","Ski Lodge","Moathouse"}
                : new string[]{"Waterfront","Ranch","Outpost","Hangar","Rim Nam Village","Katulistiwa","Clock Tower","Shipyard","Plantation","Bimasakti Strip","Factory","Riverside","Peak","Pochinok","Mars Electric","Mill","Kota Tua","Sentosa","Keraton","Cape Town"};
            Vector3[] pts = purgatory
                ? new Vector3[]{new Vector3(-95,0,-55),new Vector3(5,0,-90),new Vector3(-155,0,65),new Vector3(-120,0,125),new Vector3(75,0,155),new Vector3(165,0,55),new Vector3(125,0,-110),new Vector3(5,0,145),new Vector3(-175,0,-90),new Vector3(55,0,-155),new Vector3(145,0,115),new Vector3(100,0,-15),new Vector3(165,0,-165),new Vector3(-45,0,15)}
                : new Vector3[]{new Vector3(-165,0,-155),new Vector3(155,0,-145),new Vector3(-45,0,-165),new Vector3(-35,0,165),new Vector3(-175,0,115),new Vector3(35,0,-45),new Vector3(105,0,85),new Vector3(-160,0,20),new Vector3(155,0,5),new Vector3(-5,0,35),new Vector3(-15,0,115),new Vector3(35,0,-125),new Vector3(5,0,5),new Vector3(125,0,-55),new Vector3(175,0,150),new Vector3(145,0,65),new Vector3(175,0,-35),new Vector3(185,0,-105),new Vector3(-95,0,75),new Vector3(85,0,155)};
            for(int i=0;i<names.Length;i++) { BuildCompound(names[i],pts[i],i); }
            // Road network, cross-island route, bridges and distinct landmarks per map.
            Color roadColor = new Color(.22f,.23f,.22f);
            Create(PrimitiveType.Cube,"Main road west-east",new Vector3(0,.02f,8),new Vector3(390,.08f,8),roadColor);
            Create(PrimitiveType.Cube,"Main road north-south",new Vector3(12,.025f,0),new Vector3(8,.08f,390),roadColor);
            Create(PrimitiveType.Cube,"Bridge deck",new Vector3(52,.12f,130),new Vector3(70,.3f,13),new Color(.35f,.34f,.30f));
            for(int side=-1;side<=1;side+=2) Create(PrimitiveType.Cube,"Bridge rail",new Vector3(52,.8f,130+side*6),new Vector3(70,1.1f,.35f),new Color(.26f,.27f,.27f));
            if(purgatory){
                // Purgatory's defining waterways and multiple bridge crossings.
                Create(PrimitiveType.Cube,"Purgatory main river",new Vector3(-15,-.18f,0),new Vector3(24,.12f,390),new Color(.08f,.34f,.52f));
                Create(PrimitiveType.Cube,"Purgatory west channel",new Vector3(-100,-.16f,20),new Vector3(14,.12f,300),new Color(.08f,.34f,.52f));
                Create(PrimitiveType.Cube,"River bridge north",new Vector3(-15,.1f,115),new Vector3(42,.35f,12),new Color(.42f,.39f,.32f));
                Create(PrimitiveType.Cube,"River bridge south",new Vector3(-15,.1f,-100),new Vector3(42,.35f,12),new Color(.42f,.39f,.32f));
                for(int side=-1;side<=1;side+=2){Create(PrimitiveType.Cube,"Purgatory bridge rail",new Vector3(-15,.7f,115+side*6),new Vector3(42,.9f,.3f),new Color(.26f,.27f,.27f));}
                for(int i=0;i<7;i++){float x=Random.Range(115,155),z=Random.Range(-115,115);Create(PrimitiveType.Cylinder,"Lumber Mill log stack",new Vector3(x,.8f,z),new Vector3(2,1.6f,7),new Color(.37f,.23f,.12f));}
                for(int i=0;i<5;i++) Create(PrimitiveType.Cylinder,"Golf Course green",new Vector3(-145+i*14,.03f,125),new Vector3(12,.05f,14),new Color(.31f,.53f,.24f));
            } else {
                // Classic Bermuda cues: harbor/shipyard, airstrip and offshore Sentosa link.
                Create(PrimitiveType.Cube,"Shipyard pier",new Vector3(-190,.05f,20),new Vector3(42,.3f,10),new Color(.42f,.30f,.19f));
                for(int i=0;i<5;i++) Create(PrimitiveType.Cube,"Shipyard cargo container",new Vector3(-175+i*9,1.5f,35),new Vector3(7,3,3.5f),new Color(i%2==0?.58f:.70f,.28f,.16f));
                Create(PrimitiveType.Cube,"Hangar airstrip runway",new Vector3(-35,.035f,165),new Vector3(90,.08f,18),new Color(.19f,.20f,.20f));
                for(int i=0;i<6;i++) Create(PrimitiveType.Cube,"Runway marking",new Vector3(-73+i*15,.09f,165),new Vector3(7,.025f,.6f),Color.white);
                Create(PrimitiveType.Cube,"Sentosa bridge west",new Vector3(175,.1f,-80),new Vector3(35,.3f,8),new Color(.42f,.39f,.32f));
                Create(PrimitiveType.Cube,"Sentosa bridge east",new Vector3(175,.1f,-120),new Vector3(35,.3f,8),new Color(.42f,.39f,.32f));
            }
            // Dense but deterministic-feeling environmental dressing and scattered cover.
            // More organic road shoulders and secondary paths to connect named POIs.
            Create(PrimitiveType.Cube,"Road shoulder east",new Vector3(0,-.005f,14),new Vector3(385,.035f,2.2f),new Color(.48f,.43f,.32f));
            Create(PrimitiveType.Cube,"Road shoulder west",new Vector3(0,-.005f,2),new Vector3(385,.035f,2.2f),new Color(.48f,.43f,.32f));
            for(int i=0;i<175;i++) { Vector2 p=Random.insideUnitCircle*207; if(Mathf.Abs(p.x)<22 && Mathf.Abs(p.y)<22) continue; BuildTree(new Vector3(p.x,0,p.y),i); }
            for(int i=0;i<68;i++){ Vector2 p=Random.insideUnitCircle*210; var rock=Create(PrimitiveType.Sphere,"Rock cover",new Vector3(p.x,.7f,p.y),new Vector3(Random.Range(1.5f,4f),Random.Range(1f,2.5f),Random.Range(1.5f,4f)),new Color(.34f,.36f,.34f)); rock.transform.rotation=Quaternion.Euler(Random.Range(-12f,12f),Random.Range(0f,360f),Random.Range(-12f,12f)); }
            for(int i=0;i<28;i++){ Vector2 p=Random.insideUnitCircle*195; if(p.magnitude>30) Create(PrimitiveType.Cube,"Roadside cover",new Vector3(p.x,.6f,p.y),new Vector3(Random.Range(1.5f,3f),1.2f,Random.Range(1.5f,3f)),new Color(.32f,.34f,.31f)); }
            // Repeated roadside lighting and directional signboards give routes more visual identity.
            for(int i=-8;i<=8;i+=2)
            {
                float z=i*21f;
                Create(PrimitiveType.Cylinder,"Road lamp pole",new Vector3(8f,3.2f,z),new Vector3(.16f,3.2f,.16f),new Color(.20f,.22f,.22f));
                Create(PrimitiveType.Cube,"Road lamp head",new Vector3(8f,6.3f,z),new Vector3(1.1f,.18f,.42f),new Color(.82f,.76f,.58f));
                Create(PrimitiveType.Cube,"Route sign post",new Vector3(-8f,1.6f,z+8f),new Vector3(.18f,1.6f,.18f),new Color(.28f,.23f,.16f));
                Create(PrimitiveType.Cube,"Route sign board",new Vector3(-8f,2.55f,z+8f),new Vector3(2.8f,.9f,.16f),new Color(.13f,.30f,.25f));
            }
        }
        void BuildCompound(string label,Vector3 center,int seed)
        {
            var marker=new GameObject("POI - "+label).transform; marker.position=center; spawnPoints.Add(marker);
            Create(PrimitiveType.Cube,label+" plaza",center+new Vector3(0,.12f,0),new Vector3(26,.25f,22),new Color(.40f,.42f,.36f));
            // Floating POI label makes the classic place name visible during gameplay.
            var labelObject = new GameObject("Location label - " + label);
            labelObject.transform.position = center + new Vector3(0, 10f, 0);
            var tm = labelObject.AddComponent<TextMesh>();
            tm.text = label.ToUpperInvariant(); tm.anchor = TextAnchor.MiddleCenter; tm.alignment = TextAlignment.Center;
            tm.fontSize = 48; tm.characterSize = .22f; tm.color = Color.white;
            labelObject.AddComponent<LocationLabelBillboard>();
            int count=5+(seed%6);
            for(int i=0;i<count;i++){
                float x=(i%3-1)*8.2f+Random.Range(-1f,1f), z=(i/3)*8.2f-4;
                float h=Random.Range(4.5f,10f); var b=Create(PrimitiveType.Cube,label+" building "+i,center+new Vector3(x,h/2,z),new Vector3(Random.Range(5f,8f),h,Random.Range(5f,8f)),new Color(Random.Range(.38f,.65f),Random.Range(.34f,.53f),Random.Range(.26f,.42f)));
                var roof=Create(PrimitiveType.Cube,label+" roof "+i,b.transform.position+Vector3.up*(h/2+.2f),new Vector3(b.transform.localScale.x+ .3f,.4f,b.transform.localScale.z+.3f),new Color(.27f,.20f,.17f));
                // visible doorway recess is approximated with dark panel
                Create(PrimitiveType.Cube,"Door",b.transform.position+new Vector3(0,-h*.28f,-b.transform.localScale.z/2-.03f),new Vector3(1.1f,2.1f,.08f),new Color(.12f,.10f,.08f));
                if(i%2==0) Create(PrimitiveType.Cube,"Window",b.transform.position+new Vector3(1.5f,.5f,-b.transform.localScale.z/2-.05f),new Vector3(1.2f,1.1f,.08f),new Color(.12f,.37f,.47f));
                if(i%3==0) Create(PrimitiveType.Cube,label+" balcony",b.transform.position+new Vector3(0,-.2f,-b.transform.localScale.z/2-.8f),new Vector3(3f,.18f,1.5f),new Color(.25f,.25f,.23f));
            }
            // Low walls and crates create combat cover between structures.
            for(int j=0;j<5;j++) Create(PrimitiveType.Cube,label+" wall cover",center+new Vector3(Random.Range(-15f,15f),.65f,Random.Range(-13f,13f)),new Vector3(Random.Range(2f,5f),1.3f,.5f),new Color(.43f,.42f,.36f));
        }
        void BuildTree(Vector3 p, int seed)
        {
            float height = 1.2f + (seed % 5) * .18f;
            Create(PrimitiveType.Cylinder,"Tree trunk",p+Vector3.up*height,new Vector3(.42f,.65f+height*.55f,.42f),new Color(.28f,.17f,.09f));
            Color foliage = seed % 3 == 0 ? new Color(.17f,.39f,.16f) : (seed % 3 == 1 ? new Color(.12f,.31f,.13f) : new Color(.22f,.40f,.17f));
            var crown=Create(PrimitiveType.Sphere,"Tree canopy",p+Vector3.up*(height*2.1f+1.3f),new Vector3(2.7f+height,2.7f+height,2.7f+height),foliage);
            crown.transform.localScale = Vector3.Scale(crown.transform.localScale,new Vector3(1f,.9f,1f));
            if(seed%4==0) Create(PrimitiveType.Sphere,"Tree upper foliage",p+Vector3.up*(height*2.8f+2f),new Vector3(2.2f,2.5f,2.2f),foliage);
        }
        void BuildDistantHills()
        {
            // Low-poly ridge silhouettes on the horizon add scale without heavy assets.
            for(int i=0;i<24;i++)
            {
                float a = i*Mathf.PI*2f/24f;
                float radius = Random.Range(250f,285f);
                float h = Random.Range(18f,34f);
                var hill=Create(PrimitiveType.Cylinder,"Distant island ridge",new Vector3(Mathf.Cos(a)*radius,h*.22f,Mathf.Sin(a)*radius),new Vector3(Random.Range(35f,58f),h*.45f,Random.Range(32f,52f)),new Color(.22f,.34f,.31f));
                hill.transform.rotation=Quaternion.Euler(Random.Range(-5f,5f),Random.Range(0f,360f),Random.Range(-5f,5f));
            }
        }
        Material MakeProceduralSky()
        {
            Shader shader=Shader.Find("Skybox/Procedural");
            if(shader==null) return RenderSettings.skybox;
            Material sky=new Material(shader);
            if(sky.HasProperty("_SunSize")) sky.SetFloat("_SunSize",.035f);
            if(sky.HasProperty("_AtmosphereThickness")) sky.SetFloat("_AtmosphereThickness",1.15f);
            if(sky.HasProperty("_SkyTint")) sky.SetColor("_SkyTint",new Color(.55f,.68f,.82f));
            if(sky.HasProperty("_GroundColor")) sky.SetColor("_GroundColor",new Color(.38f,.39f,.32f));
            if(sky.HasProperty("_Exposure")) sky.SetFloat("_Exposure",1.15f);
            return sky;
        }
        Texture2D MakeGroundTexture(int width, int height, bool sand)
        {
            var tex=new Texture2D(width,height,TextureFormat.RGB24,false);
            tex.name=sand?"Procedural sand grain":"Procedural grass variation"; tex.wrapMode=TextureWrapMode.Repeat; tex.filterMode=FilterMode.Bilinear;
            for(int y=0;y<height;y++) for(int x=0;x<width;x++)
            {
                float n=Mathf.PerlinNoise(x*.055f,y*.055f)*.18f + Mathf.PerlinNoise(x*.014f,y*.014f)*.28f + Random.value*.045f;
                Color baseC=sand?new Color(.66f,.57f,.38f):new Color(.22f,.39f,.18f);
                tex.SetPixel(x,y,baseC*(.72f+n));
            }
            tex.Apply(false,true); return tex;
        }
        void BuildPlayer()
        {
            var go=Create(PrimitiveType.Capsule,"Player - you",new Vector3(0,.05f,0),new Vector3(1,1,1),new Color(.18f,.55f,.86f));
            go.GetComponent<Collider>().enabled=false;
            var cc=go.AddComponent<CharacterController>(); cc.height=1.8f; cc.radius=.42f; cc.center=new Vector3(0,.9f,0);
            Vitals=go.AddComponent<PlayerVitals>(); go.AddComponent<PlayerInventory>(); var shooter=go.AddComponent<PlayerShooter>();
            WeaponProfile profile = WeaponCatalog.Get(selectedWeapon);
            shooter.Configure(profile); Vitals.Ammo = profile.Magazine; Vitals.ReserveAmmo = profile.ReserveStart;
            var mover=go.AddComponent<PlayerMotor>(); var visuals=go.AddComponent<ProceduralCharacterVisuals>(); visuals.IsPlayer=true; visuals.OutfitIndex=selectedOutfit;
            var camGo=new GameObject("Follow Camera"); var cam=camGo.AddComponent<Camera>(); cam.fieldOfView=68; camGo.AddComponent<AudioListener>();
            var follow=camGo.AddComponent<FollowCamera>(); follow.target=go.transform; follow.offset=new Vector3(0,3.2f,-6.5f); shooter.viewCamera=cam;
            Player=go.transform;
        }
        void BuildBots(int count)
        {
            for(int i=0;i<count;i++){
                Vector2 p=Random.insideUnitCircle*175f; if(p.magnitude<38) p=p.normalized*55;
                var b=Create(PrimitiveType.Capsule,"Enemy bot "+(i+1),new Vector3(p.x,.05f,p.y),Vector3.one,new Color(.75f,.24f,.19f));
                b.GetComponent<Collider>().enabled=false; var cc=b.AddComponent<CharacterController>(); cc.height=1.8f; cc.radius=.42f; cc.center=new Vector3(0,.9f,0);
                var ai=b.AddComponent<OfflineBot>(); ai.Target=Player; ai.Skill=Random.Range(.65f,1.25f);
                var vit=b.AddComponent<BotVitals>(); vit.Owner=ai; b.AddComponent<ProceduralCharacterVisuals>();
            }
        }
        void BuildLoot(int count)
        {
            for(int i=0;i<count;i++){
                Vector2 p=Random.insideUnitCircle*190; var item=Create(PrimitiveType.Cube,"Loot - ammo or medkit",new Vector3(p.x,.45f,p.y),new Vector3(.8f,.8f,.8f),i%4==0?new Color(.18f,.8f,.35f):new Color(.94f,.72f,.18f));
                item.transform.rotation=Quaternion.Euler(0,Random.Range(0,360),0);
                var loot = item.AddComponent<LootPickup>();
                int roll = i % 10; loot.Kind = roll < 5 ? LootKind.Ammo : roll < 7 ? LootKind.Medkit : roll < 9 ? LootKind.Armor : LootKind.MarksmanAmmo;
                loot.Healing = loot.Kind == LootKind.Medkit; loot.Amount = loot.Kind == LootKind.Medkit ? 1 : loot.Kind == LootKind.Armor ? 25 : loot.Kind == LootKind.MarksmanAmmo ? 12 : 30;
                item.name = "Loot - " + loot.Kind;
                if (loot.Kind == LootKind.Medkit) item.GetComponent<Renderer>().material.color = new Color(.18f,.82f,.35f);
                else if (loot.Kind == LootKind.Armor) item.GetComponent<Renderer>().material.color = new Color(.22f,.55f,.92f);
            }
        }
        void BuildZone()
        {
            var z=Create(PrimitiveType.Cylinder,"Safe zone indicator",new Vector3(0,.025f,0),new Vector3(410,.05f,410),new Color(.1f,.65f,1f));
            var col=z.GetComponent<Collider>(); if(col) Destroy(col); var renderer=z.GetComponent<Renderer>(); renderer.material.color=new Color(.1f,.65f,1f,.12f);
            var zone=z.AddComponent<SafeZoneController>(); zone.Player=Player;
        }
        void BuildHud()
        {
            // Runtime-created UI needs an EventSystem for mouse and Android touch button events.
            if (FindObjectOfType<EventSystem>() == null)
            {
                var eventSystemObject = new GameObject("UI Event System", typeof(EventSystem), typeof(StandaloneInputModule));
            }
            var canvasGo=new GameObject("Game HUD",typeof(Canvas),typeof(CanvasScaler),typeof(GraphicRaycaster)); var canvas=canvasGo.GetComponent<Canvas>(); canvas.renderMode=RenderMode.ScreenSpaceOverlay;
            var scaler=canvasGo.GetComponent<CanvasScaler>(); scaler.uiScaleMode=CanvasScaler.ScaleMode.ScaleWithScreenSize; scaler.referenceResolution=new Vector2(1920,1080);
            hudText=MakeText(canvas.transform,"Match HUD",new Vector2(0,1),new Vector2(0,1),new Vector2(25,-22),new Vector2(900,125),26,TextAnchor.UpperLeft);
            hintText=MakeText(canvas.transform,"Controls",new Vector2(.5f,0),new Vector2(.5f,0),new Vector2(0,24),new Vector2(1100,85),23,TextAnchor.MiddleCenter);
            hintText.text="WASD / left-side drag move | SHIFT / SPRINT | C crouch | Z prone | FIRE shoot | R reload | E loot | SPACE jump";
            MakeButton(canvas.transform,"BERMUDA",new Vector2(0,1),new Vector2(175,-150),new Vector2(170,65),()=>SwitchMap(0));
            MakeButton(canvas.transform,"PURGATORY",new Vector2(0,1),new Vector2(365,-150),new Vector2(190,65),()=>SwitchMap(1));
            MakeButton(canvas.transform,"LOGOUT",new Vector2(1,1),new Vector2(-30,-30),new Vector2(145,55),Logout);
            // touch-friendly on-screen buttons
            MakeHoldButton(canvas.transform,"FIRE",new Vector2(1,0),new Vector2(-145,155),new Vector2(150,100));
            MakeButton(canvas.transform,"JUMP",new Vector2(1,0),new Vector2(-145,275),new Vector2(130,80),()=>{ if(Player) Player.GetComponent<PlayerMotor>().RequestJump(); });
            MakeButton(canvas.transform,"HEAL",new Vector2(1,0),new Vector2(-305,155),new Vector2(120,80),()=>{ if(Vitals) Vitals.Heal(35); });
            MakeButton(canvas.transform,"AIM",new Vector2(1,0),new Vector2(-305,265),new Vector2(120,75),()=>{ if(Player) Player.GetComponent<PlayerShooter>().ToggleAim(); });
            MakeButton(canvas.transform,"SCOPE",new Vector2(1,0),new Vector2(-465,155),new Vector2(120,75),()=>{ if(Player) Player.GetComponent<PlayerShooter>().CycleScope(); });
            MakeButton(canvas.transform,"RELOAD",new Vector2(1,0),new Vector2(-465,265),new Vector2(120,75),()=>{ if(Player) Player.GetComponent<PlayerShooter>().Reload(); });
            MakeButton(canvas.transform,"CROUCH",new Vector2(1,0),new Vector2(-305,365),new Vector2(135,68),()=>{ if(Player) Player.GetComponent<PlayerMotor>().ToggleCrouch(); });
            MakeButton(canvas.transform,"PRONE",new Vector2(1,0),new Vector2(-465,365),new Vector2(120,68),()=>{ if(Player) Player.GetComponent<PlayerMotor>().ToggleProne(); });
            MakeButton(canvas.transform,"SPRINT",new Vector2(1,0),new Vector2(-145,385),new Vector2(135,68),()=>{ if(Player) Player.GetComponent<PlayerMotor>().ToggleSprint(); });
            MakeButton(canvas.transform,"MEDKIT",new Vector2(0,0),new Vector2(28,108),new Vector2(155,72),()=>{ if(Player){var inv=Player.GetComponent<PlayerInventory>();if(inv)inv.UseMedkit();} });
            MakeButton(canvas.transform,"NEXT GUN",new Vector2(0,0),new Vector2(195,108),new Vector2(170,72),()=>{ if(Player){var gun=Player.GetComponent<PlayerShooter>();if(gun)gun.SelectWeapon((PlayerPrefs.GetInt("SF_WEAPON",0)+1)%WeaponCatalog.Count);} });
            var crosshair=MakeText(canvas.transform,"Aim Reticle",new Vector2(.5f,.5f),new Vector2(.5f,.5f),Vector2.zero,new Vector2(60,60),28,TextAnchor.MiddleCenter);
            crosshair.text="+"; crosshair.color=new Color(1f,1f,1f,.88f);
        }
        Text MakeText(Transform parent,string name,Vector2 anchor,Vector2 pivot,Vector2 pos,Vector2 size,int font,TextAnchor align)
        { var g=new GameObject(name,typeof(RectTransform),typeof(Text)); g.transform.SetParent(parent,false); var r=g.GetComponent<RectTransform>(); r.anchorMin=r.anchorMax=anchor; r.pivot=pivot; r.anchoredPosition=pos; r.sizeDelta=size; var t=g.GetComponent<Text>(); t.font=Resources.GetBuiltinResource<Font>("Arial.ttf"); t.fontSize=font; t.color=Color.white; t.alignment=align; t.horizontalOverflow=HorizontalWrapMode.Wrap; t.verticalOverflow=VerticalWrapMode.Overflow; t.supportRichText=true; return t; }
        void MakeHoldButton(Transform parent,string label,Vector2 anchor,Vector2 pos,Vector2 size)
        {
            var g=new GameObject(label+" Button",typeof(RectTransform),typeof(Image),typeof(Button),typeof(EventTrigger));g.transform.SetParent(parent,false);
            var r=g.GetComponent<RectTransform>();r.anchorMin=r.anchorMax=anchor;r.pivot=new Vector2(1,0);r.anchoredPosition=pos;r.sizeDelta=size;
            g.GetComponent<Image>().color=new Color(.45f,.08f,.06f,.82f);
            var t=MakeText(g.transform,label,new Vector2(.5f,.5f),new Vector2(.5f,.5f),Vector2.zero,size,24,TextAnchor.MiddleCenter);t.color=Color.white;
            var trigger=g.GetComponent<EventTrigger>();trigger.triggers=new List<EventTrigger.Entry>();
            var down=new EventTrigger.Entry{eventID=EventTriggerType.PointerDown};down.callback.AddListener((data)=>{if(Player){var shooter=Player.GetComponent<PlayerShooter>();if(shooter)shooter.SetFireHeld(true);}});trigger.triggers.Add(down);
            var up=new EventTrigger.Entry{eventID=EventTriggerType.PointerUp};up.callback.AddListener((data)=>{if(Player){var shooter=Player.GetComponent<PlayerShooter>();if(shooter)shooter.SetFireHeld(false);}});trigger.triggers.Add(up);
            var exit=new EventTrigger.Entry{eventID=EventTriggerType.PointerExit};exit.callback.AddListener((data)=>{if(Player){var shooter=Player.GetComponent<PlayerShooter>();if(shooter)shooter.SetFireHeld(false);}});trigger.triggers.Add(exit);
        }
        void MakeButton(Transform parent,string label,Vector2 anchor,Vector2 pos,Vector2 size,UnityEngine.Events.UnityAction action)
        { var g=new GameObject(label+" Button",typeof(RectTransform),typeof(Image),typeof(Button)); g.transform.SetParent(parent,false); var r=g.GetComponent<RectTransform>(); r.anchorMin=r.anchorMax=anchor; r.pivot=new Vector2(1,0); r.anchoredPosition=pos; r.sizeDelta=size; g.GetComponent<Image>().color=new Color(.05f,.12f,.18f,.75f); g.GetComponent<Button>().onClick.AddListener(action); var t=MakeText(g.transform,label,new Vector2(.5f,.5f),new Vector2(.5f,.5f),Vector2.zero,size,24,TextAnchor.MiddleCenter); t.color=Color.white; }
        GameObject Create(PrimitiveType type,string name,Vector3 pos,Vector3 scale,Color color)
        {
            var g=GameObject.CreatePrimitive(type); g.name=name; g.transform.position=pos; g.transform.localScale=scale;
            var r=g.GetComponent<Renderer>();
            if(r)
            {
                Shader shader=Shader.Find("Standard"); if(shader==null) shader=Shader.Find("Universal Render Pipeline/Lit");
                if(shader!=null) { var m=new Material(shader); m.color=color; r.sharedMaterial=m; }
                r.shadowCastingMode=UnityEngine.Rendering.ShadowCastingMode.On;
                r.receiveShadows=true;
            }
            return g;
        }
    }
}
