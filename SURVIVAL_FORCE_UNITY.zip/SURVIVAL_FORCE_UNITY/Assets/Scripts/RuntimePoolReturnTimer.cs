using UnityEngine;

namespace SurvivalForce
{
    /// <summary>Attach to pooled effects to return them automatically after a short lifetime.</summary>
    public sealed class RuntimePoolReturnTimer : MonoBehaviour
    {
        [SerializeField, Min(.01f)] float lifetime = 2f;
        float expiresAt;
        void OnEnable() { expiresAt = Time.time + lifetime; }
        void Update()
        {
            if (Time.time < expiresAt) return;
            PooledObject pooled = GetComponent<PooledObject>();
            if (pooled) pooled.Release(); else gameObject.SetActive(false);
        }
        public void SetLifetime(float seconds) { lifetime = Mathf.Max(.01f, seconds); expiresAt = Time.time + lifetime; }
    }
}
