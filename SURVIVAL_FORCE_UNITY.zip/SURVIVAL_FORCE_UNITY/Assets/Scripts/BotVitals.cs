using UnityEngine;
namespace SurvivalForce
{
    public class BotVitals : MonoBehaviour
    {
        public OfflineBot Owner;
        public float MaxHealth = 100f;
        public float Health = 100f;
        public bool Dead { get { return Health <= 0f; } }
        public void Damage(float value)
        {
            if (Dead || value <= 0f) return;
            Health = Mathf.Max(0f, Health - value);
            if (Health <= 0f) { if (Owner) Owner.Kill(); else Destroy(gameObject); }
        }
    }
}
