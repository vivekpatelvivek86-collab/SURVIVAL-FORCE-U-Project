using UnityEngine;
namespace SurvivalForce
{
    public class SafeZoneController : MonoBehaviour
    {
        public static float CurrentRadius { get; private set; } = 205f;
        public static Vector3 CurrentCenter { get; private set; }
        public Transform Player;
        public float StartRadius = 205f, EndRadius = 16f, WaitSeconds = 35f, ShrinkSeconds = 300f, OutsideDamage = 5f;
        float elapsed, damageTick;
        void OnEnable() { CurrentRadius = StartRadius; CurrentCenter = transform.position; }
        void Update()
        {
            elapsed += Time.deltaTime;
            float t = Mathf.Clamp01((elapsed - WaitSeconds) / Mathf.Max(1f, ShrinkSeconds));
            float radius = Mathf.Lerp(StartRadius, EndRadius, t);
            CurrentRadius = radius; CurrentCenter = transform.position;
            transform.localScale = new Vector3(radius * 2f, .05f, radius * 2f);
            if (elapsed <= WaitSeconds) return;
            damageTick += Time.deltaTime;
            if (damageTick < 1f) return;
            damageTick = 0f;
            if (Player && Outside(Player.position, radius))
            {
                var vitals = Player.GetComponent<PlayerVitals>(); if (vitals) vitals.Damage(OutsideDamage);
            }
            OfflineBot[] bots = Object.FindObjectsOfType<OfflineBot>();
            for (int i = 0; i < bots.Length; i++)
            {
                if (!bots[i] || bots[i].IsDead || !Outside(bots[i].transform.position, radius)) continue;
                var vitals = bots[i].GetComponent<BotVitals>(); if (vitals) vitals.Damage(OutsideDamage * .85f);
            }
        }
        bool Outside(Vector3 position, float radius)
        {
            Vector2 p = new Vector2(position.x - transform.position.x, position.z - transform.position.z);
            return p.sqrMagnitude > radius * radius;
        }
    }
}
