using System;
using UnityEngine;

namespace SurvivalForce
{
    [Flags] public enum WeaponAttachmentSlot { None = 0, Muzzle = 1, Optic = 2, Magazine = 4, Grip = 8, Stock = 16 }
    [Serializable] public class WeaponAttachmentState
    {
        public WeaponAttachmentSlot Slot;
        public string AttachmentId;
        public float DamageMultiplier = 1f;
        public float SpreadMultiplier = 1f;
        public float ReloadMultiplier = 1f;
        public int ExtraMagazine;
    }
    /// <summary>Runtime attachment modifiers; content is supplied by the project owner.</summary>
    public sealed class WeaponAttachmentSystem : MonoBehaviour
    {
        [SerializeField] WeaponAttachmentState[] attachments = new WeaponAttachmentState[0];
        public float DamageMultiplier { get; private set; } = 1f;
        public float SpreadMultiplier { get; private set; } = 1f;
        public float ReloadMultiplier { get; private set; } = 1f;
        public int ExtraMagazine { get; private set; }
        public event Action Changed;
        public bool Equip(WeaponAttachmentState item)
        {
            if (item == null || item.Slot == WeaponAttachmentSlot.None) return false;
            for (int i = 0; i < attachments.Length; i++) if (attachments[i] != null && attachments[i].Slot == item.Slot) { attachments[i] = item; Recalculate(); return true; }
            Array.Resize(ref attachments, attachments.Length + 1); attachments[attachments.Length - 1] = item; Recalculate(); return true;
        }
        public bool Remove(WeaponAttachmentSlot slot)
        {
            for (int i = 0; i < attachments.Length; i++) if (attachments[i] != null && attachments[i].Slot == slot) { attachments[i] = null; Recalculate(); return true; }
            return false;
        }
        void Recalculate()
        {
            DamageMultiplier = SpreadMultiplier = ReloadMultiplier = 1f; ExtraMagazine = 0;
            for (int i = 0; i < attachments.Length; i++) { WeaponAttachmentState a = attachments[i]; if (a == null) continue; DamageMultiplier *= Mathf.Clamp(a.DamageMultiplier, .25f, 3f); SpreadMultiplier *= Mathf.Clamp(a.SpreadMultiplier, .2f, 2f); ReloadMultiplier *= Mathf.Clamp(a.ReloadMultiplier, .25f, 3f); ExtraMagazine += Mathf.Clamp(a.ExtraMagazine, 0, 100); }
            Changed?.Invoke();
        }
    }
}
