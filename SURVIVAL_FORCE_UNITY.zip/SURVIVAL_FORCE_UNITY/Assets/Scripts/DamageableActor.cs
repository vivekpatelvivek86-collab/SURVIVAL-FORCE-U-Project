using System;
using UnityEngine;

namespace SurvivalForce
{
    /// <summary>Generic damage interface adapter for props and training targets.</summary>
    public sealed class DamageableActor : MonoBehaviour
    {
        [SerializeField, Min(1)] float maxHealth = 100f;
        [SerializeField] bool destroyOnDeath;
        [SerializeField] GameObject deathEffect;
        public float Health { get; private set; }
        public bool IsDead { get; private set; }
        public event Action<float, float> HealthChanged;
        public event Action Died;
        void Awake() { Health = maxHealth; }
        public void ApplyDamage(float amount, Transform source = null)
        {
            if (IsDead || amount <= 0) return;
            float applied = Mathf.Min(Health, amount); Health -= applied;
            HealthChanged?.Invoke(Health, maxHealth); GameEventBus.RaiseDamage(source, transform, applied);
            if (Health > 0) return;
            IsDead = true; Died?.Invoke(); GameEventBus.RaiseElimination(source, transform);
            if (deathEffect) Instantiate(deathEffect, transform.position, Quaternion.identity);
            if (destroyOnDeath) Destroy(gameObject);
        }
        public void Restore(float amount) { if (IsDead || amount <= 0) return; Health = Mathf.Min(maxHealth, Health + amount); HealthChanged?.Invoke(Health, maxHealth); }
        public void ResetActor() { IsDead = false; Health = maxHealth; HealthChanged?.Invoke(Health, maxHealth); }
    }
}
