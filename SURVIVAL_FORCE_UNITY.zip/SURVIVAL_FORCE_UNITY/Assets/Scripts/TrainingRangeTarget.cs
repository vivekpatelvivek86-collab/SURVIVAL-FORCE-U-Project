using UnityEngine;

namespace SurvivalForce
{
    /// <summary>Reusable target dummy with hit counts and reset support for weapon tuning.</summary>
    public sealed class TrainingRangeTarget : MonoBehaviour
    {
        [SerializeField, Min(1)] float targetHealth = 100f;
        [SerializeField] bool respawn = true;
        [SerializeField, Min(.1f)] float respawnDelay = 2f;
        float health;
        float respawnAt;
        public int HitsReceived { get; private set; }
        public float TotalDamageReceived { get; private set; }
        public bool Down { get; private set; }
        void Awake() { health = targetHealth; }
        void Update() { if (Down && respawn && Time.time >= respawnAt) ResetTarget(); }
        public void Hit(float damage, bool headshot = false)
        {
            if (Down || damage <= 0) return;
            float actual = headshot ? damage * 1.5f : damage;
            health = Mathf.Max(0, health - actual); HitsReceived++; TotalDamageReceived += actual;
            if (health <= 0) { Down = true; respawnAt = Time.time + respawnDelay; }
        }
        public void ResetTarget() { health = targetHealth; Down = false; }
        public void ResetStats() { HitsReceived = 0; TotalDamageReceived = 0; ResetTarget(); }
    }
}
