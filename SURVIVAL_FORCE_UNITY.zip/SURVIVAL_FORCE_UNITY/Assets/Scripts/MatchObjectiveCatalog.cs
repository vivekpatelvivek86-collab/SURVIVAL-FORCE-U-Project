using System.Collections.Generic;

namespace SurvivalForce
{
    /// <summary>Reusable local match challenges. Values are game design defaults, not external assets.</summary>
    public static class MatchObjectiveCatalog
    {
        public static List<MatchObjective> CreateStandardSet()
        {
            return new List<MatchObjective>
            {
                Make("first_elimination", "First Elimination", ObjectiveKind.EliminateBots, 1, 50),
                Make("scavenger", "Scavenger", ObjectiveKind.CollectItems, 5, 35),
                Make("survivor_60", "Stay Alive", ObjectiveKind.SurviveSeconds, 60, 60),
                Make("survivor_180", "Battle Hardened", ObjectiveKind.SurviveSeconds, 180, 120),
                Make("triple_elimination", "Triple Threat", ObjectiveKind.EliminateBots, 3, 100)
            };
        }
        static MatchObjective Make(string id, string title, ObjectiveKind kind, int count, int coins)
        { return new MatchObjective { Id = id, Title = title, Kind = kind, RequiredCount = count, RewardCoins = coins }; }
    }
}
