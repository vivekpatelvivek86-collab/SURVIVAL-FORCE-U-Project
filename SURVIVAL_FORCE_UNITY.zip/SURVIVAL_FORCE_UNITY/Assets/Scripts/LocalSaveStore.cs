using System;
using UnityEngine;

namespace SurvivalForce
{
    [Serializable]
    public class LocalPlayerSave
    {
        public int SchemaVersion = 1;
        public string PlayerName = "Survivor";
        public int Level = 1;
        public int Experience;
        public int Coins = 500;
        public int LifetimeKills;
        public int MatchesPlayed;
        public int MatchesWon;
        public string EquippedOutfit = "Default";
    }
    /// <summary>Versioned JSON save wrapper with safe defaults and explicit migration hook.</summary>
    public static class LocalSaveStore
    {
        const string Key = "SF_LOCAL_SAVE_V1";
        public static LocalPlayerSave Load()
        {
            string json = PlayerPrefs.GetString(Key, string.Empty);
            if (string.IsNullOrEmpty(json)) return new LocalPlayerSave();
            try
            {
                LocalPlayerSave save = JsonUtility.FromJson<LocalPlayerSave>(json);
                if (save == null) return new LocalPlayerSave();
                Migrate(save);
                return save;
            }
            catch (Exception ex) { Debug.LogWarning("SURVIVAL FORCE save reset: " + ex.Message); return new LocalPlayerSave(); }
        }
        public static void Save(LocalPlayerSave save)
        {
            if (save == null) return;
            save.SchemaVersion = 1;
            PlayerPrefs.SetString(Key, JsonUtility.ToJson(save));
            PlayerPrefs.Save();
        }
        static void Migrate(LocalPlayerSave save)
        {
            save.Level = Mathf.Max(1, save.Level);
            save.Experience = Mathf.Max(0, save.Experience);
            save.Coins = Mathf.Max(0, save.Coins);
            save.LifetimeKills = Mathf.Max(0, save.LifetimeKills);
            save.MatchesPlayed = Mathf.Max(0, save.MatchesPlayed);
            save.MatchesWon = Mathf.Clamp(save.MatchesWon, 0, save.MatchesPlayed);
            if (string.IsNullOrWhiteSpace(save.PlayerName)) save.PlayerName = "Survivor";
            if (string.IsNullOrWhiteSpace(save.EquippedOutfit)) save.EquippedOutfit = "Default";
        }
        public static void Delete() { PlayerPrefs.DeleteKey(Key); PlayerPrefs.Save(); }
    }
}
