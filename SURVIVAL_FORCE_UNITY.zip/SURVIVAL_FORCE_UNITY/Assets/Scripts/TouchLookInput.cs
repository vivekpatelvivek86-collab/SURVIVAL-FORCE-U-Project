using UnityEngine;

namespace SurvivalForce
{
    /// <summary>Input adapter for UI pointer deltas. A mobile UI can feed deltas without polling desktop input.</summary>
    public sealed class TouchLookInput : MonoBehaviour
    {
        [SerializeField] string sensitivityKey = "General";
        [SerializeField, Min(.01f)] float baseSensitivity = 1f;
        [SerializeField] bool invertY;
        Vector2 pendingDelta;
        public Vector2 ConsumeDelta()
        {
            Vector2 value = pendingDelta; pendingDelta = Vector2.zero;
            float sensitivity = GameSettingsStore.GetSensitivity(sensitivityKey, baseSensitivity);
            value *= sensitivity;
            if (invertY) value.y = -value.y;
            return value;
        }
        public void PushDelta(Vector2 delta) { pendingDelta += Vector2.ClampMagnitude(delta, 200f); }
        public void SetScope(string scope) { if (!string.IsNullOrEmpty(scope)) sensitivityKey = scope; }
        public void SetInvertY(bool value) { invertY = value; }
        public void Clear() { pendingDelta = Vector2.zero; }
    }
}
