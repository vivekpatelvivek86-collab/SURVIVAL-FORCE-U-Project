using System.Collections.Generic;
using UnityEngine;

namespace SurvivalForce
{
    /// <summary>
    /// Runtime-built original humanoid skeleton and legacy Animation clips.
    /// Uses original primitive geometry; no third-party or Free Fire assets are bundled.
    /// </summary>
    public class ProceduralCharacterVisuals : MonoBehaviour
    {
        public bool IsPlayer;
        public int OutfitIndex;

        Transform rig, pelvis, spine, neck, head, leftUpperArm, leftForearm, leftHand,
            rightUpperArm, rightForearm, rightHand, leftThigh, leftCalf, leftFoot,
            rightThigh, rightCalf, rightFoot, weaponSocket, weapon, muzzleFlash;
        readonly List<Transform> skinBones = new List<Transform>();
        CharacterController controller;
        OfflineBot bot;
        PlayerShooter shooter;
        PlayerMotor motor;
        Animation legacyAnimation;
        Animator externalAnimator;
        GameObject externalModel;
        readonly HashSet<string> animatorParameters = new HashSet<string>();
        bool previousFireState, previousReloadState;
        Vector3 lastPosition;
        bool wasGrounded = true;
        string baseClip = "", actionClip = "";
        float lastFireTime = -10f;
        WeaponArchetype weaponType = WeaponArchetype.AssaultRifle;
        Color outfit;

        static readonly Dictionary<Color32, Material> SharedMaterials = new Dictionary<Color32, Material>();

        void Start()
        {
            controller = GetComponent<CharacterController>();
            bot = GetComponent<OfflineBot>();
            shooter = GetComponent<PlayerShooter>();
            motor = GetComponent<PlayerMotor>();
            if (shooter) weaponType = shooter.WeaponType;

            Color[] playerOutfits = {
                new Color(.12f,.38f,.62f), new Color(.62f,.39f,.18f),
                new Color(.20f,.24f,.30f), new Color(.12f,.42f,.28f)
            };
            outfit = IsPlayer ? playerOutfits[Mathf.Clamp(OutfitIndex, 0, playerOutfits.Length - 1)] : new Color(.48f,.16f,.13f);
            Renderer oldRenderer = GetComponent<Renderer>();
            if (oldRenderer) oldRenderer.enabled = false;

            // Optional legal third-party model drop-in. Put a configured prefab at
            // Assets/Resources/Characters/SF_Humanoid.prefab. The procedural survivor
            // remains the safe fallback when no imported model is present.
            GameObject importedPrefab = Resources.Load<GameObject>("Characters/SF_Humanoid");
            if (importedPrefab)
            {
                externalModel = Instantiate(importedPrefab, transform);
                externalModel.name = "Imported Humanoid Visual";
                externalModel.transform.localPosition = Vector3.zero;
                externalModel.transform.localRotation = Quaternion.identity;
                externalModel.transform.localScale = Vector3.one;
                externalAnimator = externalModel.GetComponentInChildren<Animator>(true);
                RuntimeAnimatorController importedController = Resources.Load<RuntimeAnimatorController>("Characters/SF_HumanoidController");
                if (externalAnimator && importedController) externalAnimator.runtimeAnimatorController = importedController;
                if (externalAnimator && externalAnimator.runtimeAnimatorController)
                {
                    externalAnimator.applyRootMotion = false;
                    foreach (AnimatorControllerParameter parameter in externalAnimator.parameters) animatorParameters.Add(parameter.name);
                    lastPosition = transform.position;
                    return;
                }
                Destroy(externalModel);
                externalModel = null;
            }

            BuildHumanoidRig();
            BuildSkinnedBody();
            BuildWeapon();
            BuildAnimationClips();
            lastPosition = transform.position;
        }

        void BuildHumanoidRig()
        {
            rig = new GameObject("Rig").transform;
            rig.SetParent(transform, false);
            pelvis = Bone("Pelvis", rig, new Vector3(0, .88f, 0));
            Part("Hip armor", PrimitiveType.Cube, pelvis, new Vector3(0, -.015f, 0), new Vector3(.30f,.20f,.20f), new Color(.12f,.14f,.14f));
            spine = Bone("Spine", pelvis, new Vector3(0, .10f, 0));
            Part("Torso", PrimitiveType.Capsule, spine, new Vector3(0,.14f,0), new Vector3(.30f,.31f,.20f), outfit);
            Part("Tactical vest", PrimitiveType.Cube, spine, new Vector3(0,.15f,.025f), new Vector3(.32f,.26f,.215f), IsPlayer ? new Color(.10f,.20f,.24f) : new Color(.23f,.18f,.15f));
            Part("Chest plate", PrimitiveType.Cube, spine, new Vector3(0,.19f,.139f), new Vector3(.20f,.14f,.025f), new Color(.22f,.25f,.23f));
            Part("Backpack", PrimitiveType.Cube, spine, new Vector3(0,.10f,-.145f), new Vector3(.22f,.30f,.13f), new Color(.16f,.20f,.16f));
            neck = Bone("Neck", spine, new Vector3(0,.32f,0));
            Part("Neck", PrimitiveType.Cylinder, neck, Vector3.zero, new Vector3(.075f,.065f,.075f), new Color(.63f,.45f,.34f));
            head = Bone("Head", neck, new Vector3(0,.12f,0));
            Part("Head mesh", PrimitiveType.Sphere, head, Vector3.zero, new Vector3(.16f,.18f,.15f), new Color(.72f,.55f,.42f));
            Part("Helmet", PrimitiveType.Sphere, head, new Vector3(0,.085f,-.005f), new Vector3(.18f,.105f,.17f), new Color(.15f,.19f,.17f));
            Part("Helmet rim", PrimitiveType.Cube, head, new Vector3(0,.035f,.035f), new Vector3(.18f,.025f,.13f), new Color(.20f,.23f,.20f));

            leftThigh = Bone("LeftThigh", pelvis, new Vector3(-.13f,-.06f,0));
            Part("Left thigh", PrimitiveType.Capsule, leftThigh, new Vector3(0,-.17f,0), new Vector3(.13f,.22f,.13f), new Color(.12f,.13f,.15f));
            leftCalf = Bone("LeftCalf", leftThigh, new Vector3(0,-.34f,0));
            Part("Left shin", PrimitiveType.Capsule, leftCalf, new Vector3(0,-.15f,0), new Vector3(.095f,.18f,.10f), new Color(.16f,.17f,.17f));
            leftFoot = Bone("LeftFoot", leftCalf, new Vector3(0,-.30f,0));
            Part("Left boot", PrimitiveType.Cube, leftFoot, new Vector3(0,-.025f,.055f), new Vector3(.12f,.07f,.19f), new Color(.08f,.09f,.08f));

            rightThigh = Bone("RightThigh", pelvis, new Vector3(.13f,-.06f,0));
            Part("Right thigh", PrimitiveType.Capsule, rightThigh, new Vector3(0,-.17f,0), new Vector3(.13f,.22f,.13f), new Color(.12f,.13f,.15f));
            rightCalf = Bone("RightCalf", rightThigh, new Vector3(0,-.34f,0));
            Part("Right shin", PrimitiveType.Capsule, rightCalf, new Vector3(0,-.15f,0), new Vector3(.095f,.18f,.10f), new Color(.16f,.17f,.17f));
            rightFoot = Bone("RightFoot", rightCalf, new Vector3(0,-.30f,0));
            Part("Right boot", PrimitiveType.Cube, rightFoot, new Vector3(0,-.025f,.055f), new Vector3(.12f,.07f,.19f), new Color(.08f,.09f,.08f));

            leftUpperArm = Bone("LeftUpperArm", spine, new Vector3(-.19f,.24f,0));
            Part("Left shoulder pad", PrimitiveType.Sphere, leftUpperArm, new Vector3(0,-.045f,0), new Vector3(.13f,.13f,.13f), new Color(.17f,.20f,.19f));
            Part("Left upper arm", PrimitiveType.Capsule, leftUpperArm, new Vector3(0,-.15f,0), new Vector3(.095f,.18f,.095f), outfit);
            leftForearm = Bone("LeftForearm", leftUpperArm, new Vector3(0,-.29f,0));
            Part("Left forearm", PrimitiveType.Capsule, leftForearm, new Vector3(0,-.13f,.015f), new Vector3(.075f,.15f,.08f), outfit);
            leftHand = Bone("LeftHand", leftForearm, new Vector3(0,-.25f,.025f));
            Part("Left glove", PrimitiveType.Sphere, leftHand, Vector3.zero, new Vector3(.075f,.075f,.075f), new Color(.12f,.13f,.12f));

            rightUpperArm = Bone("RightUpperArm", spine, new Vector3(.19f,.24f,0));
            Part("Right shoulder pad", PrimitiveType.Sphere, rightUpperArm, new Vector3(0,-.045f,0), new Vector3(.13f,.13f,.13f), new Color(.17f,.20f,.19f));
            Part("Right upper arm", PrimitiveType.Capsule, rightUpperArm, new Vector3(0,-.15f,0), new Vector3(.095f,.18f,.095f), outfit);
            rightForearm = Bone("RightForearm", rightUpperArm, new Vector3(0,-.29f,0));
            Part("Right forearm", PrimitiveType.Capsule, rightForearm, new Vector3(0,-.13f,.015f), new Vector3(.075f,.15f,.08f), outfit);
            rightHand = Bone("RightHand", rightForearm, new Vector3(0,-.25f,.025f));
            Part("Right glove", PrimitiveType.Sphere, rightHand, Vector3.zero, new Vector3(.075f,.075f,.075f), new Color(.12f,.13f,.12f));
        }

        // Merge the original primitive body pieces into one SkinnedMeshRenderer. Each
        // piece is rigid-weighted to its owning bone, so animation deforms the combined
        // mesh through a real Unity skinning pipeline instead of drawing every primitive.
        void BuildSkinnedBody()
        {
            if (!rig || skinBones.Count == 0) return;
            MeshFilter[] filters = rig.GetComponentsInChildren<MeshFilter>(true);
            var materialIndices = new Dictionary<Material, int>();
            var materials = new List<Material>();
            var vertices = new List<Vector3>();
            var normals = new List<Vector3>();
            var uv = new List<Vector2>();
            var weights = new List<BoneWeight>();
            var trianglesByMaterial = new List<List<int>>();
            var boneIndices = new Dictionary<Transform, int>();
            for (int i = 0; i < skinBones.Count; i++) boneIndices[skinBones[i]] = i;

            foreach (MeshFilter filter in filters)
            {
                if (!filter || !filter.sharedMesh) continue;
                Mesh source = filter.sharedMesh;
                Renderer sourceRenderer = filter.GetComponent<Renderer>();
                if (!sourceRenderer) continue;
                Transform owner = filter.transform.parent;
                while (owner && owner != rig && !boneIndices.ContainsKey(owner)) owner = owner.parent;
                if (!owner || !boneIndices.ContainsKey(owner)) continue;
                int boneIndex = boneIndices[owner];
                int offset = vertices.Count;
                Matrix4x4 toRig = rig.worldToLocalMatrix * filter.transform.localToWorldMatrix;
                Matrix4x4 normalMatrix = toRig.inverse.transpose;
                Vector3[] sourceVertices = source.vertices;
                Vector3[] sourceNormals = source.normals;
                Vector2[] sourceUv = source.uv;
                for (int v = 0; v < sourceVertices.Length; v++)
                {
                    vertices.Add(toRig.MultiplyPoint3x4(sourceVertices[v]));
                    normals.Add(sourceNormals != null && sourceNormals.Length == sourceVertices.Length
                        ? normalMatrix.MultiplyVector(sourceNormals[v]).normalized : Vector3.up);
                    uv.Add(sourceUv != null && sourceUv.Length == sourceVertices.Length ? sourceUv[v] : Vector2.zero);
                    weights.Add(new BoneWeight { boneIndex0 = boneIndex, weight0 = 1f });
                }

                Material[] sourceMaterials = sourceRenderer.sharedMaterials;
                for (int sub = 0; sub < source.subMeshCount; sub++)
                {
                    Material material = sourceMaterials.Length > sub ? sourceMaterials[sub] : sourceRenderer.sharedMaterial;
                    if (!materialIndices.TryGetValue(material, out int materialIndex))
                    {
                        materialIndex = materials.Count;
                        materialIndices.Add(material, materialIndex);
                        materials.Add(material);
                        trianglesByMaterial.Add(new List<int>());
                    }
                    int[] sourceTriangles = source.GetTriangles(sub);
                    List<int> destination = trianglesByMaterial[materialIndex];
                    for (int t = 0; t < sourceTriangles.Length; t++) destination.Add(offset + sourceTriangles[t]);
                }
                sourceRenderer.enabled = false;
            }

            if (vertices.Count == 0) return;
            Mesh skinnedMesh = new Mesh { name = "SF_RigidWeighted_HumanoidMesh" };
            if (vertices.Count > 65000) skinnedMesh.indexFormat = UnityEngine.Rendering.IndexFormat.UInt32;
            skinnedMesh.SetVertices(vertices);
            skinnedMesh.SetNormals(normals);
            skinnedMesh.SetUVs(0, uv);
            skinnedMesh.boneWeights = weights.ToArray();
            skinnedMesh.subMeshCount = trianglesByMaterial.Count;
            for (int i = 0; i < trianglesByMaterial.Count; i++) skinnedMesh.SetTriangles(trianglesByMaterial[i], i, false);
            var bindPoses = new Matrix4x4[skinBones.Count];
            for (int i = 0; i < skinBones.Count; i++) bindPoses[i] = skinBones[i].worldToLocalMatrix * rig.localToWorldMatrix;
            skinnedMesh.bindposes = bindPoses;
            skinnedMesh.RecalculateBounds();
            SkinnedMeshRenderer skin = rig.gameObject.AddComponent<SkinnedMeshRenderer>();
            skin.sharedMesh = skinnedMesh;
            skin.bones = skinBones.ToArray();
            skin.rootBone = pelvis;
            skin.sharedMaterials = materials.ToArray();
            skin.updateWhenOffscreen = false;
        }

        void BuildWeapon()
        {
            weaponSocket = Bone("WeaponSocket", rightHand, new Vector3(-.04f,.045f,.07f));
            weapon = Bone("WeaponModel", weaponSocket, new Vector3(-.025f,.025f,.075f));
            Color metal = new Color(.075f,.085f,.078f), polymer = new Color(.16f,.15f,.12f);
            Part("Receiver", PrimitiveType.Cube, weapon, new Vector3(0,0,.07f), new Vector3(.105f,.10f,.28f), metal);
            Part("Handguard", PrimitiveType.Cube, weapon, new Vector3(0,.005f,.25f), new Vector3(.085f,.085f,.20f), polymer);
            float barrelLength = weaponType == WeaponArchetype.MarksmanRifle ? .52f : weaponType == WeaponArchetype.SMG ? .24f : .39f;
            Part("Barrel", PrimitiveType.Cylinder, weapon, new Vector3(0,.005f,.35f + (barrelLength-.39f)*.5f), new Vector3(.018f,barrelLength*.5f,.018f), metal).localRotation = Quaternion.Euler(90,0,0);
            Part("Stock", PrimitiveType.Cube, weapon, new Vector3(0,-.015f,-.13f), new Vector3(.07f,.075f,.18f), polymer);
            Part("Magazine", PrimitiveType.Cube, weapon, new Vector3(0,-.09f,.06f), new Vector3(.055f,weaponType == WeaponArchetype.MarksmanRifle ? .12f : .15f,.07f), metal);
            Part("Top rail", PrimitiveType.Cube, weapon, new Vector3(0,.065f,.10f), new Vector3(.035f,.018f,.25f), metal);
            if (weaponType == WeaponArchetype.MarksmanRifle)
                Part("Optic", PrimitiveType.Cylinder, weapon, new Vector3(0,.105f,.08f), new Vector3(.035f,.07f,.035f), new Color(.12f,.18f,.14f));
            muzzleFlash = Part("Muzzle flash", PrimitiveType.Sphere, weapon, new Vector3(0,0,.56f + (barrelLength-.39f)*.5f), Vector3.one*.001f, new Color(1f,.62f,.12f));
        }

        Transform Bone(string name, Transform parent, Vector3 localPosition)
        {
            Transform t = new GameObject(name).transform;
            t.SetParent(parent, false); t.localPosition = localPosition; t.localRotation = Quaternion.identity; t.localScale = Vector3.one;
            if (name != "WeaponSocket" && name != "WeaponModel") skinBones.Add(t);
            return t;
        }

        Transform Part(string name, PrimitiveType type, Transform parent, Vector3 localPosition, Vector3 localScale, Color color)
        {
            GameObject go = GameObject.CreatePrimitive(type); go.name = name; go.transform.SetParent(parent, false);
            go.transform.localPosition = localPosition; go.transform.localScale = localScale;
            Collider col = go.GetComponent<Collider>(); if (col) Destroy(col);
            Renderer renderer = go.GetComponent<Renderer>(); if (renderer) renderer.sharedMaterial = MaterialFor(color);
            return go.transform;
        }

        static Material MaterialFor(Color color)
        {
            Color32 key = color;
            if (SharedMaterials.TryGetValue(key, out Material found) && found) return found;
            Shader shader = Shader.Find("Standard");
            if (!shader) shader = Shader.Find("Universal Render Pipeline/Lit");
            Material mat = new Material(shader) { color = color };
            SharedMaterials[key] = mat;
            return mat;
        }

        void BuildAnimationClips()
        {
            legacyAnimation = gameObject.AddComponent<Animation>();
            legacyAnimation.playAutomatically = false;
            legacyAnimation.cullingType = AnimationCullingType.BasedOnRenderers;
            AddBaseClip("Idle", 1f, (clip) => {
                AddSin(clip, "Rig/Pelvis/Spine", "localEulerAnglesRaw.x", 1.0f, 1.2f);
                AddSin(clip, "Rig/Pelvis/Spine", "localEulerAnglesRaw.z", 1.0f, .7f);
                AddSin(clip, "Rig/Pelvis/Spine/Neck/Head", "localEulerAnglesRaw.y", 1f, 1.5f);
                AddConst(clip, "Rig/Pelvis", "localPosition.y", .88f);
            });
            AddBaseClip("Walk", 1f, (clip) => {
                AddSin(clip,"Rig/Pelvis/LeftThigh","localEulerAnglesRaw.x",1f,28f);
                AddSin(clip,"Rig/Pelvis/RightThigh","localEulerAnglesRaw.x",1f,-28f);
                AddSineHalf(clip,"Rig/Pelvis/LeftThigh/LeftCalf","localEulerAnglesRaw.x",1f,18f);
                AddSineHalf(clip,"Rig/Pelvis/RightThigh/RightCalf","localEulerAnglesRaw.x",1f,18f, .5f);
                AddSin(clip,"Rig/Pelvis/Spine/LeftUpperArm","localEulerAnglesRaw.x",1f,-17f);
                AddSin(clip,"Rig/Pelvis/Spine/RightUpperArm","localEulerAnglesRaw.x",1f,17f);
                AddConst(clip,"Rig/Pelvis","localPosition.y",.88f);
            });
            AddBaseClip("Run", .72f, (clip) => {
                AddSin(clip,"Rig/Pelvis/LeftThigh","localEulerAnglesRaw.x",.72f,48f);
                AddSin(clip,"Rig/Pelvis/RightThigh","localEulerAnglesRaw.x",.72f,-48f);
                AddSineHalf(clip,"Rig/Pelvis/LeftThigh/LeftCalf","localEulerAnglesRaw.x",.72f,38f);
                AddSineHalf(clip,"Rig/Pelvis/RightThigh/RightCalf","localEulerAnglesRaw.x",.72f,38f,.5f);
                AddSin(clip,"Rig/Pelvis/Spine/LeftUpperArm","localEulerAnglesRaw.x",.72f,-30f);
                AddSin(clip,"Rig/Pelvis/Spine/RightUpperArm","localEulerAnglesRaw.x",.72f,30f);
                AddConst(clip,"Rig/Pelvis","localPosition.y",.88f);
                AddConst(clip,"Rig/Pelvis/Spine","localEulerAnglesRaw.x",8f);
            });
            AddBaseClip("StrafeLeft", .82f, (clip) => {
                AddSin(clip,"Rig/Pelvis/LeftThigh","localEulerAnglesRaw.x",.82f,20f);
                AddSin(clip,"Rig/Pelvis/RightThigh","localEulerAnglesRaw.x",.82f,-20f);
                AddSin(clip,"Rig/Pelvis/LeftThigh","localEulerAnglesRaw.y",.82f,-9f);
                AddSin(clip,"Rig/Pelvis/RightThigh","localEulerAnglesRaw.y",.82f,-9f);
                AddConst(clip,"Rig/Pelvis/Spine","localEulerAnglesRaw.y",-7f);
                AddConst(clip,"Rig/Pelvis","localPosition.y",.88f);
            });
            AddBaseClip("StrafeRight", .82f, (clip) => {
                AddSin(clip,"Rig/Pelvis/LeftThigh","localEulerAnglesRaw.x",.82f,-20f);
                AddSin(clip,"Rig/Pelvis/RightThigh","localEulerAnglesRaw.x",.82f,20f);
                AddSin(clip,"Rig/Pelvis/LeftThigh","localEulerAnglesRaw.y",.82f,9f);
                AddSin(clip,"Rig/Pelvis/RightThigh","localEulerAnglesRaw.y",.82f,9f);
                AddConst(clip,"Rig/Pelvis/Spine","localEulerAnglesRaw.y",7f);
                AddConst(clip,"Rig/Pelvis","localPosition.y",.88f);
            });
            AddBaseClip("Backpedal", .9f, (clip) => {
                AddSin(clip,"Rig/Pelvis/LeftThigh","localEulerAnglesRaw.x",.9f,-18f);
                AddSin(clip,"Rig/Pelvis/RightThigh","localEulerAnglesRaw.x",.9f,18f);
                AddConst(clip,"Rig/Pelvis/Spine","localEulerAnglesRaw.x",-4f);
                AddConst(clip,"Rig/Pelvis/Spine/LeftUpperArm","localEulerAnglesRaw.x",-12f);
                AddConst(clip,"Rig/Pelvis/Spine/RightUpperArm","localEulerAnglesRaw.x",12f);
                AddConst(clip,"Rig/Pelvis","localPosition.y",.88f);
            });
            AddBaseClip("Jump", .5f, (clip) => {
                AddKeys(clip,"Rig/Pelvis/LeftThigh","localEulerAnglesRaw.x",new Keyframe(0,-18),new Keyframe(.25f,-38),new Keyframe(.5f,-10));
                AddKeys(clip,"Rig/Pelvis/RightThigh","localEulerAnglesRaw.x",new Keyframe(0,-18),new Keyframe(.25f,-38),new Keyframe(.5f,-10));
                AddConst(clip,"Rig/Pelvis/Spine/LeftUpperArm","localEulerAnglesRaw.x",-28f);
                AddConst(clip,"Rig/Pelvis/Spine/RightUpperArm","localEulerAnglesRaw.x",-28f);
                AddConst(clip,"Rig/Pelvis","localPosition.y",.88f);
            });
            AddBaseClip("Fall", 1f, (clip) => {
                AddConst(clip,"Rig/Pelvis/LeftThigh","localEulerAnglesRaw.x",15f);
                AddConst(clip,"Rig/Pelvis/RightThigh","localEulerAnglesRaw.x",15f);
                AddConst(clip,"Rig/Pelvis/Spine/LeftUpperArm","localEulerAnglesRaw.x",-40f);
                AddConst(clip,"Rig/Pelvis/Spine/RightUpperArm","localEulerAnglesRaw.x",-40f);
                AddConst(clip,"Rig/Pelvis","localPosition.y",.88f);
            });
            AddBaseClip("Crouch", 1f, (clip) => {
                AddConst(clip,"Rig/Pelvis","localPosition.y",.65f);
                AddConst(clip,"Rig/Pelvis/LeftThigh","localEulerAnglesRaw.x",48f);
                AddConst(clip,"Rig/Pelvis/RightThigh","localEulerAnglesRaw.x",48f);
                AddConst(clip,"Rig/Pelvis/LeftThigh/LeftCalf","localEulerAnglesRaw.x",-70f);
                AddConst(clip,"Rig/Pelvis/RightThigh/RightCalf","localEulerAnglesRaw.x",-70f);
                AddConst(clip,"Rig/Pelvis/Spine","localEulerAnglesRaw.x",-7f);
            });
            AddBaseClip("Prone", 1f, (clip) => {
                AddConst(clip,"Rig/Pelvis","localPosition.y",.37f);
                AddConst(clip,"Rig/Pelvis","localEulerAnglesRaw.x",72f);
                AddConst(clip,"Rig/Pelvis/LeftThigh","localEulerAnglesRaw.x",-8f);
                AddConst(clip,"Rig/Pelvis/RightThigh","localEulerAnglesRaw.x",-8f);
            });

            float recoil = weaponType == WeaponArchetype.MarksmanRifle ? 20f : weaponType == WeaponArchetype.SMG ? 7f : 12f;
            float reloadTilt = weaponType == WeaponArchetype.MarksmanRifle ? 34f : weaponType == WeaponArchetype.SMG ? 20f : 26f;
            float reloadClipDuration = shooter ? shooter.ReloadDuration : (weaponType == WeaponArchetype.MarksmanRifle ? 1.8f : weaponType == WeaponArchetype.SMG ? 1.15f : 1.35f);
            AddActionClip("Aim", 1f, WrapMode.Loop, (clip) => {
                AddConst(clip,"Rig/Pelvis/Spine","localEulerAnglesRaw.x",-3f);
                AddConst(clip,"Rig/Pelvis/Spine/LeftUpperArm","localEulerAnglesRaw.x",-38f);
                AddConst(clip,"Rig/Pelvis/Spine/LeftUpperArm/LeftForearm","localEulerAnglesRaw.x",-24f);
                AddConst(clip,"Rig/Pelvis/Spine/RightUpperArm","localEulerAnglesRaw.x",-28f);
                AddConst(clip,"Rig/Pelvis/Spine/RightUpperArm/RightForearm","localEulerAnglesRaw.x",-18f);
            });
            AddActionClip("Fire", .22f, WrapMode.Once, (clip) => {
                AddKeys(clip,"Rig/Pelvis/Spine/RightUpperArm","localEulerAnglesRaw.x",new Keyframe(0,-28),new Keyframe(.06f,-28-recoil),new Keyframe(.22f,-28));
                AddKeys(clip,"Rig/Pelvis/Spine/RightUpperArm/RightForearm","localEulerAnglesRaw.x",new Keyframe(0,-18),new Keyframe(.06f,-18-recoil*.35f),new Keyframe(.22f,-18));
                AddKeys(clip,"Rig/Pelvis/Spine/RightUpperArm/RightForearm/RightHand/WeaponSocket/WeaponModel","localPosition.z",new Keyframe(0,.075f),new Keyframe(.06f,.075f-recoil*.0018f),new Keyframe(.22f,.075f));
                AddKeys(clip,"Rig/Pelvis/Spine/RightUpperArm/RightForearm/RightHand/WeaponSocket/WeaponModel","localEulerAnglesRaw.x",new Keyframe(0,0),new Keyframe(.06f,-recoil),new Keyframe(.22f,0));
            });
            AddActionClip("Reload", reloadClipDuration, WrapMode.Once, (clip) => {
                float d = reloadClipDuration;
                AddKeys(clip,"Rig/Pelvis/Spine/LeftUpperArm","localEulerAnglesRaw.x",new Keyframe(0,-38),new Keyframe(d*.35f,12),new Keyframe(d*.75f,-4),new Keyframe(d,-38));
                AddKeys(clip,"Rig/Pelvis/Spine/LeftUpperArm/LeftForearm","localEulerAnglesRaw.x",new Keyframe(0,-24),new Keyframe(d*.35f,-72),new Keyframe(d*.75f,-30),new Keyframe(d,-24));
                AddKeys(clip,"Rig/Pelvis/Spine/RightUpperArm","localEulerAnglesRaw.x",new Keyframe(0,-28),new Keyframe(d*.35f,-12),new Keyframe(d*.75f,-22),new Keyframe(d,-28));
                AddKeys(clip,"Rig/Pelvis/Spine/RightUpperArm/RightForearm/RightHand/WeaponSocket/WeaponModel","localEulerAnglesRaw.x",new Keyframe(0,0),new Keyframe(d*.35f,reloadTilt),new Keyframe(d*.75f,reloadTilt*.5f),new Keyframe(d,0));
            });

            if (legacyAnimation["Idle"] != null) legacyAnimation.Play("Idle");
            baseClip = "Idle";
        }


        // Drives a supplied humanoid Animator without requiring a specific controller.
        // Parameters are only written when they exist, so different imported controllers
        // can expose any subset of the supported names.
        void UpdateImportedAnimator(Vector3 velocity)
        {
            if (!externalAnimator) return;
            float speed = new Vector3(velocity.x, 0f, velocity.z).magnitude;
            bool grounded = !controller || controller.isGrounded;
            bool aiming = (shooter && shooter.IsAiming) || (bot && bot.IsAiming);
            bool firing = (shooter && shooter.IsFiring) || (bot && bot.IsFiring);
            bool reloading = shooter && shooter.IsReloading;
            bool dead = bot && bot.IsDead;
            bool crouching = motor && motor.CurrentStance == PlayerMotor.Stance.Crouching;
            bool prone = motor && motor.CurrentStance == PlayerMotor.Stance.Prone;
            bool sprinting = motor && motor.SprintHeld;
            float normalizedSpeed = motor ? Mathf.Clamp01(motor.CurrentSpeed / Mathf.Max(0.1f, motor.SprintSpeed)) : Mathf.Clamp01(speed / 6f);
            SetAnimatorFloat("Speed", normalizedSpeed);
            SetAnimatorFloat("MoveX", motor ? motor.MoveInput.x : 0f);
            SetAnimatorFloat("MoveY", motor ? motor.MoveInput.y : 0f);
            SetAnimatorFloat("VerticalSpeed", motor ? motor.VerticalSpeed : velocity.y);
            SetAnimatorBool("IsMoving", speed > .25f);
            SetAnimatorBool("IsGrounded", grounded);
            SetAnimatorBool("IsAiming", aiming);
            SetAnimatorBool("IsFiring", firing);
            SetAnimatorBool("IsReloading", reloading);
            SetAnimatorBool("IsSprinting", sprinting);
            SetAnimatorBool("IsCrouching", crouching);
            SetAnimatorBool("IsProne", prone);
            SetAnimatorBool("IsDead", dead);
            if (firing && !previousFireState) SetAnimatorTrigger("Fire");
            if (reloading && !previousReloadState) SetAnimatorTrigger("Reload");
            if (motor && motor.JustLanded) SetAnimatorTrigger("Land");
            if (motor && motor.IsJumping) SetAnimatorTrigger("Jump");
            previousFireState = firing;
            previousReloadState = reloading;
        }

        void SetAnimatorFloat(string parameter, float value)
        { if (animatorParameters.Contains(parameter)) externalAnimator.SetFloat(parameter, value, .12f, Time.deltaTime); }
        void SetAnimatorBool(string parameter, bool value)
        { if (animatorParameters.Contains(parameter)) externalAnimator.SetBool(parameter, value); }
        void SetAnimatorTrigger(string parameter)
        { if (animatorParameters.Contains(parameter)) externalAnimator.SetTrigger(parameter); }

        void AddBaseClip(string name, float duration, System.Action<AnimationClip> build)
        {
            AnimationClip clip = NewClip(name, duration, WrapMode.Loop); build(clip); legacyAnimation.AddClip(clip, name);
        }
        void AddActionClip(string name, float duration, WrapMode wrap, System.Action<AnimationClip> build)
        {
            AnimationClip clip = NewClip(name, duration, wrap); build(clip); legacyAnimation.AddClip(clip, name);
            AnimationState state = legacyAnimation[name]; state.layer = 1; state.wrapMode = wrap; state.blendMode = AnimationBlendMode.Blend;
            state.AddMixingTransform(spine, true);
        }
        AnimationClip NewClip(string name, float duration, WrapMode wrap)
        {
            AnimationClip clip = new AnimationClip { name = name, legacy = true, frameRate = 30f, wrapMode = wrap };
            // Seed a valid binding so clip.length is known before the feature curves are added.
            clip.SetCurve("Rig", typeof(Transform), "localScale.x", new AnimationCurve(new Keyframe(0f, 1f), new Keyframe(duration, 1f)));
            return clip;
        }
        void AddConst(AnimationClip clip, string path, string property, float value)
        {
            clip.SetCurve(path, typeof(Transform), property, new AnimationCurve(new Keyframe(0, value), new Keyframe(clip.length, value)));
        }
        void AddSin(AnimationClip clip, string path, string property, float duration, float amplitude)
        {
            clip.SetCurve(path, typeof(Transform), property, new AnimationCurve(
                new Keyframe(0,0), new Keyframe(duration*.25f,amplitude), new Keyframe(duration*.5f,0),
                new Keyframe(duration*.75f,-amplitude), new Keyframe(duration,0)));
        }
        void AddSineHalf(AnimationClip clip, string path, string property, float duration, float amplitude, float phase = 0f)
        {
            float offset = phase * duration;
            clip.SetCurve(path, typeof(Transform), property, new AnimationCurve(
                new Keyframe(0,Mathf.Max(0,Mathf.Sin((0+phase)*Mathf.PI*2))*amplitude),
                new Keyframe(duration*.25f,Mathf.Max(0,Mathf.Sin((.25f+phase)*Mathf.PI*2))*amplitude),
                new Keyframe(duration*.5f,Mathf.Max(0,Mathf.Sin((.5f+phase)*Mathf.PI*2))*amplitude),
                new Keyframe(duration*.75f,Mathf.Max(0,Mathf.Sin((.75f+phase)*Mathf.PI*2))*amplitude),
                new Keyframe(duration,Mathf.Max(0,Mathf.Sin((1+phase)*Mathf.PI*2))*amplitude)));
        }
        void AddKeys(AnimationClip clip, string path, string property, params Keyframe[] keys)
        {
            clip.SetCurve(path, typeof(Transform), property, new AnimationCurve(keys));
        }

        void Update()
        {
            Vector3 velocity = (transform.position - lastPosition) / Mathf.Max(Time.deltaTime, .0001f);
            lastPosition = transform.position;
            if (externalAnimator)
            {
                UpdateImportedAnimator(velocity);
                return;
            }
            if (!legacyAnimation || !rig) return;
            lastPosition = transform.position;
            float speed = new Vector3(velocity.x, 0, velocity.z).magnitude;
            bool moving = speed > .25f;
            bool grounded = !controller || controller.isGrounded;
            bool aiming = (shooter && shooter.IsAiming) || (bot && bot.IsAiming);
            bool firing = (shooter && shooter.IsFiring) || (bot && bot.IsFiring);
            bool reloading = shooter && shooter.IsReloading;
            bool dead = bot && bot.IsDead;

            string wantedBase = "Idle";
            if (dead) wantedBase = "Fall";
            else if (motor && motor.CurrentStance == PlayerMotor.Stance.Prone) wantedBase = "Prone";
            else if (motor && motor.CurrentStance == PlayerMotor.Stance.Crouching) wantedBase = "Crouch";
            else if (!grounded) wantedBase = velocity.y > .1f ? "Jump" : "Fall";
            else if (moving)
            {
                if (motor && motor.SprintHeld && speed > motor.MoveSpeed * 1.12f) wantedBase = "Run";
                else if (motor && motor.MoveInput.y < -.35f) wantedBase = "Backpedal";
                else if (motor && motor.MoveInput.x < -.35f && Mathf.Abs(motor.MoveInput.x) > Mathf.Abs(motor.MoveInput.y)) wantedBase = "StrafeLeft";
                else if (motor && motor.MoveInput.x > .35f && Mathf.Abs(motor.MoveInput.x) > Mathf.Abs(motor.MoveInput.y)) wantedBase = "StrafeRight";
                else wantedBase = "Walk";
            }
            if (wantedBase != baseClip)
            {
                legacyAnimation.CrossFade(wantedBase, .13f, PlayMode.StopSameLayer);
                baseClip = wantedBase;
            }

            if (firing) lastFireTime = Time.time;
            string wantedAction = "";
            if (reloading) wantedAction = "Reload";
            else if (firing && actionClip != "Fire") wantedAction = "Fire";
            else if (actionClip == "Fire" && legacyAnimation.IsPlaying("Fire")) wantedAction = "Fire";
            else if (aiming) wantedAction = "Aim";

            if (wantedAction != actionClip)
            {
                if (wantedAction.Length > 0)
                {
                    legacyAnimation.CrossFade(wantedAction, wantedAction == "Fire" ? .025f : .12f, PlayMode.StopSameLayer);
                    actionClip = wantedAction;
                }
                else
                {
                    if (actionClip.Length > 0) legacyAnimation.Stop(actionClip);
                    actionClip = "";
                }
            }

            if (muzzleFlash)
            {
                bool flash = firing && (Time.frameCount % 2 == 0);
                muzzleFlash.localScale = flash ? new Vector3(.045f,.045f,.075f) : Vector3.one*.001f;
            }
            if (dead && pelvis) pelvis.localRotation = Quaternion.Slerp(pelvis.localRotation, Quaternion.Euler(0,0,62), Time.deltaTime*3f);
        }
    }
}
