using System;
using System.Collections.Generic;
using UnityEngine;

namespace SurvivalForce
{
    [Serializable] public class KillFeedEntry { public string Killer; public string Victim; public float Time; public bool Headshot; }
    public sealed class KillFeedService : MonoBehaviour
    {
        [SerializeField, Range(1, 12)] int capacity = 5;
        [SerializeField, Min(1)] float lifetime = 7f;
        readonly List<KillFeedEntry> entries = new List<KillFeedEntry>();
        public IReadOnlyList<KillFeedEntry> Entries => entries;
        public event Action<KillFeedEntry> Added;
        void OnEnable() { GameEventBus.ActorEliminated += OnEliminated; }
        void OnDisable() { GameEventBus.ActorEliminated -= OnEliminated; }
        void Update() { for (int i = entries.Count - 1; i >= 0; i--) if (Time.time - entries[i].Time > lifetime) entries.RemoveAt(i); }
        public void Add(string killer, string victim, bool headshot = false)
        {
            KillFeedEntry entry = new KillFeedEntry { Killer = string.IsNullOrEmpty(killer) ? "Unknown" : killer, Victim = string.IsNullOrEmpty(victim) ? "Unknown" : victim, Time = Time.time, Headshot = headshot };
            entries.Insert(0, entry); while (entries.Count > capacity) entries.RemoveAt(entries.Count - 1); Added?.Invoke(entry);
        }
        void OnEliminated(Transform source, Transform target) { Add(source ? source.name : "Zone", target ? target.name : "Unknown"); }
    }
}
