using UnityEngine;

namespace SurvivalForce
{
    /// <summary>Lightweight procedural hit feedback that avoids external particle dependencies.</summary>
    public static class CombatFeedback
    {
        public static void SpawnImpact(Vector3 point, Vector3 normal, bool critical)
        {
            GameObject marker = GameObject.CreatePrimitive(PrimitiveType.Sphere);
            marker.name = critical ? "Critical Hit Feedback" : "Hit Feedback";
            marker.transform.position = point + normal * .035f;
            marker.transform.localScale = critical ? Vector3.one * .19f : Vector3.one * .11f;
            Collider col = marker.GetComponent<Collider>(); if (col) Object.Destroy(col);
            Renderer renderer = marker.GetComponent<Renderer>();
            if (renderer)
            {
                Shader shader = Shader.Find("Unlit/Color"); if (shader == null) shader = Shader.Find("Standard");
                if (shader != null) { Material material = new Material(shader); material.color = critical ? new Color(1f,.72f,.12f) : new Color(.95f,.25f,.12f); renderer.material = material; }
            }
            var fade = marker.AddComponent<ImpactFade>(); fade.Lifetime = critical ? .24f : .16f;
        }
    }

    public class ImpactFade : MonoBehaviour
    {
        public float Lifetime = .2f;
        float elapsed;
        Renderer cachedRenderer;
        void Awake() { cachedRenderer = GetComponent<Renderer>(); }
        void OnDestroy() { if (cachedRenderer && cachedRenderer.material) Object.Destroy(cachedRenderer.material); }
        void Update()
        {
            elapsed += Time.deltaTime;
            float t = Mathf.Clamp01(elapsed / Mathf.Max(.01f, Lifetime));
            transform.localScale *= Mathf.Max(0f, 1f - Time.deltaTime * 4f);
            if (t >= 1f) Destroy(gameObject);
        }
    }
}
