using UnityEngine;

namespace SurvivalForce
{
    public enum WeaponClass { AssaultRifle, SubmachineGun, MarksmanRifle, Shotgun, SniperRifle }

    public struct WeaponProfile
    {
        public string Name;
        public WeaponClass Class;
        public float Damage, Rate, Range, Spread, Recoil, ReloadSeconds;
        public int Magazine, ReserveStart;
        public WeaponProfile(string name, WeaponClass weaponClass, float damage, float rate, float range, float spread, float recoil, float reload, int magazine, int reserve)
        { Name=name; Class=weaponClass; Damage=damage; Rate=rate; Range=range; Spread=spread; Recoil=recoil; ReloadSeconds=reload; Magazine=magazine; ReserveStart=reserve; }
    }

    /// <summary>Central balance table so weapon tuning is consistent across lobby presets and combat.</summary>
    public static class WeaponCatalog
    {
        static readonly WeaponProfile[] Profiles = {
            new WeaponProfile("AR-30", WeaponClass.AssaultRifle, 34f, .14f, 130f, .012f, 1.25f, 1.55f, 30, 150),
            new WeaponProfile("SMG-35", WeaponClass.SubmachineGun, 22f, .075f, 75f, .026f, .82f, 1.25f, 35, 175),
            new WeaponProfile("DMR-12", WeaponClass.MarksmanRifle, 68f, .72f, 180f, .004f, 2.8f, 1.8f, 12, 72),
            new WeaponProfile("SG-8", WeaponClass.Shotgun, 12f, .72f, 32f, .085f, 3.4f, 1.9f, 8, 48),
            new WeaponProfile("SR-5", WeaponClass.SniperRifle, 92f, 1.15f, 240f, .0015f, 4.2f, 2.2f, 5, 35)
        };
        public static int Count { get { return Profiles.Length; } }
        public static WeaponProfile Get(int index) { return Profiles[Mathf.Clamp(index, 0, Profiles.Length - 1)]; }
        public static WeaponProfile Get(WeaponClass weaponClass) { for(int i=0;i<Profiles.Length;i++) if(Profiles[i].Class==weaponClass) return Profiles[i]; return Profiles[0]; }
    }
}
