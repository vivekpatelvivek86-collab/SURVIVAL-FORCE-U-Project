using System;
using UnityEngine;

namespace SurvivalForce
{
    /// <summary>Simple local currency wallet with atomic buy checks and notifications.</summary>
    public sealed class LocalEconomy : MonoBehaviour
    {
        const string CoinsKey = "SF_WALLET_COINS";
        [SerializeField, Min(0)] int startingCoins = 500;
        public int Balance { get; private set; }
        public event Action<int> BalanceChanged;
        void Awake() { Balance = Mathf.Max(0, PlayerPrefs.GetInt(CoinsKey, startingCoins)); }
        public bool CanAfford(int price) => price >= 0 && Balance >= price;
        public bool TrySpend(int price)
        {
            if (!CanAfford(price)) return false;
            Balance -= price; Save(); return true;
        }
        public void Add(int amount)
        {
            if (amount <= 0) return;
            Balance = (int)System.Math.Min(int.MaxValue, (long)Balance + amount); Save();
        }
        public void SetBalanceForDevelopment(int value) { Balance = Mathf.Max(0, value); Save(); }
        void Save() { PlayerPrefs.SetInt(CoinsKey, Balance); PlayerPrefs.Save(); BalanceChanged?.Invoke(Balance); }
    }
}
