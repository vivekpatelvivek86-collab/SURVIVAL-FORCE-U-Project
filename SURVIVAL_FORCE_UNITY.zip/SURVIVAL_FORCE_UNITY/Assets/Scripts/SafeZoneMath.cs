using UnityEngine;

namespace SurvivalForce
{
    public static class SafeZoneMath
    {
        public static bool IsInside(Vector3 point, Vector3 center, float radius)
        {
            float dx = point.x - center.x; float dz = point.z - center.z;
            return dx * dx + dz * dz <= Mathf.Max(0, radius) * Mathf.Max(0, radius);
        }
        public static float DistanceOutside(Vector3 point, Vector3 center, float radius)
        {
            float dx = point.x - center.x; float dz = point.z - center.z;
            return Mathf.Max(0, Mathf.Sqrt(dx * dx + dz * dz) - Mathf.Max(0, radius));
        }
        public static Vector3 ClampToCircle(Vector3 point, Vector3 center, float radius)
        {
            Vector2 delta = new Vector2(point.x - center.x, point.z - center.z);
            float safeRadius = Mathf.Max(0, radius);
            if (delta.sqrMagnitude <= safeRadius * safeRadius) return point;
            Vector2 clamped = new Vector2(center.x, center.z) + delta.normalized * safeRadius;
            return new Vector3(clamped.x, point.y, clamped.y);
        }
        public static Vector3 RandomPoint(Vector3 center, float radius)
        {
            Vector2 offset = Random.insideUnitCircle * Mathf.Max(0, radius);
            return new Vector3(center.x + offset.x, center.y, center.z + offset.y);
        }
    }
}
