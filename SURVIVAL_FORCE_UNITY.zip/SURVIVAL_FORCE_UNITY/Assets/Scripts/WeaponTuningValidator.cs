using System.Collections.Generic;
using UnityEngine;

namespace SurvivalForce
{
    public static class WeaponTuningValidator
    {
        public static List<string> Validate(WeaponProfile profile)
        {
            List<string> issues = new List<string>();
            if (string.IsNullOrWhiteSpace(profile.Name)) issues.Add("Weapon name is empty.");
            if (profile.Damage <= 0 || profile.Damage > 300) issues.Add("Damage must be in the range (0, 300].");
            if (profile.Rate <= 0 || profile.Rate > 10) issues.Add("Fire interval must be in the range (0, 10].");
            if (profile.Range <= 0 || profile.Range > 1000) issues.Add("Range must be in the range (0, 1000].");
            if (profile.Spread < 0 || profile.Spread > 1) issues.Add("Spread should be between 0 and 1.");
            if (profile.ReloadSeconds < 0 || profile.ReloadSeconds > 30) issues.Add("Reload time should be between 0 and 30 seconds.");
            if (profile.Magazine < 1 || profile.Magazine > 200) issues.Add("Magazine capacity should be between 1 and 200.");
            if (profile.ReserveStart < 0 || profile.ReserveStart > 999) issues.Add("Starting reserve ammo should be between 0 and 999.");
            return issues;
        }
        public static bool IsValid(WeaponProfile profile) => Validate(profile).Count == 0;
    }
}
