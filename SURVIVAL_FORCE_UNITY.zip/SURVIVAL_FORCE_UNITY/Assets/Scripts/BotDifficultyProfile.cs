using UnityEngine;

namespace SurvivalForce
{
    [CreateAssetMenu(menuName = "SURVIVAL FORCE/Bot Difficulty", fileName = "BotDifficulty")]
    public sealed class BotDifficultyProfile : ScriptableObject
    {
        [Range(.1f, 2f)] public float Accuracy = .65f;
        [Range(.1f, 2f)] public float ReactionSpeed = .8f;
        [Range(.1f, 2f)] public float MovementSpeed = 1f;
        [Range(.1f, 2f)] public float Aggression = 1f;
        [Range(.1f, 2f)] public float HealthMultiplier = 1f;
        [Range(.1f, 2f)] public float DamageMultiplier = 1f;
        [Range(5f, 100f)] public float PreferredRange = 24f;
        public void ApplyTo(OfflineBot bot)
        {
            if (!bot) return;
            bot.Speed *= Mathf.Clamp(MovementSpeed, .1f, 2f);
            BotVitals vitals = bot.GetComponent<BotVitals>();
            if (vitals)
            {
                float multiplier = Mathf.Clamp(HealthMultiplier, .1f, 2f);
                vitals.MaxHealth = Mathf.Max(1f, vitals.MaxHealth * multiplier);
                vitals.Health = Mathf.Clamp(vitals.Health * multiplier, 1f, vitals.MaxHealth);
                bot.DamagePerShot *= Mathf.Clamp(DamageMultiplier, .1f, 2f);
                bot.Skill = Mathf.Clamp(bot.Skill * Mathf.Clamp(Accuracy, .1f, 2f), .5f, 1.5f);
                bot.FireDelay = Mathf.Max(.15f, bot.FireDelay / Mathf.Clamp(ReactionSpeed, .1f, 2f));
                bot.FireRange = Mathf.Max(5f, PreferredRange);
            }
        }
    }
}
