using UnityEngine;
namespace SurvivalForce
{
    public class PlayerVitals : MonoBehaviour
    {
        public float MaxHealth = 200f, Health = 200f;
        public int Ammo = 30, ReserveAmmo = 150;
        public float Armor { get; private set; }
        public bool Dead { get { return Health <= 0f; } }
        public void Damage(float amount)
        {
            if (Dead || amount <= 0f) return;
            float remaining = amount;
            if (Armor > 0f)
            {
                float absorbed = Mathf.Min(Armor, amount * .38f);
                Armor -= absorbed; remaining -= absorbed;
                var inventory = GetComponent<PlayerInventory>(); if (inventory) inventory.SyncArmor(Mathf.RoundToInt(Armor));
            }
            Health = Mathf.Max(0f, Health - remaining);
        }
        public void Heal(float amount) { Health = Mathf.Min(MaxHealth, Health + Mathf.Max(0f, amount)); }
        public void SetArmor(float amount) { Armor = Mathf.Clamp(amount, 0f, 100f); }
        public bool SpendBullet() { if (Ammo <= 0) return false; Ammo--; return true; }
        public void AddAmmo(int amount) { ReserveAmmo = Mathf.Clamp(ReserveAmmo + Mathf.Max(0, amount), 0, 999); }
    }
}
