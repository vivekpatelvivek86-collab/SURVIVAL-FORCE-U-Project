using UnityEngine;

namespace SurvivalForce
{
    /// <summary>Surface-aware footstep clip selector. Assign licensed clips in the Inspector.</summary>
    public sealed class SurfaceFootstep : MonoBehaviour
    {
        [SerializeField] AudioSource source;
        [SerializeField] AudioClip[] defaultClips;
        [SerializeField] AudioClip[] grassClips;
        [SerializeField] AudioClip[] sandClips;
        [SerializeField] AudioClip[] stoneClips;
        [SerializeField] LayerMask groundMask = ~0;
        [SerializeField, Range(0, 1)] float volume = .65f;
        public void PlayStep()
        {
            if (!source) source = GetComponent<AudioSource>();
            if (!source) return;
            Vector3 origin = transform.position + Vector3.up * .2f;
            if (!Physics.Raycast(origin, Vector3.down, out RaycastHit hit, 2f, groundMask, QueryTriggerInteraction.Ignore)) return;
            AudioClip[] clips = SelectClips(hit.collider);
            if (clips == null || clips.Length == 0) return;
            AudioClip clip = clips[Random.Range(0, clips.Length)];
            if (clip) source.PlayOneShot(clip, volume);
        }
        AudioClip[] SelectClips(Collider ground)
        {
            string label = ground.tag.ToLowerInvariant();
            if (label.Contains("grass") && grassClips.Length > 0) return grassClips;
            if ((label.Contains("sand") || label.Contains("dirt")) && sandClips.Length > 0) return sandClips;
            if ((label.Contains("stone") || label.Contains("concrete")) && stoneClips.Length > 0) return stoneClips;
            return defaultClips;
        }
    }
}
