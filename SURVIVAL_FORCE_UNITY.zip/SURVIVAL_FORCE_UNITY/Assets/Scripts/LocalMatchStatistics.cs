using System;
using UnityEngine;

namespace SurvivalForce
{
    [Serializable]
    public class LocalMatchResult
    {
        public int Placement;
        public int Kills;
        public int DamageDealt;
        public int DamageTaken;
        public int ItemsCollected;
        public float SurvivalSeconds;
        public int CoinsEarned;
        public bool Victory;
    }
    /// <summary>Stores the last offline result separately from persistent profile progression.</summary>
    public static class LocalMatchStatistics
    {
        const string Key = "SF_LAST_MATCH_RESULT";
        public static void Save(LocalMatchResult result) { if (result != null) { result.Placement = Mathf.Max(1, result.Placement); result.Kills = Mathf.Max(0, result.Kills); PlayerPrefs.SetString(Key, JsonUtility.ToJson(result)); PlayerPrefs.Save(); } }
        public static LocalMatchResult Load()
        {
            string json = PlayerPrefs.GetString(Key, "");
            if (string.IsNullOrEmpty(json)) return new LocalMatchResult();
            try { return JsonUtility.FromJson<LocalMatchResult>(json) ?? new LocalMatchResult(); }
            catch { return new LocalMatchResult(); }
        }
        public static void Clear() { PlayerPrefs.DeleteKey(Key); PlayerPrefs.Save(); }
    }
}
