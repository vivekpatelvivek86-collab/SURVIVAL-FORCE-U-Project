using UnityEngine;

namespace SurvivalForce
{
    /// <summary>Central audio settings adapter; safe to use even when no mixer is assigned.</summary>
    public sealed class AudioSettingsService : MonoBehaviour
    {
        const string MusicKey = "SF_MUSIC_ENABLED";
        const string SfxKey = "SF_SFX_ENABLED";
        const string MusicVolumeKey = "SF_MUSIC_VOLUME";
        const string SfxVolumeKey = "SF_SFX_VOLUME";
        [SerializeField] AudioSource musicSource;
        [SerializeField] AudioSource ambienceSource;
        public bool MusicEnabled { get; private set; }
        public bool SfxEnabled { get; private set; }
        public float MusicVolume { get; private set; }
        public float SfxVolume { get; private set; }
        void Awake()
        {
            MusicEnabled = PlayerPrefs.GetInt(MusicKey, 1) != 0;
            SfxEnabled = PlayerPrefs.GetInt(SfxKey, 1) != 0;
            MusicVolume = PlayerPrefs.GetFloat(MusicVolumeKey, .8f);
            SfxVolume = PlayerPrefs.GetFloat(SfxVolumeKey, .8f);
            Apply();
        }
        public void SetMusic(bool enabled) { MusicEnabled = enabled; Save(); Apply(); }
        public void SetSfx(bool enabled) { SfxEnabled = enabled; Save(); Apply(); }
        public void SetMusicVolume(float value) { MusicVolume = Mathf.Clamp01(value); Save(); Apply(); }
        public void SetSfxVolume(float value) { SfxVolume = Mathf.Clamp01(value); Save(); Apply(); }
        void Apply() { if (musicSource) { musicSource.mute = !MusicEnabled; musicSource.volume = MusicVolume; } if (ambienceSource) { ambienceSource.mute = !SfxEnabled; ambienceSource.volume = SfxVolume; } }
        void Save() { PlayerPrefs.SetInt(MusicKey, MusicEnabled ? 1 : 0); PlayerPrefs.SetInt(SfxKey, SfxEnabled ? 1 : 0); PlayerPrefs.SetFloat(MusicVolumeKey, MusicVolume); PlayerPrefs.SetFloat(SfxVolumeKey, SfxVolume); PlayerPrefs.Save(); }
    }
}
