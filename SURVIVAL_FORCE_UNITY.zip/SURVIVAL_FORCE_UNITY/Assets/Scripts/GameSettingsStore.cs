using UnityEngine;

namespace SurvivalForce
{
    /// <summary>Typed settings facade for UI widgets; all values are clamped and persisted locally.</summary>
    public static class GameSettingsStore
    {
        static string Key(string name) => "SF_SETTING_" + name;
        public static float GetSensitivity(string scope, float fallback = 1f) => Mathf.Clamp(PlayerPrefs.GetFloat(Key("SENS_" + scope), fallback), .1f, 5f);
        public static void SetSensitivity(string scope, float value) { PlayerPrefs.SetFloat(Key("SENS_" + scope), Mathf.Clamp(value, .1f, 5f)); PlayerPrefs.Save(); }
        public static bool GetToggle(string name, bool fallback) => PlayerPrefs.GetInt(Key("TOGGLE_" + name), fallback ? 1 : 0) != 0;
        public static void SetToggle(string name, bool value) { PlayerPrefs.SetInt(Key("TOGGLE_" + name), value ? 1 : 0); PlayerPrefs.Save(); }
        public static int GetQuality(int fallback = 1) => Mathf.Clamp(PlayerPrefs.GetInt(Key("QUALITY"), fallback), 0, 3);
        public static void SetQuality(int value) { int q = Mathf.Clamp(value, 0, 3); PlayerPrefs.SetInt(Key("QUALITY"), q); QualitySettings.SetQualityLevel(q, true); PlayerPrefs.Save(); }
        public static int GetTargetFps(int fallback = 60) => Mathf.Clamp(PlayerPrefs.GetInt(Key("TARGET_FPS"), fallback), 30, 120);
        public static void SetTargetFps(int fps) { int value = Mathf.Clamp(fps, 30, 120); PlayerPrefs.SetInt(Key("TARGET_FPS"), value); Application.targetFrameRate = value; PlayerPrefs.Save(); }
        public static void ResetAll() { string[] keys = { "SENS_General", "SENS_RedDot", "SENS_2X", "SENS_4X", "SENS_Sniper", "QUALITY", "TARGET_FPS" }; for (int i = 0; i < keys.Length; i++) PlayerPrefs.DeleteKey(Key(keys[i])); PlayerPrefs.Save(); }
    }
}
