using UnityEngine;
using UnityEngine.EventSystems;

namespace SurvivalForce
{
    [RequireComponent(typeof(CharacterController))]
    public class PlayerMotor : MonoBehaviour
    {
        [Header("Movement")]
        public float MoveSpeed = 6.2f;
        public float SprintSpeed = 8.2f;
        public float CrouchSpeed = 3.1f;
        public float ProneSpeed = 1.25f;
        public float JumpHeight = 1.35f;
        public float Gravity = -22f;
        public float MouseSensitivity = 2.1f;
        [Header("Movement feel")]
        public float JumpBufferTime = .12f;
        public float CoyoteTime = .10f;
        public float GroundStickVelocity = -2f;

        public enum Stance { Standing, Crouching, Prone }
        public Stance CurrentStance { get; private set; } = Stance.Standing;
        public bool SprintHeld { get; private set; }
        public bool IsGrounded { get; private set; }
        public bool IsMoving { get; private set; }
        public bool IsJumping { get; private set; }
        public bool IsFalling { get; private set; }
        public bool JustLanded { get; private set; }
        public float VerticalSpeed { get { return vertical; } }
        public float CurrentSpeed { get; private set; }
        public Vector2 MoveInput { get; private set; }

        bool sprintToggle;
        CharacterController cc;
        float vertical, yaw, pitch = 10f, jumpPressedAt = -10f, lastGroundedAt = -10f;
        bool jumpRequested;
        float nextAutoPickup;
        int moveFinger = -1, lookFinger = -1;
        Vector2 moveOrigin, mobileMove;
        float standingHeight = 1.8f;
        Vector3 standingCenter = new Vector3(0, .9f, 0);
        bool wasGrounded;

        void Awake()
        {
            cc = GetComponent<CharacterController>();
            yaw = transform.eulerAngles.y;
            if (cc) { standingHeight = cc.height; standingCenter = cc.center; }
            IsGrounded = cc && cc.isGrounded;
            wasGrounded = IsGrounded;
        }

        void Update()
        {
            JustLanded = false;
            if (SurvivalForceBootstrap.Instance == null || cc == null) return;

            float h = Input.GetAxisRaw("Horizontal");
            float v = Input.GetAxisRaw("Vertical");
            ReadTouchControls(ref h, ref v);
            MoveInput = Vector2.ClampMagnitude(new Vector2(h, v), 1f);
            IsMoving = MoveInput.sqrMagnitude > .035f;

            if (Input.GetButtonDown("Jump") || jumpRequested) jumpPressedAt = Time.time;
            jumpRequested = false;

            bool groundedNow = cc.isGrounded;
            if (groundedNow) lastGroundedAt = Time.time;
            if (!wasGrounded && groundedNow) JustLanded = true;
            wasGrounded = groundedNow;
            IsGrounded = groundedNow;

            SprintHeld = Input.GetKey(KeyCode.LeftShift) || sprintToggle;
            if (CurrentStance != Stance.Standing) SprintHeld = false;
            CurrentSpeed = CurrentStance == Stance.Prone ? ProneSpeed :
                           CurrentStance == Stance.Crouching ? CrouchSpeed :
                           (SprintHeld && IsMoving ? SprintSpeed : MoveSpeed);

            Vector3 move = (transform.right * MoveInput.x + transform.forward * MoveInput.y);
            if (move.sqrMagnitude > 1f) move.Normalize();
            cc.Move(move * CurrentSpeed * Time.deltaTime);

            bool jumpBuffered = Time.time - jumpPressedAt <= JumpBufferTime;
            bool canJump = Time.time - lastGroundedAt <= CoyoteTime;
            if (jumpBuffered && canJump && CurrentStance != Stance.Prone)
            {
                vertical = Mathf.Sqrt(JumpHeight * -2f * Gravity);
                jumpPressedAt = -10f;
                lastGroundedAt = -10f;
                IsGrounded = false;
            }
            if (cc.isGrounded && vertical < 0f) vertical = GroundStickVelocity;
            vertical += Gravity * Time.deltaTime;
            cc.Move(Vector3.up * vertical * Time.deltaTime);
            IsJumping = !cc.isGrounded && vertical > .7f;
            IsFalling = !cc.isGrounded && vertical < -.7f;
            IsGrounded = cc.isGrounded;

            if (Input.GetMouseButton(1))
            {
                var shooter = GetComponent<PlayerShooter>();
                float sensitivity = GetLookSensitivity(shooter);
                yaw += Input.GetAxis("Mouse X") * sensitivity;
                pitch = Mathf.Clamp(pitch - Input.GetAxis("Mouse Y") * sensitivity, -15f, 55f);
                ApplyCameraPitch();
            }
            transform.rotation = Quaternion.Euler(0f, yaw, 0f);

            if (Input.GetKeyDown(KeyCode.E)) PickupNearby(2.5f);
            if (Input.GetKeyDown(KeyCode.C)) ToggleCrouch();
            if (Input.GetKeyDown(KeyCode.Z)) ToggleProne();
            if (Input.GetKeyDown(KeyCode.LeftShift) && CurrentStance != Stance.Standing) SetStance(Stance.Standing);
            if (PlayerPrefs.GetInt("SF_AUTO_PICKUP", 0) == 1 && Time.time >= nextAutoPickup)
            {
                nextAutoPickup = Time.time + .35f;
                PickupNearby(1.65f);
            }
        }

        float GetLookSensitivity(PlayerShooter shooter)
        {
            string key = "SF_SENS_GENERAL";
            if (shooter && shooter.IsAiming)
                key = shooter.ScopeLevel == 0 ? "SF_SENS_RED_DOT" : shooter.ScopeLevel == 1 ? "SF_SENS_2X" : shooter.ScopeLevel == 2 ? "SF_SENS_4X" : "SF_SENS_SNIPER";
            return PlayerPrefs.GetFloat(key, MouseSensitivity);
        }

        void ReadTouchControls(ref float h, ref float v)
        {
            if (Input.touchCount == 0) { moveFinger = -1; lookFinger = -1; mobileMove = Vector2.zero; return; }
            for (int i = 0; i < Input.touchCount; i++)
            {
                Touch t = Input.GetTouch(i);
                bool overUI = EventSystem.current != null && EventSystem.current.IsPointerOverGameObject(t.fingerId);
                if (t.phase == TouchPhase.Began && !overUI)
                {
                    if (t.position.x < Screen.width * .45f && t.position.y < Screen.height * .72f)
                    { moveFinger = t.fingerId; moveOrigin = t.position; }
                    else if (t.position.x >= Screen.width * .45f) lookFinger = t.fingerId;
                }
                if (t.fingerId == moveFinger)
                {
                    Vector2 delta = t.position - moveOrigin;
                    mobileMove = new Vector2(Mathf.Clamp(delta.x / 105f, -1f, 1f), Mathf.Clamp(delta.y / 105f, -1f, 1f));
                    if (t.phase == TouchPhase.Ended || t.phase == TouchPhase.Canceled) { moveFinger = -1; mobileMove = Vector2.zero; }
                }
                if (t.fingerId == lookFinger)
                {
                    if (t.phase == TouchPhase.Moved && !overUI)
                    {
                        float sensitivity = GetLookSensitivity(GetComponent<PlayerShooter>());
                        yaw += t.deltaPosition.x * sensitivity * .018f;
                        pitch = Mathf.Clamp(pitch - t.deltaPosition.y * sensitivity * .018f, -15f, 55f);
                        ApplyCameraPitch();
                    }
                    if (t.phase == TouchPhase.Ended || t.phase == TouchPhase.Canceled) lookFinger = -1;
                }
            }
            if (moveFinger != -1) { h = mobileMove.x; v = mobileMove.y; }
        }

        void ApplyCameraPitch()
        {
            var cam = Camera.main;
            var follow = cam ? cam.GetComponent<FollowCamera>() : null;
            if (follow) follow.pitch = pitch;
        }

        void PickupNearby(float radius)
        {
            var hits = Physics.OverlapSphere(transform.position, radius);
            foreach (var c in hits)
            {
                var loot = c.GetComponent<LootPickup>();
                if (loot) { loot.Collect(GetComponent<PlayerVitals>()); if (PlayerPrefs.GetInt("SF_AUTO_PICKUP", 0) == 0) break; }
            }
        }

        public void RequestJump() { jumpRequested = true; jumpPressedAt = Time.time; }
        public void ToggleSprint() { sprintToggle = !sprintToggle; if (CurrentStance != Stance.Standing) SetStance(Stance.Standing); }
        public void ToggleCrouch() { SetStance(CurrentStance == Stance.Crouching ? Stance.Standing : Stance.Crouching); }
        public void ToggleProne() { SetStance(CurrentStance == Stance.Prone ? Stance.Standing : Stance.Prone); }

        void SetStance(Stance stance)
        {
            if (cc == null) return;
            if (stance == Stance.Standing && CurrentStance != Stance.Standing)
            {
                float radius = Mathf.Max(.1f, cc.radius * .92f);
                Vector3 bottom = transform.position + Vector3.up * radius;
                Vector3 top = transform.position + Vector3.up * (standingHeight - radius);
                Collider[] blockers = Physics.OverlapCapsule(bottom, top, radius, ~0, QueryTriggerInteraction.Ignore);
                for (int i = 0; i < blockers.Length; i++)
                {
                    if (blockers[i] && blockers[i] != cc && !blockers[i].transform.IsChildOf(transform))
                        return; // Do not stand up through a ceiling or roof.
                }
            }
            CurrentStance = stance;
            cc.height = stance == Stance.Standing ? standingHeight : stance == Stance.Crouching ? 1.25f : .62f;
            cc.center = stance == Stance.Standing ? standingCenter : stance == Stance.Crouching ? new Vector3(0, .625f, 0) : new Vector3(0, .31f, 0);
            if (stance != Stance.Standing) { SprintHeld = false; sprintToggle = false; }
        }
    }
}
