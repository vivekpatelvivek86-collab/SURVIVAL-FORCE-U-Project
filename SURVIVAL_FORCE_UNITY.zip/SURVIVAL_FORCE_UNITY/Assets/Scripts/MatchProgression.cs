using UnityEngine;

namespace SurvivalForce
{
    /// <summary>Local match rewards, account XP and lifetime stats. No online claims or server dependency.</summary>
    public static class MatchProgression
    {
        public static int Level { get { return Mathf.Max(1, PlayerPrefs.GetInt("SF_ACCOUNT_LEVEL", 1)); } }
        public static int XP { get { return Mathf.Max(0, PlayerPrefs.GetInt("SF_ACCOUNT_XP", 0)); } }
        public static int XPForNextLevel { get { return Level * 250; } }
        public static int LifetimeKills { get { return Mathf.Max(0, PlayerPrefs.GetInt("SF_LIFETIME_KILLS", 0)); } }

        public static void RecordKill()
        {
            PlayerPrefs.SetInt("SF_LIFETIME_KILLS", LifetimeKills + 1);
            PlayerPrefs.SetInt("SF_ACCOUNT_XP", XP + 25);
            NormalizeLevel();
            PlayerPrefs.Save();
        }

        public static int FinishMatch(bool won, int kills, float secondsSurvived)
        {
            int reward = Mathf.Clamp(20 + kills * 12 + Mathf.FloorToInt(secondsSurvived / 30f) * 2 + (won ? 150 : 0), 20, 900);
            int coins = Mathf.Max(0, PlayerPrefs.GetInt("SF_LOCAL_COINS", 1200));
            PlayerPrefs.SetInt("SF_LOCAL_COINS", coins + reward);
            PlayerPrefs.SetInt("SF_ACCOUNT_XP", XP + Mathf.Clamp(35 + kills * 20 + Mathf.FloorToInt(secondsSurvived / 10f) + (won ? 250 : 0), 35, 1500));
            PlayerPrefs.SetInt("SF_MATCHES", PlayerPrefs.GetInt("SF_MATCHES", 0) + 0); // Match count is recorded at match start.
            PlayerPrefs.SetInt("SF_LAST_MATCH_KILLS", kills);
            PlayerPrefs.SetInt("SF_LAST_MATCH_SECONDS", Mathf.FloorToInt(secondsSurvived));
            PlayerPrefs.SetInt("SF_LAST_MATCH_WON", won ? 1 : 0);
            NormalizeLevel();
            PlayerPrefs.Save();
            return reward;
        }

        static void NormalizeLevel()
        {
            int xp = Mathf.Max(0, PlayerPrefs.GetInt("SF_ACCOUNT_XP", 0));
            int level = 1;
            while (level < 100 && xp >= level * 250) { xp -= level * 250; level++; }
            PlayerPrefs.SetInt("SF_ACCOUNT_LEVEL", level);
            PlayerPrefs.SetInt("SF_ACCOUNT_LEVEL_XP", xp);
        }
    }
}
