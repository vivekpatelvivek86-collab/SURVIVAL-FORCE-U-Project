using System;
using UnityEngine;

namespace SurvivalForce
{
    [Serializable]
    public class WeaponRuntimeState
    {
        public WeaponClass Class;
        public int Magazine;
        public int Reserve;
        public bool IsReloading;
        public float ReloadRemaining;
        public float NextFireTime;
        public WeaponRuntimeState(WeaponClass weaponClass)
        {
            Class = weaponClass;
            WeaponProfile profile = WeaponCatalog.Get(weaponClass);
            Magazine = profile.Magazine;
            Reserve = profile.ReserveStart;
        }
        public bool CanFire(float now) => !IsReloading && Magazine > 0 && now >= NextFireTime;
        public bool ConsumeRound(float now)
        {
            if (!CanFire(now)) return false;
            WeaponProfile profile = WeaponCatalog.Get(Class);
            Magazine--;
            NextFireTime = now + Mathf.Max(.01f, profile.Rate);
            return true;
        }
        public bool BeginReload()
        {
            WeaponProfile profile = WeaponCatalog.Get(Class);
            if (IsReloading || Magazine >= profile.Magazine || Reserve <= 0) return false;
            IsReloading = true;
            ReloadRemaining = profile.ReloadSeconds;
            return true;
        }
        public bool TickReload(float deltaTime)
        {
            if (!IsReloading) return false;
            ReloadRemaining -= Mathf.Max(0, deltaTime);
            if (ReloadRemaining > 0) return false;
            WeaponProfile profile = WeaponCatalog.Get(Class);
            int amount = Mathf.Min(profile.Magazine - Magazine, Reserve);
            Magazine += amount;
            Reserve -= amount;
            IsReloading = false;
            ReloadRemaining = 0;
            return true;
        }
        public int AddAmmo(int amount) { int accepted = Mathf.Clamp(amount, 0, 999 - Reserve); Reserve += accepted; return accepted; }
    }
}
