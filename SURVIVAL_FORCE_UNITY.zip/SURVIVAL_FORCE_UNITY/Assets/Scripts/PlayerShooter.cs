using UnityEngine;
namespace SurvivalForce
{
    public enum WeaponArchetype { AssaultRifle, SMG, MarksmanRifle, Shotgun, SniperRifle }

    public class PlayerShooter : MonoBehaviour
    {
        public WeaponArchetype WeaponType = WeaponArchetype.AssaultRifle;
        public Camera viewCamera;
        public float Range = 130f, Damage = 34f, FireRate = .14f;
        public bool IsAiming { get; private set; }
        public bool IsFiring { get; private set; }
        public bool IsReloading { get; private set; }
        public int ScopeLevel { get; private set; }
        public int MagazineSize = 30;
        public float ReloadDuration = 1.35f;
        public float Spread = .012f;
        public float Recoil = 1.25f;
        public float CriticalMultiplier = 1.55f;
        float nextFire, reloadEnds, baseFov = 68f, recoilKick;
        bool touchFireHeld;

        void Start()
        {
            ScopeLevel = Mathf.Clamp(PlayerPrefs.GetInt("SF_ACTIVE_SCOPE", 0), 0, 3);
            if (!viewCamera) viewCamera = Camera.main;
            if (viewCamera) baseFov = viewCamera.fieldOfView;
        }

        public void Configure(WeaponProfile profile)
        {
            WeaponType = (WeaponArchetype)Mathf.Clamp((int)profile.Class, 0, 4);
            Damage = profile.Damage; FireRate = profile.Rate; Range = profile.Range;
            Spread = profile.Spread; Recoil = profile.Recoil; ReloadDuration = profile.ReloadSeconds;
            MagazineSize = profile.Magazine;
        }

        void Update()
        {
            IsFiring = false;
            if (Input.GetMouseButton(0) || touchFireHeld) Fire();
            if (Input.GetKeyDown(KeyCode.R)) Reload();
            if (Input.GetKeyDown(KeyCode.V)) ToggleAim();
            if (Input.GetKeyDown(KeyCode.Alpha1)) SelectWeapon(0);
            if (Input.GetKeyDown(KeyCode.Alpha2)) SelectWeapon(1);
            if (Input.GetKeyDown(KeyCode.Alpha3)) SelectWeapon(2);
            if (Input.GetKeyDown(KeyCode.Alpha4)) SelectWeapon(3);
            if (Input.GetKeyDown(KeyCode.Alpha5)) SelectWeapon(4);
            if (IsReloading && Time.time >= reloadEnds) FinishReload();
            if (viewCamera)
            {
                float target = IsAiming ? (ScopeLevel == 0 ? 48f : ScopeLevel == 1 ? 36f : ScopeLevel == 2 ? 25f : 18f) : baseFov;
                viewCamera.fieldOfView = Mathf.Lerp(viewCamera.fieldOfView, target, Time.deltaTime * 8f);
            }
            recoilKick = Mathf.Lerp(recoilKick, 0f, Time.deltaTime * 7f);
        }

        public void SelectWeapon(int index)
        {
            if (IsReloading) return;
            WeaponProfile profile = WeaponCatalog.Get(index);
            Configure(profile);
            var vitals = GetComponent<PlayerVitals>();
            if (vitals) { vitals.Ammo = profile.Magazine; vitals.ReserveAmmo = Mathf.Max(vitals.ReserveAmmo, profile.ReserveStart); }
            PlayerPrefs.SetInt("SF_WEAPON", Mathf.Clamp(index, 0, WeaponCatalog.Count - 1)); PlayerPrefs.Save();
        }

        public void Fire()
        {
            if (IsReloading || Time.time < nextFire) return;
            var vitals = GetComponent<PlayerVitals>();
            if (!vitals || vitals.Dead) return;
            if (vitals.Ammo <= 0) { Reload(); return; }
            if (!vitals.SpendBullet()) { Reload(); return; }
            nextFire = Time.time + FireRate; IsFiring = true;
            recoilKick = Mathf.Min(8f, recoilKick + Recoil * (IsAiming ? .45f : 1f));
            if (!viewCamera) viewCamera = Camera.main;
            if (!viewCamera) return;

            int pellets = WeaponType == WeaponArchetype.Shotgun ? 8 : 1;
            for (int pellet = 0; pellet < pellets; pellet++)
            {
                Vector3 direction = viewCamera.transform.forward;
                float currentSpread = Spread * (IsAiming ? .35f : 1f);
                direction = Quaternion.Euler(Random.Range(-currentSpread, currentSpread) * 100f, Random.Range(-currentSpread, currentSpread) * 100f, 0f) * direction;
                Ray ray = new Ray(viewCamera.transform.position, direction);
                if (Physics.Raycast(ray, out RaycastHit hit, Range, ~0, QueryTriggerInteraction.Ignore))
                {
                    var bot = hit.collider.GetComponentInParent<BotVitals>();
                    if (bot)
                    {
                        bool critical = hit.point.y - bot.transform.position.y > 1.35f;
                        float damage = Damage * (IsAiming ? 1.08f : 1f) * (critical ? CriticalMultiplier : 1f);
                        if (WeaponType == WeaponArchetype.Shotgun) damage /= pellets;
                        bot.Damage(damage);
                    }
                    var loot = hit.collider.GetComponent<LootPickup>(); if (loot) loot.Collect(vitals);
                    CombatFeedback.SpawnImpact(hit.point, hit.normal, bot != null && hit.point.y - bot.transform.position.y > 1.35f);
                }
            }
        }

        public void Reload()
        {
            if (IsReloading) return;
            var vitals = GetComponent<PlayerVitals>();
            if (!vitals || vitals.ReserveAmmo <= 0 || vitals.Ammo >= MagazineSize) return;
            IsReloading = true; reloadEnds = Time.time + ReloadDuration;
        }

        void FinishReload()
        {
            var vitals = GetComponent<PlayerVitals>();
            if (vitals)
            {
                int amount = Mathf.Min(Mathf.Max(0, MagazineSize - vitals.Ammo), vitals.ReserveAmmo);
                vitals.Ammo += amount; vitals.ReserveAmmo -= amount;
            }
            IsReloading = false;
        }

        public void SetFireHeld(bool held) { touchFireHeld = held; }
        public void ToggleAim() { IsAiming = !IsAiming; }
        public void CycleScope() { ScopeLevel = (ScopeLevel + 1) % 4; IsAiming = true; PlayerPrefs.SetInt("SF_ACTIVE_SCOPE", ScopeLevel); PlayerPrefs.Save(); }
    }
}
