using System;
using UnityEngine;

namespace SurvivalForce
{
    public enum MatchPhase { Lobby, Countdown, Inserting, Active, FinalCircle, Results }

    /// <summary>Single authoritative offline match state machine. Attach to a scene manager object.</summary>
    public sealed class MatchPhaseDirector : MonoBehaviour
    {
        [SerializeField] MatchPhase phase = MatchPhase.Lobby;
        [SerializeField, Min(0)] float countdownSeconds = 5f;
        [SerializeField, Min(0)] float insertionSeconds = 8f;
        [SerializeField, Min(1)] int finalCircleAliveThreshold = 5;
        float timer;
        public MatchPhase Phase => phase;
        public float PhaseTimeRemaining => Mathf.Max(0, timer);
        public event Action<MatchPhase> Changed;

        void Update()
        {
            if (phase != MatchPhase.Countdown && phase != MatchPhase.Inserting) return;
            timer -= Time.deltaTime;
            if (timer > 0) return;
            SetPhase(phase == MatchPhase.Countdown ? MatchPhase.Inserting : MatchPhase.Active);
            if (phase == MatchPhase.Inserting) timer = insertionSeconds;
        }

        public bool BeginMatch()
        {
            if (phase != MatchPhase.Lobby && phase != MatchPhase.Results) return false;
            timer = countdownSeconds;
            SetPhase(MatchPhase.Countdown);
            if (timer <= 0) { timer = insertionSeconds; SetPhase(MatchPhase.Inserting); }
            return true;
        }

        public void NotifyAliveCount(int alive)
        {
            if (phase == MatchPhase.Active && alive > 0 && alive <= finalCircleAliveThreshold) SetPhase(MatchPhase.FinalCircle);
            if ((phase == MatchPhase.Active || phase == MatchPhase.FinalCircle) && alive <= 1) SetPhase(MatchPhase.Results);
        }

        public void EndMatch() { if (phase != MatchPhase.Lobby) SetPhase(MatchPhase.Results); }
        public void ReturnToLobby() { timer = 0; SetPhase(MatchPhase.Lobby); }
        void SetPhase(MatchPhase next)
        {
            if (phase == next) return;
            phase = next;
            GameEventBus.RaisePhase((int)phase);
            Changed?.Invoke(phase);
        }
    }
}
