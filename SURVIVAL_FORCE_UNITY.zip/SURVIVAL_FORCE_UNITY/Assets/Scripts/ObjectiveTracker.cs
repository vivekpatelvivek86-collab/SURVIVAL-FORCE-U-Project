using System;
using System.Collections.Generic;
using UnityEngine;

namespace SurvivalForce
{
    public enum ObjectiveKind { EliminateBots, CollectItems, SurviveSeconds, ReachLocation, UseMedkit }
    [Serializable]
    public class MatchObjective
    {
        public string Id;
        public string Title;
        public ObjectiveKind Kind;
        public int RequiredCount = 1;
        public int CurrentCount;
        public bool Completed;
        public int RewardCoins;
    }
    public sealed class ObjectiveTracker : MonoBehaviour
    {
        [SerializeField] List<MatchObjective> objectives = new List<MatchObjective>();
        public IReadOnlyList<MatchObjective> Objectives => objectives;
        public event Action<MatchObjective> ProgressChanged;
        public event Action<MatchObjective> Completed;
        float aliveSeconds;
        void OnEnable() { GameEventBus.ActorEliminated += OnElimination; GameEventBus.ItemCollected += OnItem; }
        void OnDisable() { GameEventBus.ActorEliminated -= OnElimination; GameEventBus.ItemCollected -= OnItem; }
        void Update()
        {
            aliveSeconds += Time.deltaTime;
            for (int i = 0; i < objectives.Count; i++)
                if (!objectives[i].Completed && objectives[i].Kind == ObjectiveKind.SurviveSeconds)
                    SetProgress(objectives[i], Mathf.FloorToInt(aliveSeconds));
        }
        public void Configure(IEnumerable<MatchObjective> values)
        {
            objectives.Clear(); if (values == null) return;
            foreach (MatchObjective item in values) if (item != null) objectives.Add(item);
            aliveSeconds = 0;
        }
        public void AddProgress(ObjectiveKind kind, int amount = 1)
        {
            for (int i = 0; i < objectives.Count; i++) if (objectives[i].Kind == kind && !objectives[i].Completed)
                SetProgress(objectives[i], objectives[i].CurrentCount + Mathf.Max(0, amount));
        }
        void OnElimination(Transform source, Transform target) { if (source == transform || (source && source.root == transform.root)) AddProgress(ObjectiveKind.EliminateBots); }
        void OnItem(string id, int count) { AddProgress(ObjectiveKind.CollectItems, count); }
        void SetProgress(MatchObjective item, int value)
        {
            int next = Mathf.Clamp(value, 0, Mathf.Max(1, item.RequiredCount));
            if (next == item.CurrentCount && !item.Completed) return;
            item.CurrentCount = next;
            ProgressChanged?.Invoke(item);
            if (item.CurrentCount < Mathf.Max(1, item.RequiredCount) || item.Completed) return;
            item.Completed = true; Completed?.Invoke(item); GameEventBus.RaiseObjective(item.Id);
        }
    }
}
