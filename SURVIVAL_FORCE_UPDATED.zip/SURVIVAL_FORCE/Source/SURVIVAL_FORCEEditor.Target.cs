using UnrealBuildTool;
using System.Collections.Generic;
public class SURVIVAL_FORCEEditorTarget : TargetRules
{
    public SURVIVAL_FORCEEditorTarget(TargetInfo Target) : base(Target)
    {
        Type = TargetType.Editor;
        DefaultBuildSettings = BuildSettingsVersion.V5;
        IncludeOrderVersion = EngineIncludeOrderVersion.Unreal5_4;
        ExtraModuleNames.Add("SURVIVAL_FORCE");
    }
}
