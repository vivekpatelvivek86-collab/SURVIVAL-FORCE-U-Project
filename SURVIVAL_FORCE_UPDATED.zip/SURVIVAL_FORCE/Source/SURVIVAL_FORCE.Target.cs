using UnrealBuildTool;
using System.Collections.Generic;
public class SURVIVAL_FORCETarget : TargetRules
{
    public SURVIVAL_FORCETarget(TargetInfo Target) : base(Target)
    {
        Type = TargetType.Game;
        DefaultBuildSettings = BuildSettingsVersion.V5;
        IncludeOrderVersion = EngineIncludeOrderVersion.Unreal5_4;
        ExtraModuleNames.Add("SURVIVAL_FORCE");
    }
}
