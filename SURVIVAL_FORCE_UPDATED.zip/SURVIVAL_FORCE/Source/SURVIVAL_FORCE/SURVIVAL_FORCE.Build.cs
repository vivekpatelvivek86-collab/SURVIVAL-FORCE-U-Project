using UnrealBuildTool;

public class SURVIVAL_FORCE : ModuleRules
{
    public SURVIVAL_FORCE(ReadOnlyTargetRules Target) : base(Target)
    {
        PCHUsage = PCHUsageMode.UseExplicitOrSharedPCHs;
        PublicDependencyModuleNames.AddRange(new string[] { "Core", "CoreUObject", "Engine", "InputCore", "AIModule", "GameplayTasks", "NavigationSystem", "UMG", "Slate", "SlateCore" });
    }
}
