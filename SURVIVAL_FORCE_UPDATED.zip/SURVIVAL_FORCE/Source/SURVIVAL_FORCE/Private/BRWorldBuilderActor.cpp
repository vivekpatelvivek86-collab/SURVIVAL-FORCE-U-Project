#include "BRWorldBuilderActor.h"
#include "Components/SceneComponent.h"
#include "Components/StaticMeshComponent.h"
#include "Components/InstancedStaticMeshComponent.h"
#include "Materials/MaterialInstanceDynamic.h"
#include "Materials/MaterialInterface.h"
#include "Components/DirectionalLightComponent.h"
#include "UObject/ConstructorHelpers.h"
#include "BRMetaProgressionSubsystem.h"

ABRWorldBuilderActor::ABRWorldBuilderActor()
{
    PrimaryActorTick.bCanEverTick = false;
    SetRootComponent(CreateDefaultSubobject<USceneComponent>(TEXT("Root")));
    BlockInstances = CreateDefaultSubobject<UInstancedStaticMeshComponent>(TEXT("WorldBlockInstances"));
    BlockInstances->SetupAttachment(GetRootComponent());
    BlockInstances->SetMobility(EComponentMobility::Movable);
    BlockInstances->SetCollisionProfileName(TEXT("BlockAll"));
    BlockInstances->SetCastShadow(false);
    CanopyInstances = CreateDefaultSubobject<UInstancedStaticMeshComponent>(TEXT("FoliageCanopyInstances"));
    CanopyInstances->SetupAttachment(GetRootComponent());
    CanopyInstances->SetMobility(EComponentMobility::Movable);
    CanopyInstances->SetCollisionEnabled(ECollisionEnabled::NoCollision);
    CanopyInstances->SetCastShadow(false);
    GroundInstances = CreateDefaultSubobject<UInstancedStaticMeshComponent>(TEXT("IslandGroundInstances"));
    GroundInstances->SetupAttachment(GetRootComponent());
    GroundInstances->SetMobility(EComponentMobility::Movable);
    GroundInstances->SetCollisionProfileName(TEXT("BlockAll"));
    GroundInstances->SetCastShadow(false);
    WaterInstances = CreateDefaultSubobject<UInstancedStaticMeshComponent>(TEXT("OceanWaterInstances"));
    WaterInstances->SetupAttachment(GetRootComponent());
    WaterInstances->SetMobility(EComponentMobility::Movable);
    WaterInstances->SetCollisionEnabled(ECollisionEnabled::NoCollision);
    WaterInstances->SetCastShadow(false);
    RoadInstances = CreateDefaultSubobject<UInstancedStaticMeshComponent>(TEXT("RoadInstances"));
    RoadInstances->SetupAttachment(GetRootComponent());
    RoadInstances->SetMobility(EComponentMobility::Movable);
    RoadInstances->SetCollisionProfileName(TEXT("BlockAll"));
    RoadInstances->SetCastShadow(false);
    static ConstructorHelpers::FObjectFinder<UStaticMesh> SphereAsset(TEXT("/Engine/BasicShapes/Sphere.Sphere"));
    if (SphereAsset.Succeeded())
    {
        CanopyMesh = SphereAsset.Object;
        CanopyInstances->SetStaticMesh(CanopyMesh);
    }
    static ConstructorHelpers::FObjectFinder<UMaterialInterface> BasicMaterial(TEXT("/Engine/BasicShapes/BasicShapeMaterial.BasicShapeMaterial"));
    if (BasicMaterial.Succeeded())
    {
        UMaterialInstanceDynamic* FoliageMaterial = UMaterialInstanceDynamic::Create(BasicMaterial.Object, this);
        if (FoliageMaterial)
        {
            FoliageMaterial->SetVectorParameterValue(TEXT("Color"), FLinearColor(0.075f, 0.27f, 0.075f, 1.f));
            FoliageMaterial->SetVectorParameterValue(TEXT("BaseColor"), FLinearColor(0.075f, 0.27f, 0.075f, 1.f));
            CanopyInstances->SetMaterial(0, FoliageMaterial);
            UMaterialInstanceDynamic* GroundMaterial = UMaterialInstanceDynamic::Create(BasicMaterial.Object, this);
            if (GroundMaterial) { GroundMaterial->SetVectorParameterValue(TEXT("Color"), FLinearColor(0.20f,0.36f,0.13f,1.f)); GroundMaterial->SetVectorParameterValue(TEXT("BaseColor"), FLinearColor(0.20f,0.36f,0.13f,1.f)); GroundInstances->SetMaterial(0,GroundMaterial); }
            UMaterialInstanceDynamic* WaterMaterial = UMaterialInstanceDynamic::Create(BasicMaterial.Object, this);
            if (WaterMaterial) { WaterMaterial->SetVectorParameterValue(TEXT("Color"), FLinearColor(0.025f,0.22f,0.36f,1.f)); WaterMaterial->SetVectorParameterValue(TEXT("BaseColor"), FLinearColor(0.025f,0.22f,0.36f,1.f)); WaterInstances->SetMaterial(0,WaterMaterial); }
            UMaterialInstanceDynamic* RoadMaterial = UMaterialInstanceDynamic::Create(BasicMaterial.Object, this);
            if (RoadMaterial) { RoadMaterial->SetVectorParameterValue(TEXT("Color"), FLinearColor(0.12f,0.13f,0.12f,1.f)); RoadMaterial->SetVectorParameterValue(TEXT("BaseColor"), FLinearColor(0.12f,0.13f,0.12f,1.f)); RoadInstances->SetMaterial(0,RoadMaterial); }
        }
    }
    static ConstructorHelpers::FObjectFinder<UStaticMesh> CubeAsset(TEXT("/Engine/BasicShapes/Cube.Cube"));
    if (CubeAsset.Succeeded()) { CubeMesh = CubeAsset.Object; BlockInstances->SetStaticMesh(CubeMesh); GroundInstances->SetStaticMesh(CubeMesh); WaterInstances->SetStaticMesh(CubeMesh); RoadInstances->SetStaticMesh(CubeMesh); }
}
void ABRWorldBuilderActor::BeginPlay()
{
    Super::BeginPlay();
    if (!bGenerateAtBeginPlay) return;

    // Original low-poly island blockout. Selected map changes the district ring and terrain profile.
    bool bPurgatoryStyle = false;
    EBRGameMode SelectedMode = EBRGameMode::BRClassic;
    if (UGameInstance* GI = GetGameInstance())
    {
        if (UBRMetaProgressionSubsystem* Meta = GI->GetSubsystem<UBRMetaProgressionSubsystem>())
        {
            bPurgatoryStyle = Meta->GetSelectedMap() == EBRMapId::Purgatory;
            SelectedMode = Meta->GetSelectedMode();
        }
    }

    // Training and Lone Wolf use purpose-built compact spaces rather than the BR island.
    // The layouts are still blockout geometry; replace these with authored/licensed art later.
    if (SelectedMode == EBRGameMode::Training)
    {
        const FVector Center(0.f, -2400.f, 0.f);
        AddGround(Center, FVector(115.f, 92.f, 1.2f));
        AddRoad(Center + FVector(0,0,8), FVector(100.f, 1.5f, .15f));
        // Four firing lanes with backstops, lane separators and targets at increasing ranges.
        for (int32 Lane=0; Lane<4; ++Lane)
        {
            const float X = (Lane-1.5f)*1900.f;
            AddRoad(Center + FVector(X, 1000.f, 12.f), FVector(8.5f, 30.f, .08f));
            AddBlock(Center + FVector(X-900.f, 1000.f, 110.f), FVector(.45f, 30.f, 1.1f));
            AddBlock(Center + FVector(X+900.f, 1000.f, 110.f), FVector(.45f, 30.f, 1.1f));
            AddBlock(Center + FVector(X, 3900.f, 180.f), FVector(9.f, .55f, 1.8f));
            for (int32 Target=0; Target<3; ++Target)
            {
                const float Y = -700.f + Target*1900.f;
                AddBlock(Center + FVector(X, Y, 105.f), FVector(.45f, .45f, 1.05f));
                AddBlock(Center + FVector(X, Y, 215.f), FVector(1.2f, .22f, .22f));
            }
        }
        // Movement/parkour zone, low vaults, ramps represented as stepped cover and an obstacle course.
        for (int32 I=0; I<9; ++I)
        {
            const float X = -6500.f + I*1550.f;
            const float H = 45.f + (I%3)*55.f;
            AddBlock(Center + FVector(X, -3100.f, H), FVector(4.5f, 2.2f, .45f + (I%3)*.55f));
        }
        // Training stations and safe boundary walls.
        for (int32 I=0; I<4; ++I)
        {
            const float X = (I-1.5f)*2800.f;
            AddBlock(Center + FVector(X, -6000.f, 110.f), FVector(9.f, 3.f, 1.1f));
            AddBlock(Center + FVector(X, -6000.f, 230.f), FVector(9.4f, 3.4f, .22f));
        }
        AddBlock(Center + FVector(0, 7800.f, 260.f), FVector(112.f, .8f, 2.6f));
        AddBlock(Center + FVector(0, -7600.f, 260.f), FVector(112.f, .8f, 2.6f));
        AddBlock(Center + FVector(-9600.f, 0, 260.f), FVector(.8f, 80.f, 2.6f));
        AddBlock(Center + FVector(9600.f, 0, 260.f), FVector(.8f, 80.f, 2.6f));
        return;
    }
    if (SelectedMode == EBRGameMode::LoneWolf)
    {
        const FVector Center(0.f, -2400.f, 0.f);
        AddGround(Center, FVector(78.f, 58.f, 1.2f));
        AddRoad(Center + FVector(0,0,10), FVector(65.f, 43.f, .12f));
        // Mirrored sides create readable 1v1 sightlines and alternate cover routes.
        for (int32 Side=-1; Side<=1; Side+=2)
        {
            AddBlock(Center + FVector(Side*5700.f, 0, 160.f), FVector(.8f, 47.f, 1.6f));
            AddBlock(Center + FVector(Side*4400.f, -1800.f, 100.f), FVector(5.5f, 2.f, 1.f));
            AddBlock(Center + FVector(Side*4400.f, 1800.f, 100.f), FVector(5.5f, 2.f, 1.f));
            for (int32 Row=0; Row<3; ++Row)
            {
                const float Y=(Row-1)*2200.f;
                AddBlock(Center + FVector(Side*(2100.f + (Row%2)*600.f), Y, 125.f), FVector(2.5f, 2.8f, 1.25f));
                AddBlock(Center + FVector(Side*3400.f, Y+650.f, 55.f), FVector(4.2f, 1.1f, .55f));
            }
            // Spawn-side platforms and rear safety wall.
            AddBlock(Center + FVector(Side*4900.f, -4200.f, 65.f), FVector(6.f, 4.f, .65f));
        }
        AddBlock(Center + FVector(0, 0, 170.f), FVector(.65f, 13.f, 1.7f));
        AddBlock(Center + FVector(0, 0, 30.f), FVector(2.2f, 9.f, .3f));
        AddBlock(Center + FVector(0, 4700.f, 180.f), FVector(58.f, .8f, 1.8f));
        AddBlock(Center + FVector(0, -4700.f, 180.f), FVector(58.f, .8f, 1.8f));
        return;
    }

    const float MapRadius = bPurgatoryStyle ? 7600.f : 8500.f;
    const float RoadRadius = bPurgatoryStyle ? 3850.f : 4300.f;
    if (bPurgatoryStyle) LandmarkCount = 10; else LandmarkCount = 12;
    AddWater(FVector(0,0,-620), FVector(420,420,5));      // surrounding ocean foundation
    AddGround(FVector(0,0,-360), FVector(275,275,3));      // island landmass foundation
    AddGround(FVector(0,0,-40), FVector(245,245,0.4f));    // underlying ground

    // Tiled height variation creates playable low hills/ridges rather than a single flat slab.
    // 21 x 21 tiles at 1.1 km each cover a broad island area with deterministic terrain.
    for (int32 X=-10; X<=10; ++X)
    {
        for (int32 Y=-10; Y<=10; ++Y)
        {
            const float FX = static_cast<float>(X);
            const float FY = static_cast<float>(Y);
            const float Dist = FMath::Sqrt(FX*FX + FY*FY) / 14.2f;
            const float Ridge = bPurgatoryStyle
                ? (FMath::Sin(FX*0.42f + 1.3f) * 0.6f + FMath::Cos(FY*0.71f) * 0.4f)
                : (FMath::Sin(FX*0.63f) * 0.55f + FMath::Cos(FY*0.47f) * 0.45f);
            const float Height = FMath::Clamp((1.f-Dist) * (95.f + Ridge*115.f), 0.f, 210.f);
            AddGround(FVector(FX*1100.f, FY*1100.f, Height-18.f), FVector(11.f,11.f,.36f));
        }
    }

    // Irregular shoreline rocks and beach strips around the island edge.
    for (int32 I=0; I<64; ++I)
    {
        const float A = (2.f*PI*I)/64.f;
        const float R = (bPurgatoryStyle ? 9900.f : 10800.f) + FMath::Sin(A*(bPurgatoryStyle?7.f:5.f))*650.f;
        AddBlock(FVector(FMath::Cos(A)*R,FMath::Sin(A)*R,-4.f), FVector(2.2f,1.1f,.55f), FRotator(0,A*57.2958f,0));
        AddBlock(FVector(FMath::Cos(A)*(R+850.f),FMath::Sin(A)*(R+850.f),-70.f), FVector(7.f,5.f,.15f), FRotator(0,A*57.2958f,0));
    }

    const int32 Count = FMath::Clamp(LandmarkCount, 4, 16);
    for (int32 I=0; I<Count; ++I)
    {
        const float A = 2.f * PI * I / Count;
        const FVector C(FMath::Cos(A)*MapRadius, FMath::Sin(A)*MapRadius, 0.f);
        // Town square, small roads and roadside cover.
        AddBlock(C + FVector(0,0,12), FVector(13,13,.25f));
        AddBlock(C + FVector(0,0,18), FVector(4.5f,4.5,.12f));
        AddBlock(C + FVector(650,0,8), FVector(18.f,1.5f,.12f), FRotator(0,A*57.2958f,0));
        AddBlock(C + FVector(-650,0,8), FVector(18.f,1.5f,.12f), FRotator(0,A*57.2958f,0));

        // House 1: open-roof interior, floor and four walls with a front-door gap.
        const FVector H1 = C + FVector(300,350,0);
        AddBlock(H1 + FVector(0,0,8), FVector(10,8,.25f));              // floor
        AddBlock(H1 + FVector(0,750,160), FVector(10,.35f,3.2f));      // back wall
        AddBlock(H1 + FVector(-965,0,160), FVector(.35f,7.5f,3.2f));   // left wall
        AddBlock(H1 + FVector(965,0,160), FVector(.35f,7.5f,3.2f));    // right wall
        AddBlock(H1 + FVector(-650,-750,160), FVector(3.5f,.35f,3.2f));// front left
        AddBlock(H1 + FVector(650,-750,160), FVector(3.5f,.35f,3.2f)); // front right
        // Interior divider and a counter create traversable room space.
        AddBlock(H1 + FVector(250,100,110), FVector(.22f,3.2f,2.2f));
        AddBlock(H1 + FVector(-350,350,55), FVector(2.2f,.65f,.55f));

        // House 2 / warehouse with a wide entrance and interior support pillars.
        const FVector H2 = C + FVector(-900,-500,0);
        AddBlock(H2 + FVector(0,0,8), FVector(12,9,.25f));
        AddBlock(H2 + FVector(0,850,190), FVector(12,.4f,3.8f));
        AddBlock(H2 + FVector(-1150,0,190), FVector(.4f,8.5f,3.8f));
        AddBlock(H2 + FVector(1150,0,190), FVector(.4f,8.5f,3.8f));
        AddBlock(H2 + FVector(-800,-850,190), FVector(4.f,.4f,3.8f));
        AddBlock(H2 + FVector(800,-850,190), FVector(4.f,.4f,3.8f));
        AddBlock(H2 + FVector(-500,200,100), FVector(.35f,.35f,2.f));
        AddBlock(H2 + FVector(500,200,100), FVector(.35f,.35f,2.f));

        // Low cover and landmark tower silhouettes.
        AddBlock(C + FVector(1500,650,45), FVector(3.5f,.6f,.45f));
        AddBlock(C + FVector(-1500,650,45), FVector(3.5f,.6f,.45f));
        AddBlock(C + FVector(1250,-950,110), FVector(1.2f,1.2f,1.1f));
    }

    // Additional low-poly structures per district: small homes, a long warehouse, and stair/roof silhouettes.
    for (int32 I=0; I<Count; ++I)
    {
        const float A = (2.f*PI*I)/Count;
        const FVector C(FMath::Cos(A)*MapRadius, FMath::Sin(A)*MapRadius, 0.f);
        for (int32 B=0; B<3; ++B)
        {
            const float Side = (B-1)*1050.f;
            const FVector H = C + FVector(Side, 1450.f + (B%2)*700.f, 0.f);
            AddBlock(H+FVector(0,0,8), FVector(6.5f,5.5f,.25f)); // floor
            AddBlock(H+FVector(0,520,120), FVector(6.5f,.25f,2.4f));
            AddBlock(H+FVector(-650,0,120), FVector(.25f,5.2f,2.4f));
            AddBlock(H+FVector(650,0,120), FVector(.25f,5.2f,2.4f));
            AddBlock(H+FVector(-390,-520,120), FVector(2.5f,.25f,2.4f));
            AddBlock(H+FVector(390,-520,120), FVector(2.5f,.25f,2.4f)); // door gap between walls
            AddBlock(H+FVector(0,0,255), FVector(7.1f,6.1f,.3f)); // flat roof silhouette
        }
        // Industrial storage row and lookout platform at alternating landmarks.
        if (I%2==0)
        {
            const FVector W=C+FVector(-1900.f,350.f,0.f);
            AddBlock(W+FVector(0,0,10), FVector(14.f,8.f,.3f));
            AddBlock(W+FVector(0,780,170), FVector(14.f,.35f,3.4f));
            AddBlock(W+FVector(-1350,0,170), FVector(.35f,8.f,3.4f));
            AddBlock(W+FVector(1350,0,170), FVector(.35f,8.f,3.4f));
            AddBlock(W+FVector(-850,-780,170), FVector(5.f,.35f,3.4f));
            AddBlock(W+FVector(850,-780,170), FVector(5.f,.35f,3.4f));
            AddBlock(W+FVector(1700,1300,250), FVector(2.4f,2.4f,5.f));
        }
    }

    // Primitive tree silhouettes and rock cover provide landmarks and combat cover.
    FRandomStream FoliageRandom(2019);
    for (int32 I=0; I<180; ++I)
    {
        const float A=FoliageRandom.FRandRange(0.f,2.f*PI);
        const float R=FMath::Sqrt(FoliageRandom.FRand())*9800.f;
        const FVector P(FMath::Cos(A)*R,FMath::Sin(A)*R,0.f);
        const float S=FoliageRandom.FRandRange(.65f,1.35f);
        AddBlock(P+FVector(0,0,85.f*S), FVector(.42f*S,.42f*S,1.7f*S)); // trunk proxy
        AddCanopy(P+FVector(0,0,235.f*S), FVector(1.55f*S,1.45f*S,1.35f*S)); // rounded foliage canopy
        if (I%3==0) AddBlock(P+FVector(220.f,80.f,28.f), FVector(1.25f*S,.9f*S,.5f*S));
    }

    // Road spokes from the hub to each district, plus a central compound.
    for (int32 I=0; I<Count; ++I)
    {
        const float A = 2.f * PI * I / Count;
        const FVector Mid(FMath::Cos(A)*RoadRadius,FMath::Sin(A)*RoadRadius,4.f);
        AddRoad(Mid, FVector(44.f,2.6f,.12f), FRotator(0,A*57.2958f,0));
        // road-edge barriers at selected intervals
        for (int32 J=1; J<=3; ++J)
        {
            const FVector Edge(FMath::Cos(A)*RoadRadius - FMath::Sin(A)*J*900.f,
                               FMath::Sin(A)*RoadRadius + FMath::Cos(A)*J*900.f,35.f);
            AddBlock(Edge,FVector(1.8f,.28f,.35f),FRotator(0,A*57.2958f,0));
        }
    }
    AddRoad(FVector(0,0,30), FVector(18,18,.3f));
    AddBlock(FVector(0,0,100), FVector(5,5,1.f));
    // Low-profile concrete pads and roadside markers add visual rhythm without actor spam.
    for (int32 I=0; I<48; ++I)
    {
        const float A = (2.f*PI*I)/48.f;
        const float R = 5200.f + 450.f*FMath::Sin(A*5.f);
        AddBlock(FVector(FMath::Cos(A)*R,FMath::Sin(A)*R,16.f), FVector(1.4f,.35f,.28f), FRotator(0,A*57.2958f,0));
    }
    for (int32 I=0; I<36; ++I)
    {
        const float A = I * 2.399963f;
        const float R = 1800.f + (I%6)*700.f;
        AddBlock(FVector(FMath::Cos(A)*R,FMath::Sin(A)*R,45.f),
                 FVector(1.8f,1.2f,.8f),FRotator(0,A*57.2958f,0));
    }
}
void ABRWorldBuilderActor::AddCanopy(const FVector& Location, const FVector& Scale)
{
    if (CanopyInstances && CanopyMesh)
        CanopyInstances->AddInstance(FTransform(FRotator::ZeroRotator, Location, Scale));
}

void ABRWorldBuilderActor::AddGround(const FVector& Location, const FVector& Scale, const FRotator& Rotation)
{
    if (GroundInstances && CubeMesh) GroundInstances->AddInstance(FTransform(Rotation, Location, Scale));
}
void ABRWorldBuilderActor::AddWater(const FVector& Location, const FVector& Scale, const FRotator& Rotation)
{
    if (WaterInstances && CubeMesh) WaterInstances->AddInstance(FTransform(Rotation, Location, Scale));
}
void ABRWorldBuilderActor::AddRoad(const FVector& Location, const FVector& Scale, const FRotator& Rotation)
{
    if (RoadInstances && CubeMesh) RoadInstances->AddInstance(FTransform(Rotation, Location, Scale));
}
void ABRWorldBuilderActor::AddBlock(const FVector& Location, const FVector& Scale, const FRotator& Rotation)
{
    if (!BlockInstances || !CubeMesh) return;
    // One instanced mesh component keeps the greybox map far cheaper than thousands of actors/components.
    BlockInstances->AddInstance(FTransform(Rotation, Location, Scale));
}
