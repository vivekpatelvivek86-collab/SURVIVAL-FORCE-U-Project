#include "BRPetCompanion.h"
#include "BRPlayerCharacter.h"
#include "Components/StaticMeshComponent.h"
#include "UObject/ConstructorHelpers.h"

ABRPetCompanion::ABRPetCompanion()
{
    PrimaryActorTick.bCanEverTick = true;
    SetActorTickInterval(0.05f);
    PetVisual = CreateDefaultSubobject<UStaticMeshComponent>(TEXT("OriginalPetProxy"));
    SetRootComponent(PetVisual);
    PetVisual->SetCollisionEnabled(ECollisionEnabled::NoCollision);
    static ConstructorHelpers::FObjectFinder<UStaticMesh> Mesh(TEXT("/Engine/BasicShapes/Sphere.Sphere"));
    if (Mesh.Succeeded()) PetVisual->SetStaticMesh(Mesh.Object);
    PetVisual->SetRelativeScale3D(FVector(0.35f,0.35f,0.35f));
}
void ABRPetCompanion::BeginPlay()
{
    Super::BeginPlay();
    if (!FollowTarget.IsValid()) FollowTarget = Cast<ABRPlayerCharacter>(GetWorld()->GetFirstPlayerController() ? GetWorld()->GetFirstPlayerController()->GetPawn() : nullptr);
}
void ABRPetCompanion::Tick(float DeltaSeconds)
{
    Super::Tick(DeltaSeconds);
    ABRPlayerCharacter* Player = FollowTarget.Get();
    if (!Player || Player->Health <= 0.f) return;
    const FVector Desired = Player->GetActorLocation() - Player->GetActorForwardVector()*FollowDistance + FVector(0.f,0.f,FollowHeight);
    SetActorLocation(FMath::VInterpTo(GetActorLocation(), Desired, DeltaSeconds, 5.f));
    SetActorRotation(FMath::RInterpTo(GetActorRotation(), Player->GetActorRotation(), DeltaSeconds, 3.f));
}
