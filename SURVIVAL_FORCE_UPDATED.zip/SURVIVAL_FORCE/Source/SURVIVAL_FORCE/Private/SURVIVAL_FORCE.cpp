#include "Modules/ModuleManager.h"
IMPLEMENT_PRIMARY_GAME_MODULE(FDefaultGameModuleImpl, SURVIVAL_FORCE, "SURVIVAL_FORCE");
