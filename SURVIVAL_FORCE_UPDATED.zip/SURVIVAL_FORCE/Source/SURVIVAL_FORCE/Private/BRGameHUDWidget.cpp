#include "BRGameHUDWidget.h"
#include "BRActionButton.h"
#include "BRPlayerCharacter.h"
#include "Blueprint/WidgetTree.h"
#include "Components/CanvasPanel.h"
#include "Components/CanvasPanelSlot.h"
#include "Components/Border.h"
#include "Components/ProgressBar.h"
#include "Components/TextBlock.h"
#include "Components/Button.h"
#include "GameFramework/PlayerController.h"
#include "Kismet/GameplayStatics.h"

namespace
{
    UTextBlock* AddLabel(UWidgetTree* Tree, UCanvasPanel* Canvas, const TCHAR* Name, const FString& Text, FVector2D Position, FVector2D Size, int32 FontSize, FLinearColor Color)
    {
        UTextBlock* Label = Tree->ConstructWidget<UTextBlock>(UTextBlock::StaticClass(), FName(Name));
        Label->SetText(FText::FromString(Text));
        Label->SetColorAndOpacity(FSlateColor(Color));
        FSlateFontInfo Font = Label->GetFont(); Font.Size = FontSize; Label->SetFont(Font);
        if (UCanvasPanelSlot* Slot = Canvas->AddChildToCanvas(Label)) { Slot->SetPosition(Position); Slot->SetSize(Size); }
        return Label;
    }
}

void UBRGameHUDWidget::NativeConstruct()
{
    Super::NativeConstruct();
    if (!WidgetTree) return;
    UCanvasPanel* Canvas = WidgetTree->ConstructWidget<UCanvasPanel>(UCanvasPanel::StaticClass(), TEXT("HUDCanvas"));
    WidgetTree->RootWidget = Canvas;

    // Dark, translucent-feeling panel blocks; kept lightweight for mobile.
    UBorder* HealthPanel = WidgetTree->ConstructWidget<UBorder>(UBorder::StaticClass(), TEXT("HealthPanel"));
    HealthPanel->SetBrushColor(FLinearColor(0.025f, 0.035f, 0.045f, 0.82f));
    if (UCanvasPanelSlot* S = Canvas->AddChildToCanvas(HealthPanel)) { S->SetPosition(FVector2D(28, 28)); S->SetSize(FVector2D(260, 70)); }
    HealthText = AddLabel(WidgetTree, Canvas, TEXT("HealthText"), TEXT("HP 100 / 100"), FVector2D(42, 32), FVector2D(220, 28), 22, FLinearColor::White);
    HealthBar = WidgetTree->ConstructWidget<UProgressBar>(UProgressBar::StaticClass(), TEXT("HealthBar"));
    HealthBar->SetPercent(1.f); HealthBar->SetFillColorAndOpacity(FLinearColor(0.95f, 0.72f, 0.12f, 1.f));
    if (UCanvasPanelSlot* S = Canvas->AddChildToCanvas(HealthBar)) { S->SetPosition(FVector2D(42, 62)); S->SetSize(FVector2D(225, 14)); }

    UBorder* AmmoPanel = WidgetTree->ConstructWidget<UBorder>(UBorder::StaticClass(), TEXT("AmmoPanel"));
    AmmoPanel->SetBrushColor(FLinearColor(0.025f, 0.035f, 0.045f, 0.82f));
    if (UCanvasPanelSlot* S = Canvas->AddChildToCanvas(AmmoPanel)) { S->SetAnchors(FAnchors(1.f, 1.f)); S->SetAlignment(FVector2D(1.f, 1.f)); S->SetPosition(FVector2D(-36, -34)); S->SetSize(FVector2D(220, 82)); }
    AmmoText = AddLabel(WidgetTree, Canvas, TEXT("AmmoText"), TEXT("RIFLE   30 / 30"), FVector2D(0, 0), FVector2D(200, 42), 25, FLinearColor(1.f, 0.78f, 0.12f, 1.f));
    if (UCanvasPanelSlot* S = Cast<UCanvasPanelSlot>(AmmoText->Slot)) { S->SetAnchors(FAnchors(1.f, 1.f)); S->SetAlignment(FVector2D(1.f, 1.f)); S->SetPosition(FVector2D(-48, -55)); }

    StatusText = AddLabel(WidgetTree, Canvas, TEXT("StatusText"), TEXT("SURVIVAL FORCE  •  OFFLINE MATCH"), FVector2D(0, 28), FVector2D(500, 36), 18, FLinearColor(1.f, 0.78f, 0.12f, 1.f));
    if (UCanvasPanelSlot* S = Cast<UCanvasPanelSlot>(StatusText->Slot)) { S->SetAnchors(FAnchors(0.5f, 0.f)); S->SetAlignment(FVector2D(0.5f, 0.f)); }
    UTextBlock* ControlsHint = AddLabel(WidgetTree, Canvas, TEXT("ControlsHint"), TEXT("WASD MOVE   MOUSE AIM   LMB FIRE   R RELOAD   SPACE JUMP"), FVector2D(0, -18), FVector2D(650, 24), 13, FLinearColor(0.9f, 0.9f, 0.9f, 0.9f));
    if (UCanvasPanelSlot* S = Cast<UCanvasPanelSlot>(ControlsHint->Slot)) { S->SetAnchors(FAnchors(0.5f, 1.f)); S->SetAlignment(FVector2D(0.5f, 1.f)); S->SetPosition(FVector2D(0, -18)); }
    AimText = AddLabel(WidgetTree, Canvas, TEXT("AimText"), TEXT("+"), FVector2D(0, 0), FVector2D(40, 40), 32, FLinearColor::White);
    if (UCanvasPanelSlot* S = Cast<UCanvasPanelSlot>(AimText->Slot)) { S->SetAnchors(FAnchors(0.5f, 0.5f)); S->SetAlignment(FVector2D(0.5f, 0.5f)); }

    // Large, touch-friendly action buttons. Movement/look remain on Unreal's virtual joysticks.
    auto AddTouchButton = [this, Canvas](const TCHAR* Name, const TCHAR* Label, FVector2D Position, TFunction<void(ABRPlayerCharacter*)> Action)
    {
        UBRActionButton* Button = WidgetTree->ConstructWidget<UBRActionButton>(UBRActionButton::StaticClass(), FName(Name));
        Button->SetBackgroundColor(FLinearColor(0.08f,0.11f,0.14f,0.88f));
        UTextBlock* Text = WidgetTree->ConstructWidget<UTextBlock>(UTextBlock::StaticClass());
        Text->SetText(FText::FromString(Label)); Text->SetJustification(ETextJustify::Center);
        FSlateFontInfo Font=Text->GetFont(); Font.Size=16; Text->SetFont(Font); Text->SetColorAndOpacity(FSlateColor(FLinearColor(1.f,0.82f,0.35f,1.f)));
        Button->SetContent(Text);
        if (UCanvasPanelSlot* Slot=Canvas->AddChildToCanvas(Button)) { Slot->SetAnchors(FAnchors(1.f,1.f)); Slot->SetAlignment(FVector2D(1.f,1.f)); Slot->SetPosition(Position); Slot->SetSize(FVector2D(104.f,66.f)); }
        Button->SetAction([this, Action]() { if (ABRPlayerCharacter* P=Cast<ABRPlayerCharacter>(UGameplayStatics::GetPlayerCharacter(this,0))) Action(P); });
    };
    AddTouchButton(TEXT("TouchFire"),TEXT("FIRE"),FVector2D(-26.f,-112.f),[](ABRPlayerCharacter* P){P->FireWeapon();});
    AddTouchButton(TEXT("TouchJump"),TEXT("JUMP"),FVector2D(-142.f,-112.f),[](ABRPlayerCharacter* P){P->Jump();});
    AddTouchButton(TEXT("TouchReload"),TEXT("RELOAD"),FVector2D(-26.f,-188.f),[](ABRPlayerCharacter* P){P->ReloadWeapon();});
    AddTouchButton(TEXT("TouchMedkit"),TEXT("MEDKIT"),FVector2D(-142.f,-188.f),[](ABRPlayerCharacter* P){P->UseMedkit();});
    AddTouchButton(TEXT("TouchAbility"),TEXT("ABILITY"),FVector2D(-258.f,-112.f),[](ABRPlayerCharacter* P){P->ActivateSelectedAbility();});
    AddTouchButton(TEXT("TouchWeapon"),TEXT("NEXT GUN"),FVector2D(-258.f,-188.f),[](ABRPlayerCharacter* P){P->SwitchWeaponNext();});
}

void UBRGameHUDWidget::NativeTick(const FGeometry& MyGeometry, float InDeltaTime)
{
    Super::NativeTick(MyGeometry, InDeltaTime);
    ABRPlayerCharacter* Player = Cast<ABRPlayerCharacter>(UGameplayStatics::GetPlayerCharacter(this, 0));
    if (!Player) return;
    if (HealthText) HealthText->SetText(FText::FromString(FString::Printf(TEXT("HP  %d / %d"), FMath::RoundToInt(Player->Health), FMath::RoundToInt(Player->MaxHealth))));
    if (HealthBar) HealthBar->SetPercent(Player->MaxHealth > 0.f ? Player->Health / Player->MaxHealth : 0.f);
    if (AmmoText)
    {
        const TCHAR* WeaponLabel = TEXT("RIFLE");
        switch (Player->CurrentWeapon)
        {
            case EBRWeaponType::AssaultRifle: WeaponLabel = TEXT("ASSAULT RIFLE"); break;
            case EBRWeaponType::SMG: WeaponLabel = TEXT("SMG"); break;
            case EBRWeaponType::Shotgun: WeaponLabel = TEXT("SHOTGUN"); break;
            case EBRWeaponType::Sniper: WeaponLabel = TEXT("SNIPER"); break;
            default: break;
        }
        AmmoText->SetText(FText::FromString(FString::Printf(TEXT("%s   %02d / %02d  |  RESERVE %03d"), WeaponLabel, Player->AmmoInMagazine, Player->MagazineSize, Player->ReserveAmmo)));
    }
}
