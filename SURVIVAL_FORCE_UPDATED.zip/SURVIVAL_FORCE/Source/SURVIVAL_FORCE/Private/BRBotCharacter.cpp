#include "BRBotCharacter.h"
#include "BRPlayerCharacter.h"
#include "BRLootPickup.h"
#include "GameFramework/CharacterMovementComponent.h"
#include "Kismet/GameplayStatics.h"
#include "Components/StaticMeshComponent.h"
#include "UObject/ConstructorHelpers.h"
#include "Engine/World.h"
ABRBotCharacter::ABRBotCharacter()
{
    PrimaryActorTick.bCanEverTick = true;
    GetCharacterMovement()->MaxWalkSpeed = MoveSpeed;
    static ConstructorHelpers::FObjectFinder<UStaticMesh> CapsuleAsset(TEXT("/Engine/BasicShapes/Capsule.Capsule"));
    if (CapsuleAsset.Succeeded())
    {
        UStaticMeshComponent* Proxy = CreateDefaultSubobject<UStaticMeshComponent>(TEXT("BotRuntimeVisual"));
        Proxy->SetStaticMesh(CapsuleAsset.Object); Proxy->SetupAttachment(GetRootComponent());
        Proxy->SetRelativeLocation(FVector(0.f,0.f,-8.f)); Proxy->SetRelativeScale3D(FVector(.42f,.42f,.82f));
        Proxy->SetCollisionEnabled(ECollisionEnabled::NoCollision);
    }
}
void ABRBotCharacter::BeginPlay() { Super::BeginPlay(); }
void ABRBotCharacter::Tick(float DeltaSeconds)
{
    Super::Tick(DeltaSeconds);
    if (Health <= 0.f || !GetWorld()) return;
    TargetRefreshClock -= DeltaSeconds;
    if (TargetRefreshClock <= 0.f || !CurrentTarget.IsValid())
    {
        RefreshTarget();
        TargetRefreshClock = 0.35f;
    }
    AActor* Target = CurrentTarget.Get();
    if (!Target) return;
    FVector Delta = Target->GetActorLocation() - GetActorLocation(); Delta.Z = 0.f;
    const float Dist = Delta.Size();
    if (!Delta.IsNearlyZero()) SetActorRotation(FMath::RInterpTo(GetActorRotation(), Delta.Rotation(), DeltaSeconds, 3.5f));

    // Keep the prototype bots mobile instead of running in a perfectly straight line.
    // A short strafe pulse makes combat less static while keeping the logic inexpensive on Android.
    StrafeChangeClock -= DeltaSeconds;
    if (StrafeChangeClock <= 0.f)
    {
        StrafeSign = FMath::RandBool() ? 1.f : -1.f;
        StrafeChangeClock = FMath::FRandRange(0.7f, 1.5f);
    }
    if (Dist > 180.f)
    {
        const FVector ToTarget = Delta.GetSafeNormal();
        if (Dist > AttackRange * 0.8f) AddMovementInput(ToTarget, 0.65f);
        else if (Dist < AttackRange * 0.35f) AddMovementInput(-ToTarget, 0.22f);
        const FVector Sideways(-ToTarget.Y, ToTarget.X, 0.f);
        AddMovementInput(Sideways, CombatMoveScale * StrafeSign);
    }
    if (Dist <= AttackRange && GetWorld()->GetTimeSeconds() >= NextAttackTime)
    {
        NextAttackTime = GetWorld()->GetTimeSeconds() + AttackInterval;
        FHitResult Hit; FCollisionQueryParams Params(SCENE_QUERY_STAT(BotAttack), true, this);
        const FVector Start = GetActorLocation() + FVector(0,0,60); const FVector End = Target->GetActorLocation() + FVector(0,0,45);
        if (GetWorld()->LineTraceSingleByChannel(Hit, Start, End, ECC_Visibility, Params) && Hit.GetActor() == Target)
        {
            if (ABRPlayerCharacter* HitPlayer = Cast<ABRPlayerCharacter>(Target)) HitPlayer->ReceiveDamage(AttackDamage);
            else if (ABRBotCharacter* HitBot = Cast<ABRBotCharacter>(Target)) HitBot->ReceiveDamage(AttackDamage);
        }
    }
}
void ABRBotCharacter::RefreshTarget()
{
    AActor* BestTarget = nullptr;
    float BestDistance = TNumericLimits<float>::Max();
    ABRPlayerCharacter* Player = Cast<ABRPlayerCharacter>(UGameplayStatics::GetPlayerCharacter(this, 0));
    if (Player && Player->Health > 0.f && Player->TeamId != TeamId)
    {
        const float D2 = FVector::DistSquared(Player->GetActorLocation(), GetActorLocation());
        if (D2 <= FMath::Square(AwarenessRange))
        {
            BestTarget = Player;
            BestDistance = D2;
        }
    }
    if (bCanAttackBots)
    {
        TArray<AActor*> AllBots;
        UGameplayStatics::GetAllActorsOfClass(this, ABRBotCharacter::StaticClass(), AllBots);
        for (AActor* Actor : AllBots)
        {
            ABRBotCharacter* Candidate = Cast<ABRBotCharacter>(Actor);
            if (!Candidate || Candidate == this || Candidate->Health <= 0.f || Candidate->TeamId == TeamId) continue;
            const float D2 = FVector::DistSquared(Candidate->GetActorLocation(), GetActorLocation());
            if (D2 <= FMath::Square(AwarenessRange) && D2 < BestDistance) { BestDistance = D2; BestTarget = Candidate; }
        }
    }
    CurrentTarget = BestTarget;
}
void ABRBotCharacter::ReceiveDamage(float Amount)
{
    if (Health <= 0.f || Amount <= 0.f) return;
    Health = FMath::Max(0.f, Health - Amount);
    if (Health <= 0.f) { DropLoot(); Destroy(); }
}
void ABRBotCharacter::DropLoot()
{
    if (!GetWorld() || FMath::FRand() > 0.72f) return;
    const FVector DropLocation = GetActorLocation() + FVector(0.f, 0.f, 45.f);
    FActorSpawnParameters Params; Params.SpawnCollisionHandlingOverride = ESpawnActorCollisionHandlingMethod::AdjustIfPossibleButAlwaysSpawn;
    if (ABRLootPickup* Pickup = GetWorld()->SpawnActor<ABRLootPickup>(ABRLootPickup::StaticClass(), DropLocation, FRotator::ZeroRotator, Params))
    {
        const int32 Roll = FMath::RandRange(0, 2);
        Pickup->LootType = Roll == 0 ? EBRLootType::Ammo : (Roll == 1 ? EBRLootType::Medkit : EBRLootType::Armor);
        Pickup->Amount = Roll == 0 ? 30 : (Roll == 1 ? 1 : 15);
    }
}
