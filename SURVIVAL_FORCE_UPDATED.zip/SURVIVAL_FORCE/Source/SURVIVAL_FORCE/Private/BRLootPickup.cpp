#include "BRLootPickup.h"
#include "BRPlayerCharacter.h"
#include "Components/SphereComponent.h"
#include "Components/StaticMeshComponent.h"
#include "UObject/ConstructorHelpers.h"

ABRLootPickup::ABRLootPickup()
{
    PrimaryActorTick.bCanEverTick = false;
    Trigger = CreateDefaultSubobject<USphereComponent>(TEXT("PickupTrigger"));
    SetRootComponent(Trigger); Trigger->SetSphereRadius(115.f);
    Trigger->SetCollisionEnabled(ECollisionEnabled::QueryOnly);
    Trigger->SetCollisionResponseToAllChannels(ECR_Ignore);
    Trigger->SetCollisionResponseToChannel(ECC_Pawn, ECR_Overlap);
    Visual = CreateDefaultSubobject<UStaticMeshComponent>(TEXT("PickupVisual"));
    Visual->SetupAttachment(Trigger); Visual->SetCollisionEnabled(ECollisionEnabled::NoCollision);
    static ConstructorHelpers::FObjectFinder<UStaticMesh> SphereMesh(TEXT("/Engine/BasicShapes/Sphere.Sphere"));
    if (SphereMesh.Succeeded()) Visual->SetStaticMesh(SphereMesh.Object);
    Visual->SetRelativeScale3D(FVector(.38f));
}
void ABRLootPickup::BeginPlay()
{
    Super::BeginPlay();
    if (Trigger) Trigger->OnComponentBeginOverlap.AddDynamic(this, &ABRLootPickup::OnOverlap);
}
void ABRLootPickup::OnOverlap(UPrimitiveComponent*, AActor* OtherActor, UPrimitiveComponent*, int32, bool, const FHitResult&)
{
    ABRPlayerCharacter* Player = Cast<ABRPlayerCharacter>(OtherActor);
    if (!Player || Player->Health <= 0.f) return;
    switch (LootType)
    {
        case EBRLootType::Ammo: Player->AddReserveAmmo(Amount); break;
        case EBRLootType::Medkit: Player->Medkits = FMath::Clamp(Player->Medkits + Amount, 0, 5); break;
        case EBRLootType::Armor: Player->AddArmor(static_cast<float>(Amount)); break;
        case EBRLootType::WeaponUpgrade: Player->WeaponDamage = FMath::Clamp(Player->WeaponDamage + 2.f, 20.f, 100.f); break;
        default: break;
    }
    Destroy();
}
