#include "BRSafeZoneActor.h"
#include "BRPlayerCharacter.h"
#include "BRBotCharacter.h"
#include "Kismet/GameplayStatics.h"
#include "DrawDebugHelpers.h"
ABRSafeZoneActor::ABRSafeZoneActor() { PrimaryActorTick.bCanEverTick = true; SetActorTickInterval(0.1f); }
void ABRSafeZoneActor::BeginPlay() { Super::BeginPlay(); }
void ABRSafeZoneActor::Tick(float DeltaSeconds)
{
    Super::Tick(DeltaSeconds); Radius = FMath::Max(MinimumRadius, Radius - ShrinkPerSecond * DeltaSeconds);
    DrawDebugSphere(GetWorld(), GetActorLocation(), Radius, 48, FColor::Cyan, false, 0.12f, 0, 5.f);
    DamageClock += DeltaSeconds; if (DamageClock < DamageInterval) return; DamageClock = 0.f;
    TArray<AActor*> Actors;
    UGameplayStatics::GetAllActorsOfClass(GetWorld(), ABRPlayerCharacter::StaticClass(), Actors);
    TArray<AActor*> Bots;
    UGameplayStatics::GetAllActorsOfClass(GetWorld(), ABRBotCharacter::StaticClass(), Bots);
    Actors.Append(Bots);
    for (AActor* A : Actors) if (A && FVector::Dist2D(A->GetActorLocation(), GetActorLocation()) > Radius)
    {
        if (ABRPlayerCharacter* P = Cast<ABRPlayerCharacter>(A)) P->ReceiveDamage(DamagePerSecond * DamageInterval);
        else if (ABRBotCharacter* B = Cast<ABRBotCharacter>(A)) B->ReceiveDamage(DamagePerSecond * DamageInterval);
    }
}
