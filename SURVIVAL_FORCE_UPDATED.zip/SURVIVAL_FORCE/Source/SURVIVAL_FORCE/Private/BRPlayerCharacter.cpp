#include "BRPlayerCharacter.h"
#include "BRBotCharacter.h"
#include "BRMetaProgressionSubsystem.h"
#include "Kismet/GameplayStatics.h"
#include "DrawDebugHelpers.h"
#include "Camera/CameraComponent.h"
#include "GameFramework/SpringArmComponent.h"
#include "GameFramework/CharacterMovementComponent.h"
#include "Components/CapsuleComponent.h"
#include "Components/StaticMeshComponent.h"
#include "UObject/ConstructorHelpers.h"
#include "Engine/World.h"
#include "TimerManager.h"

ABRPlayerCharacter::ABRPlayerCharacter()
{
    PrimaryActorTick.bCanEverTick = true;
    CameraArm = CreateDefaultSubobject<USpringArmComponent>(TEXT("CameraArm"));
    CameraArm->SetupAttachment(GetRootComponent());
    CameraArm->TargetArmLength = DefaultCameraArmLength;
    CameraArm->bUsePawnControlRotation = true;
    UCameraComponent* Camera = CreateDefaultSubobject<UCameraComponent>(TEXT("ThirdPersonCamera"));
    Camera->SetupAttachment(CameraArm, USpringArmComponent::SocketName);
    Camera->bUsePawnControlRotation = false;
    bUseControllerRotationYaw = false;
    GetCharacterMovement()->bOrientRotationToMovement = true;
    GetCharacterMovement()->RotationRate = FRotator(0.f, 540.f, 0.f);
    GetCharacterMovement()->MaxWalkSpeed = 540.f;
    GetCharacterMovement()->JumpZVelocity = 480.f;
    GetCharacterMovement()->AirControl = 0.32f;
    static ConstructorHelpers::FObjectFinder<UStaticMesh> BodyAsset(TEXT("/Engine/BasicShapes/Capsule.Capsule"));
    if (BodyAsset.Succeeded())
    {
        BodyVisual = CreateDefaultSubobject<UStaticMeshComponent>(TEXT("RuntimeBodyVisual"));
        BodyVisual->SetStaticMesh(BodyAsset.Object);
        BodyVisual->SetupAttachment(GetRootComponent());
        BodyVisual->SetRelativeLocation(FVector(0.f, 0.f, -8.f));
        BodyVisual->SetRelativeScale3D(FVector(0.42f, 0.42f, 0.82f));
        BodyVisual->SetCollisionEnabled(ECollisionEnabled::NoCollision);
    }
    static ConstructorHelpers::FObjectFinder<UStaticMesh> WeaponAsset(TEXT("/Engine/BasicShapes/Cube.Cube"));
    if (WeaponAsset.Succeeded())
    {
        WeaponVisual = CreateDefaultSubobject<UStaticMeshComponent>(TEXT("RuntimeWeaponVisual"));
        WeaponVisual->SetStaticMesh(WeaponAsset.Object);
        WeaponVisual->SetupAttachment(GetRootComponent());
        WeaponVisual->SetRelativeLocation(FVector(35.f, 16.f, 48.f));
        WeaponVisual->SetRelativeRotation(FRotator(0.f, 0.f, 0.f));
        WeaponVisual->SetRelativeScale3D(FVector(0.42f, 0.07f, 0.08f));
        WeaponVisual->SetCollisionEnabled(ECollisionEnabled::NoCollision);
    }
}
void ABRPlayerCharacter::BeginPlay()
{
    Super::BeginPlay(); Health = MaxHealth; AmmoInMagazine = MagazineSize; NormalSpeed = GetCharacterMovement()->MaxWalkSpeed;
    WeaponMagazines = {30,36,6,5}; WeaponReserves = {120,150,24,20};
    if (CameraArm) DefaultCameraArmLength = CameraArm->TargetArmLength;
    TriggerPetPassive(); OnHealthChanged(Health, MaxHealth);
}
void ABRPlayerCharacter::Tick(float DeltaSeconds) { Super::Tick(DeltaSeconds); }
void ABRPlayerCharacter::SetupPlayerInputComponent(UInputComponent* Input)
{
    Super::SetupPlayerInputComponent(Input);
    Input->BindAxis("MoveForward", this, &ABRPlayerCharacter::MoveForward);
    Input->BindAxis("MoveRight", this, &ABRPlayerCharacter::MoveRight);
    Input->BindAxis("Turn", this, &ABRPlayerCharacter::Turn);
    Input->BindAxis("LookUp", this, &ABRPlayerCharacter::LookUp);
    Input->BindAction("Jump", IE_Pressed, this, &ABRPlayerCharacter::StartJump);
    Input->BindAction("Fire", IE_Pressed, this, &ABRPlayerCharacter::FireWeapon);
    Input->BindAction("Reload", IE_Pressed, this, &ABRPlayerCharacter::ReloadWeapon);
    Input->BindAction("Sprint", IE_Pressed, this, &ABRPlayerCharacter::StartSprint);
    Input->BindAction("Sprint", IE_Released, this, &ABRPlayerCharacter::StopSprint);
    Input->BindAction("Crouch", IE_Pressed, this, &ABRPlayerCharacter::ToggleCrouch);
    Input->BindAction("Aim", IE_Pressed, this, &ABRPlayerCharacter::AimPressed);
    Input->BindAction("Aim", IE_Released, this, &ABRPlayerCharacter::AimReleased);
    Input->BindAction("Medkit", IE_Pressed, this, &ABRPlayerCharacter::UseMedkit);
    Input->BindAction("Ability", IE_Pressed, this, &ABRPlayerCharacter::ActivateAbilityInput);
    Input->BindAction("NextWeapon", IE_Pressed, this, &ABRPlayerCharacter::SwitchWeaponNext);
    Input->BindAction("PreviousWeapon", IE_Pressed, this, &ABRPlayerCharacter::SwitchWeaponPrevious);
}
void ABRPlayerCharacter::MoveForward(float V) { if (Controller && FMath::Abs(V)>KINDA_SMALL_NUMBER) AddMovementInput(FRotationMatrix(FRotator(0, Controller->GetControlRotation().Yaw, 0)).GetUnitAxis(EAxis::X), V); }
void ABRPlayerCharacter::MoveRight(float V) { if (Controller && FMath::Abs(V)>KINDA_SMALL_NUMBER) AddMovementInput(FRotationMatrix(FRotator(0, Controller->GetControlRotation().Yaw, 0)).GetUnitAxis(EAxis::Y), V); }
void ABRPlayerCharacter::Turn(float V) { AddControllerYawInput(V); }
void ABRPlayerCharacter::LookUp(float V) { AddControllerPitchInput(V); }
void ABRPlayerCharacter::StartJump() { Jump(); }
void ABRPlayerCharacter::ReceiveDamage(float Amount)
{
    if (Health <= 0.f || Amount <= 0.f) return;
    const float SafeReduction = FMath::Clamp(ArmorDamageReduction, 0.f, 0.85f);
    const float Absorbed = FMath::Min(Armor, Amount * SafeReduction);
    Armor = FMath::Max(0.f, Armor - Absorbed);
    const float FinalDamage = Amount - Absorbed;
    Health = FMath::Clamp(Health - FinalDamage, 0.f, MaxHealth);
    OnHealthChanged(Health, MaxHealth);
    if (Health <= 0.f) { GetCharacterMovement()->DisableMovement(); OnEliminated(); }
}
void ABRPlayerCharacter::FireWeapon()
{
    const float Now = GetWorld()->GetTimeSeconds();
    if (Health <= 0.f || bReloading || AmmoInMagazine <= 0 || Now - LastFireTime < FireCooldown || !Controller) return;
    LastFireTime = Now; --AmmoInMagazine;
    FVector Start; FRotator Rot; Controller->GetPlayerViewPoint(Start, Rot);
    FCollisionQueryParams Params(SCENE_QUERY_STAT(WeaponTrace), true, this);
    const int32 PelletCount = CurrentWeapon == EBRWeaponType::Shotgun ? 6 : 1;
    for (int32 Pellet = 0; Pellet < PelletCount; ++Pellet)
    {
        FRotator ShotRotation = Rot;
        const float Spread = CurrentWeapon == EBRWeaponType::Shotgun ? 5.0f : (CurrentWeapon == EBRWeaponType::SMG ? 1.1f : 0.35f);
        ShotRotation.Yaw += FMath::FRandRange(-Spread, Spread);
        ShotRotation.Pitch += FMath::FRandRange(-Spread, Spread);
        FHitResult Hit;
        const FVector End = Start + ShotRotation.Vector() * WeaponRange;
        if (GetWorld()->LineTraceSingleByChannel(Hit, Start, End, ECC_Visibility, Params))
        {
            if (ABRBotCharacter* Bot = Cast<ABRBotCharacter>(Hit.GetActor()))
            {
                if (Bot->TeamId != TeamId)
                {
                    const bool bHeadshot = Hit.ImpactPoint.Z >= Bot->GetActorLocation().Z + 58.f;
                    const float Falloff = FMath::GetMappedRangeValueClamped(FVector2D(0.f, WeaponRange), FVector2D(1.f, 0.58f), Hit.Distance);
                    const float PelletDamage = (CurrentWeapon == EBRWeaponType::Shotgun ? WeaponDamage : WeaponDamage) * Falloff * (bHeadshot ? 1.65f : 1.f);
                    Bot->ReceiveDamage(PelletDamage);
                }
            }
        }
        if (CurrentWeapon != EBRWeaponType::Shotgun) break;
    }
}
void ABRPlayerCharacter::SwitchWeaponNext()
{
    const int32 OldIndex = static_cast<int32>(CurrentWeapon);
    if (WeaponMagazines.IsValidIndex(OldIndex)) { WeaponMagazines[OldIndex]=AmmoInMagazine; WeaponReserves[OldIndex]=ReserveAmmo; }
    CurrentWeapon = static_cast<EBRWeaponType>((static_cast<uint8>(CurrentWeapon) + 1) % 4);
    ApplyWeaponStats();
}
void ABRPlayerCharacter::SwitchWeaponPrevious()
{
    const int32 OldIndex = static_cast<int32>(CurrentWeapon);
    if (WeaponMagazines.IsValidIndex(OldIndex)) { WeaponMagazines[OldIndex]=AmmoInMagazine; WeaponReserves[OldIndex]=ReserveAmmo; }
    CurrentWeapon = static_cast<EBRWeaponType>((static_cast<uint8>(CurrentWeapon) + 3) % 4);
    ApplyWeaponStats();
}
void ABRPlayerCharacter::ApplyWeaponStats()
{
    switch (CurrentWeapon)
    {
        case EBRWeaponType::AssaultRifle: WeaponDamage=34.f; FireCooldown=0.18f; MagazineSize=30; ReloadSeconds=1.4f; WeaponRange=12000.f; break;
        case EBRWeaponType::SMG: WeaponDamage=22.f; FireCooldown=0.095f; MagazineSize=36; ReloadSeconds=1.25f; WeaponRange=8500.f; break;
        case EBRWeaponType::Shotgun: WeaponDamage=13.f; FireCooldown=0.75f; MagazineSize=6; ReloadSeconds=1.8f; WeaponRange=2600.f; break;
        case EBRWeaponType::Sniper: WeaponDamage=85.f; FireCooldown=1.1f; MagazineSize=5; ReloadSeconds=2.1f; WeaponRange=20000.f; break;
        default: break;
    }
    const int32 WeaponIndex = static_cast<int32>(CurrentWeapon);
    if (WeaponMagazines.IsValidIndex(WeaponIndex))
    {
        AmmoInMagazine = FMath::Clamp(WeaponMagazines[WeaponIndex], 0, MagazineSize);
        ReserveAmmo = FMath::Max(0, WeaponReserves[WeaponIndex]);
    }
    else AmmoInMagazine = FMath::Min(AmmoInMagazine, MagazineSize);
    if (WeaponVisual)
    {
        const FVector Scale = CurrentWeapon == EBRWeaponType::Shotgun ? FVector(.36f,.09f,.09f) : CurrentWeapon == EBRWeaponType::Sniper ? FVector(.68f,.055f,.055f) : FVector(.42f,.07f,.08f);
        WeaponVisual->SetRelativeScale3D(Scale);
    }
}
void ABRPlayerCharacter::ReloadWeapon()
{
    if (bReloading || AmmoInMagazine >= MagazineSize || ReserveAmmo <= 0 || Health <= 0.f) return;
    bReloading = true; GetWorldTimerManager().SetTimer(ReloadTimer, this, &ABRPlayerCharacter::FinishReload, ReloadSeconds, false);
}
void ABRPlayerCharacter::FinishReload()
{
    const int32 Needed = MagazineSize - AmmoInMagazine;
    const int32 Loaded = FMath::Min(Needed, ReserveAmmo);
    AmmoInMagazine += Loaded; ReserveAmmo -= Loaded; bReloading = false;
    const int32 WeaponIndex = static_cast<int32>(CurrentWeapon);
    if (WeaponMagazines.IsValidIndex(WeaponIndex)) { WeaponMagazines[WeaponIndex]=AmmoInMagazine; WeaponReserves[WeaponIndex]=ReserveAmmo; }
}
void ABRPlayerCharacter::StartSprint()
{
    if (Health <= 0.f) return;
    bIsSprinting = true; GetCharacterMovement()->MaxWalkSpeed = SprintSpeed;
}
void ABRPlayerCharacter::StopSprint()
{
    bIsSprinting = false; GetCharacterMovement()->MaxWalkSpeed = bIsAiming ? NormalSpeed * 0.72f : NormalSpeed;
}
void ABRPlayerCharacter::ToggleCrouch()
{
    if (Health <= 0.f) return;
    if (bIsCrouched) UnCrouch(); else Crouch();
}
void ABRPlayerCharacter::AimPressed()
{
    if (Health <= 0.f) return;
    bIsAiming = true;
    if (CameraArm) CameraArm->TargetArmLength = AimCameraArmLength;
    if (!bIsSprinting) GetCharacterMovement()->MaxWalkSpeed = NormalSpeed * 0.72f;
}
void ABRPlayerCharacter::AimReleased()
{
    bIsAiming = false;
    if (CameraArm) CameraArm->TargetArmLength = DefaultCameraArmLength;
    GetCharacterMovement()->MaxWalkSpeed = bIsSprinting ? SprintSpeed : NormalSpeed;
}
void ABRPlayerCharacter::UseMedkit()
{
    if (Health <= 0.f || Medkits <= 0 || Health >= MaxHealth) return;
    --Medkits; Health = FMath::Clamp(Health + MedkitHealAmount, 0.f, MaxHealth); OnHealthChanged(Health, MaxHealth);
}
void ABRPlayerCharacter::AddReserveAmmo(int32 Amount)
{
    if (Amount > 0) { ReserveAmmo = FMath::Clamp(ReserveAmmo + Amount, 0, 300); TotalAmmoPickedUp += Amount; const int32 I=static_cast<int32>(CurrentWeapon); if(WeaponReserves.IsValidIndex(I)) WeaponReserves[I]=ReserveAmmo; }
}
void ABRPlayerCharacter::AddArmor(float Amount)
{
    if (Amount > 0.f) Armor = FMath::Clamp(Armor + Amount, 0.f, MaxArmor);
}


bool ABRPlayerCharacter::ActivateSelectedAbility()
{
    if (Health <= 0.f || !GetWorld()) return false;
    UBRMetaProgressionSubsystem* Meta = GetGameInstance() ? GetGameInstance()->GetSubsystem<UBRMetaProgressionSubsystem>() : nullptr;
    if (!Meta) return false;
    const FName SelectedId = Meta->GetSelectedCharacter();
    const TArray<FBRCharacterDefinition> CharacterDefs = Meta->GetCharacterCatalog();
    const FBRCharacterDefinition* Definition = CharacterDefs.FindByPredicate([SelectedId](const FBRCharacterDefinition& D){ return D.Id == SelectedId; });
    if (!Definition || Definition->Ability == EBRCharacterAbility::None) return false;
    const float Now = GetWorld()->GetTimeSeconds();
    if (Now - LastAbilityTime < Definition->CooldownSeconds) return false;
    bool bActivated = true;
    switch (Definition->Ability)
    {
        case EBRCharacterAbility::SprintBoost:
            GetCharacterMovement()->MaxWalkSpeed = SprintSpeed * (1.f + FMath::Clamp(Definition->AbilityValue, 0.f, 0.5f));
            GetWorldTimerManager().ClearTimer(AbilitySpeedTimer);
            GetWorldTimerManager().SetTimer(AbilitySpeedTimer, this, &ABRPlayerCharacter::RestoreAbilitySpeed, 3.0f, false);
            break;
        case EBRCharacterAbility::HealingAura:
            Health = FMath::Clamp(Health + Definition->AbilityValue, 0.f, MaxHealth); OnHealthChanged(Health, MaxHealth); break;
        case EBRCharacterAbility::ArmorBoost:
            AddArmor(Definition->AbilityValue); break;
        case EBRCharacterAbility::ScanPulse:
        {
            DrawDebugSphere(GetWorld(), GetActorLocation(), FMath::Max(Definition->AbilityValue, 500.f), 32, FColor::Yellow, false, 2.5f, 0, 4.f);
            TArray<AActor*> Bots; UGameplayStatics::GetAllActorsOfClass(this, ABRBotCharacter::StaticClass(), Bots);
            for (AActor* A : Bots) if (ABRBotCharacter* B = Cast<ABRBotCharacter>(A)) if (B->TeamId != TeamId && FVector::DistSquared(B->GetActorLocation(), GetActorLocation()) <= FMath::Square(Definition->AbilityValue)) B->Tags.AddUnique(FName("Scanned"));
            break;
        }
        default: bActivated = false; break;
    }
    if (bActivated) LastAbilityTime = Now;
    return bActivated;
}

void ABRPlayerCharacter::TriggerPetPassive()
{
    MedkitHealAmount = 45.f; ArmorDamageReduction = 0.55f;
    if (WeaponReserves.IsValidIndex(static_cast<int32>(CurrentWeapon))) { ReserveAmmo = WeaponReserves[static_cast<int32>(CurrentWeapon)]; }
    UBRMetaProgressionSubsystem* Meta = GetGameInstance() ? GetGameInstance()->GetSubsystem<UBRMetaProgressionSubsystem>() : nullptr;
    if (!Meta) return;
    const FName PetId = Meta->GetSelectedPet();
    const TArray<FBRPetDefinition> PetDefs = Meta->GetPetCatalog();
    const FBRPetDefinition* Pet = PetDefs.FindByPredicate([PetId](const FBRPetDefinition& D){ return D.Id == PetId; });
    if (!Pet) return;
    switch (Pet->Ability)
    {
        case EBRPetAbility::MedkitBonus: MedkitHealAmount = FMath::Clamp(45.f + Pet->AbilityValue, 45.f, 70.f); break;
        case EBRPetAbility::AmmoFinder: ReserveAmmo = FMath::Clamp(ReserveAmmo + FMath::RoundToInt(120.f * Pet->AbilityValue), 0, 300); TotalAmmoPickedUp = ReserveAmmo; break;
        case EBRPetAbility::CooldownBoost: ArmorDamageReduction = FMath::Clamp(ArmorDamageReduction + Pet->AbilityValue, 0.f, 0.7f); break;
        case EBRPetAbility::ZoneWarning: Tags.AddUnique(FName("PetZoneWarningEnabled")); break;
        default: break;
    }
    const int32 CurrentIndex = static_cast<int32>(CurrentWeapon);
    if (WeaponReserves.IsValidIndex(CurrentIndex)) WeaponReserves[CurrentIndex] = ReserveAmmo;
}

void ABRPlayerCharacter::RestoreAbilitySpeed()
{ if (GetCharacterMovement()) GetCharacterMovement()->MaxWalkSpeed = bIsSprinting ? SprintSpeed : (bIsAiming ? NormalSpeed * 0.72f : NormalSpeed); }

void ABRPlayerCharacter::ActivateAbilityInput()
{ ActivateSelectedAbility(); }
