#pragma once
#include "CoreMinimal.h"
#include "GameFramework/Actor.h"
#include "BRLootPickup.generated.h"

UENUM(BlueprintType)
enum class EBRLootType : uint8 { Ammo, Medkit, Armor, WeaponUpgrade };

UCLASS()
class SURVIVAL_FORCE_API ABRLootPickup : public AActor
{
    GENERATED_BODY()
public:
    ABRLootPickup();
    UPROPERTY(EditAnywhere, BlueprintReadWrite, Category="Loot") EBRLootType LootType = EBRLootType::Ammo;
    UPROPERTY(EditAnywhere, BlueprintReadWrite, Category="Loot") int32 Amount = 30;
protected:
    virtual void BeginPlay() override;
private:
    UPROPERTY() class USphereComponent* Trigger = nullptr;
    UPROPERTY() class UStaticMeshComponent* Visual = nullptr;
    UFUNCTION() void OnOverlap(UPrimitiveComponent* Overlapped, AActor* OtherActor, UPrimitiveComponent* OtherComp, int32 BodyIndex, bool bFromSweep, const FHitResult& Sweep);
};
