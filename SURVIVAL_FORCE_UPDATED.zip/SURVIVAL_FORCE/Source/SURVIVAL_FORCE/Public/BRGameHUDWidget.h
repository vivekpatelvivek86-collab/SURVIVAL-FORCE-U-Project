#pragma once
#include "CoreMinimal.h"
#include "Blueprint/UserWidget.h"
#include "BRGameHUDWidget.generated.h"

class UTextBlock;
class UProgressBar;

/** Native placeholder HUD. All elements are created in C++ so the project has a real HUD foundation. */
UCLASS()
class SURVIVAL_FORCE_API UBRGameHUDWidget : public UUserWidget
{
    GENERATED_BODY()
protected:
    virtual void NativeConstruct() override;
    virtual void NativeTick(const FGeometry& MyGeometry, float InDeltaTime) override;
private:
    UPROPERTY() UTextBlock* HealthText = nullptr;
    UPROPERTY() UProgressBar* HealthBar = nullptr;
    UPROPERTY() UTextBlock* AmmoText = nullptr;
    UPROPERTY() UTextBlock* StatusText = nullptr;
    UPROPERTY() UTextBlock* AimText = nullptr;
};
