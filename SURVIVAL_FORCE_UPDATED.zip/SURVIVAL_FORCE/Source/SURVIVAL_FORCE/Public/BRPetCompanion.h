#pragma once
#include "CoreMinimal.h"
#include "GameFramework/Actor.h"
#include "BRPetCompanion.generated.h"

UCLASS()
class SURVIVAL_FORCE_API ABRPetCompanion : public AActor
{
    GENERATED_BODY()
public:
    ABRPetCompanion();
    virtual void Tick(float DeltaSeconds) override;
    UPROPERTY(EditAnywhere, BlueprintReadWrite, Category="Pet") float FollowDistance = 125.f;
    UPROPERTY(EditAnywhere, BlueprintReadWrite, Category="Pet") float FollowHeight = 35.f;
    UPROPERTY() TWeakObjectPtr<class ABRPlayerCharacter> FollowTarget;
protected:
    virtual void BeginPlay() override;
private:
    UPROPERTY() class UStaticMeshComponent* PetVisual = nullptr;
};
