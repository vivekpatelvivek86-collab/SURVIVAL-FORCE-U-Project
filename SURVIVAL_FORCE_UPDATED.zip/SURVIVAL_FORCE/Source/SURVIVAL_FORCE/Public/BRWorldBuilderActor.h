#pragma once
#include "CoreMinimal.h"
#include "GameFramework/Actor.h"
#include "BRWorldBuilderActor.generated.h"

/** Lightweight runtime-generated island blockout; replace meshes with original/licensed art for production. */
UCLASS()
class SURVIVAL_FORCE_API ABRWorldBuilderActor : public AActor
{
    GENERATED_BODY()
public:
    ABRWorldBuilderActor();
    virtual void BeginPlay() override;
    UPROPERTY(EditAnywhere, BlueprintReadWrite, Category="World") bool bGenerateAtBeginPlay = true;
    UPROPERTY(EditAnywhere, BlueprintReadWrite, Category="World") int32 LandmarkCount = 12;
private:
    UPROPERTY() class UStaticMesh* CubeMesh = nullptr;
    UPROPERTY() class UInstancedStaticMeshComponent* BlockInstances = nullptr;
    UPROPERTY() class UInstancedStaticMeshComponent* CanopyInstances = nullptr;
    UPROPERTY() class UInstancedStaticMeshComponent* GroundInstances = nullptr;
    UPROPERTY() class UInstancedStaticMeshComponent* WaterInstances = nullptr;
    UPROPERTY() class UInstancedStaticMeshComponent* RoadInstances = nullptr;
    UPROPERTY() class UStaticMesh* CanopyMesh = nullptr;
    void AddCanopy(const FVector& Location, const FVector& Scale);
    void AddBlock(const FVector& Location, const FVector& Scale, const FRotator& Rotation = FRotator::ZeroRotator);
    void AddGround(const FVector& Location, const FVector& Scale, const FRotator& Rotation = FRotator::ZeroRotator);
    void AddWater(const FVector& Location, const FVector& Scale, const FRotator& Rotation = FRotator::ZeroRotator);
    void AddRoad(const FVector& Location, const FVector& Scale, const FRotator& Rotation = FRotator::ZeroRotator);
};
