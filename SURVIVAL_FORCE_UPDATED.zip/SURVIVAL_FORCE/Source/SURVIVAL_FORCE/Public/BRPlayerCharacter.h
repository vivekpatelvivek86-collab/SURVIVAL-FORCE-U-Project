#pragma once
#include "CoreMinimal.h"
#include "GameFramework/Character.h"
#include "BRPlayerCharacter.generated.h"

UENUM(BlueprintType)
enum class EBRWeaponType : uint8 { AssaultRifle, SMG, Shotgun, Sniper };

UCLASS()
class SURVIVAL_FORCE_API ABRPlayerCharacter : public ACharacter
{
    GENERATED_BODY()
public:
    ABRPlayerCharacter();
    virtual void SetupPlayerInputComponent(UInputComponent* PlayerInputComponent) override;
    virtual void Tick(float DeltaSeconds) override;
    UFUNCTION(BlueprintCallable) void ReceiveDamage(float Amount);
    UFUNCTION(BlueprintCallable) void FireWeapon();
    UPROPERTY(EditAnywhere, BlueprintReadWrite, Category="Combat") float MaxHealth = 100.f;
    UPROPERTY(EditAnywhere, BlueprintReadWrite, Category="Team") int32 TeamId = 1;
    UPROPERTY(VisibleAnywhere, BlueprintReadOnly, Category="Combat") float Health = 100.f;
    UPROPERTY(EditAnywhere, BlueprintReadWrite, Category="Combat") float WeaponDamage = 34.f;
    UPROPERTY(EditAnywhere, BlueprintReadWrite, Category="Combat", meta=(ClampMin="0", ClampMax="100")) float Armor = 0.f;
    UPROPERTY(EditAnywhere, BlueprintReadWrite, Category="Combat", meta=(ClampMin="0", ClampMax="100")) float MaxArmor = 100.f;
    UPROPERTY(EditAnywhere, BlueprintReadWrite, Category="Combat") float ArmorDamageReduction = 0.55f;
    UPROPERTY(EditAnywhere, BlueprintReadWrite, Category="Combat") float WeaponRange = 12000.f;
    UPROPERTY(EditAnywhere, BlueprintReadWrite, Category="Combat") float FireCooldown = 0.18f;
    UPROPERTY(VisibleAnywhere, BlueprintReadOnly, Category="Combat") int32 AmmoInMagazine = 30;
    UPROPERTY(EditAnywhere, BlueprintReadWrite, Category="Combat") int32 MagazineSize = 30;
    UPROPERTY(EditAnywhere, BlueprintReadWrite, Category="Combat") float ReloadSeconds = 1.4f;
    UFUNCTION(BlueprintCallable) void ReloadWeapon();
    UFUNCTION(BlueprintCallable, Category="Combat") void SwitchWeaponNext();
    UFUNCTION(BlueprintCallable, Category="Combat") void SwitchWeaponPrevious();
    UPROPERTY(VisibleAnywhere, BlueprintReadOnly, Category="Combat") EBRWeaponType CurrentWeapon = EBRWeaponType::AssaultRifle;
    UFUNCTION(BlueprintCallable, Category="Mobile Controls") void StartSprint();
    UFUNCTION(BlueprintCallable, Category="Mobile Controls") void StopSprint();
    UFUNCTION(BlueprintCallable, Category="Mobile Controls") void ToggleCrouch();
    UFUNCTION(BlueprintCallable, Category="Mobile Controls") void AimPressed();
    UFUNCTION(BlueprintCallable, Category="Mobile Controls") void AimReleased();
    UFUNCTION(BlueprintCallable, Category="Items") void UseMedkit();
    UFUNCTION(BlueprintCallable, Category="Combat") void AddReserveAmmo(int32 Amount);
    UFUNCTION(BlueprintCallable, Category="Items") void AddArmor(float Amount);
    UFUNCTION(BlueprintCallable, Category="Abilities") bool ActivateSelectedAbility();
    UFUNCTION(BlueprintCallable, Category="Abilities") void TriggerPetPassive();
    UFUNCTION(BlueprintCallable, Category="Combat") bool IsReloading() const { return bReloading; }
    UPROPERTY(VisibleAnywhere, BlueprintReadOnly, Category="Combat") int32 ReserveAmmo = 120;
    UPROPERTY(VisibleAnywhere, BlueprintReadOnly, Category="Combat") int32 TotalAmmoPickedUp = 120;
    UPROPERTY(EditAnywhere, BlueprintReadWrite, Category="Items") int32 Medkits = 2;
    UPROPERTY(EditAnywhere, BlueprintReadWrite, Category="Items") float MedkitHealAmount = 45.f;
    UPROPERTY(EditAnywhere, BlueprintReadWrite, Category="Movement") float SprintSpeed = 760.f;
    UPROPERTY(EditAnywhere, BlueprintReadWrite, Category="Movement") float NormalSpeed = 540.f;
    UPROPERTY(EditAnywhere, BlueprintReadWrite, Category="Combat") float AimCameraArmLength = 190.f;
    UFUNCTION(BlueprintImplementableEvent, Category="Combat") void OnHealthChanged(float NewHealth, float InMaxHealth);
    UFUNCTION(BlueprintImplementableEvent, Category="Combat") void OnEliminated();
protected:
    virtual void BeginPlay() override;
private:
    void MoveForward(float Value);
    void MoveRight(float Value);
    void Turn(float Value);
    void LookUp(float Value);
    void StartJump();
    float LastFireTime = -100.f;
    TArray<int32> WeaponMagazines;
    TArray<int32> WeaponReserves;
    float LastAbilityTime = -10000.f;
    float DefaultCameraArmLength = 320.f;
    class USpringArmComponent* CameraArm = nullptr;
    bool bIsAiming = false;
    bool bIsSprinting = false;
    bool bReloading = false;
    FTimerHandle ReloadTimer;
    void FinishReload();
    void RestoreAbilitySpeed();
    void ActivateAbilityInput();
    FTimerHandle AbilitySpeedTimer;
    void ApplyWeaponStats();
    UPROPERTY() class UStaticMeshComponent* BodyVisual = nullptr;
    UPROPERTY() class UStaticMeshComponent* WeaponVisual = nullptr;
};
