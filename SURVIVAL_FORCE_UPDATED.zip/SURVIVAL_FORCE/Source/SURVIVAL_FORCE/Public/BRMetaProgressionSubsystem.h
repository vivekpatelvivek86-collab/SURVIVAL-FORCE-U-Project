#pragma once
#include "CoreMinimal.h"
#include "Subsystems/GameInstanceSubsystem.h"
#include "BRMetaProgressionSubsystem.generated.h"

UENUM(BlueprintType)
enum class EBRGameMode : uint8 { BRClassic, BRRanked, ClashSquad, ClashSquadRanked, RushHour, Training, LoneWolf };
UENUM(BlueprintType)
enum class EBRStoreCategory : uint8 { Character, Pet, Outfit, WeaponSkin, Emote, LootCrate, Voucher, RoyaleToken };

// 2019-era mode and map metadata. These IDs are native gameplay configuration,
// not a claim that full production maps or every mode's gameplay is finished.
UENUM(BlueprintType)
enum class EBRMapId : uint8 { Bermuda, Purgatory };
UENUM(BlueprintType)
enum class EBRPartySize : uint8 { Solo, Duo, Squad };
UENUM(BlueprintType)
enum class EBRLuckRoyaleType : uint8 { GoldRoyale, DiamondRoyale, WeaponRoyale, Incubator, LegacyReturns };


UENUM(BlueprintType)
enum class EBRCharacterAbility : uint8 { None, SprintBoost, HealingAura, ArmorBoost, ScanPulse };
UENUM(BlueprintType)
enum class EBRPetAbility : uint8 { None, AmmoFinder, MedkitBonus, ZoneWarning, CooldownBoost };

USTRUCT(BlueprintType)
struct FBRCharacterDefinition
{
    GENERATED_BODY()
    UPROPERTY(EditAnywhere, BlueprintReadOnly) FName Id;
    UPROPERTY(EditAnywhere, BlueprintReadOnly) FText DisplayName;
    UPROPERTY(EditAnywhere, BlueprintReadOnly) EBRCharacterAbility Ability = EBRCharacterAbility::None;
    UPROPERTY(EditAnywhere, BlueprintReadOnly) float AbilityValue = 0.f;
    UPROPERTY(EditAnywhere, BlueprintReadOnly) float CooldownSeconds = 30.f;
};
USTRUCT(BlueprintType)
struct FBRPetDefinition
{
    GENERATED_BODY()
    UPROPERTY(EditAnywhere, BlueprintReadOnly) FName Id;
    UPROPERTY(EditAnywhere, BlueprintReadOnly) FText DisplayName;
    UPROPERTY(EditAnywhere, BlueprintReadOnly) EBRPetAbility Ability = EBRPetAbility::None;
    UPROPERTY(EditAnywhere, BlueprintReadOnly) float AbilityValue = 0.f;
};
USTRUCT(BlueprintType)
struct FBRRoyaleResult
{
    GENERATED_BODY()
    UPROPERTY(BlueprintReadOnly) FName RewardId;
    UPROPERTY(BlueprintReadOnly) FText RewardName;
    UPROPERTY(BlueprintReadOnly) bool bDuplicate = false;
    UPROPERTY(BlueprintReadOnly) int32 CompensationCoins = 0;
};

USTRUCT(BlueprintType)
struct FBRModeDefinition
{
    GENERATED_BODY()
    UPROPERTY(EditAnywhere, BlueprintReadOnly) EBRGameMode Mode = EBRGameMode::BRClassic;
    UPROPERTY(EditAnywhere, BlueprintReadOnly) FText DisplayName;
    UPROPERTY(EditAnywhere, BlueprintReadOnly) bool bRanked = false;
    UPROPERTY(EditAnywhere, BlueprintReadOnly) int32 TargetPlayers = 50;
    UPROPERTY(EditAnywhere, BlueprintReadOnly) int32 TeamSize = 1;
    UPROPERTY(EditAnywhere, BlueprintReadOnly) bool bUsesSafeZone = true;
};

USTRUCT(BlueprintType)
struct FBRLuckRoyaleOffer
{
    GENERATED_BODY()
    UPROPERTY(EditAnywhere, BlueprintReadOnly) EBRLuckRoyaleType Type = EBRLuckRoyaleType::GoldRoyale;
    UPROPERTY(EditAnywhere, BlueprintReadOnly) FText DisplayName;
    UPROPERTY(EditAnywhere, BlueprintReadOnly) int32 GoldCost = 0;
    UPROPERTY(EditAnywhere, BlueprintReadOnly) int32 DiamondCost = 0;
};

USTRUCT(BlueprintType)
struct FBRStoreItem
{
    GENERATED_BODY()
    UPROPERTY(EditAnywhere, BlueprintReadOnly) FName Id;
    UPROPERTY(EditAnywhere, BlueprintReadOnly) FText DisplayName;
    UPROPERTY(EditAnywhere, BlueprintReadOnly) EBRStoreCategory Category = EBRStoreCategory::Outfit;
    UPROPERTY(EditAnywhere, BlueprintReadOnly) int32 CoinPrice = 0;
    UPROPERTY(EditAnywhere, BlueprintReadOnly) int32 DiamondPrice = 0;
    UPROPERTY(EditAnywhere, BlueprintReadOnly) bool bDefaultOwned = false;
};

USTRUCT(BlueprintType)
struct FBRPlayerProfile
{
    GENERATED_BODY()
    UPROPERTY(BlueprintReadOnly) FString Nickname = TEXT("Player");
    UPROPERTY(BlueprintReadOnly) int32 Level = 1;
    UPROPERTY(BlueprintReadOnly) int32 Experience = 0;
    UPROPERTY(BlueprintReadOnly) int32 Coins = 5000;
    UPROPERTY(BlueprintReadOnly) int32 Diamonds = 0;
    UPROPERTY(BlueprintReadOnly) int32 BRWins = 0;
    UPROPERTY(BlueprintReadOnly) int32 BRMatches = 0;
    UPROPERTY(BlueprintReadOnly) int32 CSWins = 0;
    UPROPERTY(BlueprintReadOnly) int32 CSMatches = 0;
};

USTRUCT(BlueprintType)
struct FBRGameSettings
{
    GENERATED_BODY()
    UPROPERTY(EditAnywhere, BlueprintReadWrite) float MasterVolume = 0.8f;
    UPROPERTY(EditAnywhere, BlueprintReadWrite) float MusicVolume = 0.5f;
    UPROPERTY(EditAnywhere, BlueprintReadWrite) float SFXVolume = 0.8f;
    UPROPERTY(EditAnywhere, BlueprintReadWrite) float LookSensitivity = 1.0f;
    UPROPERTY(EditAnywhere, BlueprintReadWrite) float AimSensitivity = 0.8f;
    UPROPERTY(EditAnywhere, BlueprintReadWrite) bool bAimAssist = true;
    UPROPERTY(EditAnywhere, BlueprintReadWrite) bool bAutoPickup = true;
    UPROPERTY(EditAnywhere, BlueprintReadWrite) bool bLeftFireButton = false;
    UPROPERTY(EditAnywhere, BlueprintReadWrite) bool bVibration = true;
    UPROPERTY(EditAnywhere, BlueprintReadWrite) bool bDamageNumbers = true;
    UPROPERTY(EditAnywhere, BlueprintReadWrite) bool bHitMarkers = true;
    UPROPERTY(EditAnywhere, BlueprintReadWrite) bool bAutoParachute = true;
    UPROPERTY(EditAnywhere, BlueprintReadWrite) bool bQuickWeaponSwitch = true;
    UPROPERTY(EditAnywhere, BlueprintReadWrite) bool bLowPowerMode = false;
    UPROPERTY(EditAnywhere, BlueprintReadWrite) int32 FPSLimit = 60;
    UPROPERTY(EditAnywhere, BlueprintReadWrite) int32 GraphicsQuality = 1;
    UPROPERTY(EditAnywhere, BlueprintReadWrite) int32 ShadowQuality = 1;
    UPROPERTY(EditAnywhere, BlueprintReadWrite) int32 TextureQuality = 1;
    UPROPERTY(EditAnywhere, BlueprintReadWrite) int32 MinimapSize = 1;
    UPROPERTY(EditAnywhere, BlueprintReadWrite) int32 HUDScale = 100;
};

UCLASS()
class SURVIVAL_FORCE_API UBRMetaSaveGame : public USaveGame
{
    GENERATED_BODY()
public:
    UPROPERTY() FBRPlayerProfile Profile;
    UPROPERTY() FBRGameSettings Settings;
    UPROPERTY() TArray<FName> OwnedItems;
    UPROPERTY() TArray<FName> EquippedItems;
    UPROPERTY() EBRGameMode SelectedMode = EBRGameMode::BRClassic;
    UPROPERTY() EBRMapId SelectedMap = EBRMapId::Bermuda;
    UPROPERTY() FName SelectedCharacter = TEXT("char_recruit");
    UPROPERTY() FName SelectedPet = NAME_None;
    UPROPERTY() TMap<uint8, int32> RoyaleSpinCounts;
};

UCLASS(BlueprintType)
class SURVIVAL_FORCE_API UBRMetaProgressionSubsystem : public UGameInstanceSubsystem
{
    GENERATED_BODY()
public:
    virtual void Initialize(FSubsystemCollectionBase& Collection) override;
    UFUNCTION(BlueprintCallable, Category="FF2019|Profile") FBRPlayerProfile GetProfile() const { return Profile; }
    UFUNCTION(BlueprintCallable, Category="FF2019|Characters") TArray<FBRCharacterDefinition> GetCharacterCatalog() const;
    UFUNCTION(BlueprintCallable, Category="FF2019|Pets") TArray<FBRPetDefinition> GetPetCatalog() const;
    UFUNCTION(BlueprintCallable, Category="FF2019|Characters") bool SelectCharacter(FName CharacterId);
    UFUNCTION(BlueprintCallable, Category="FF2019|Pets") bool SelectPet(FName PetId);
    UFUNCTION(BlueprintCallable, Category="FF2019|Characters") FName GetSelectedCharacter() const { return SelectedCharacter; }
    UFUNCTION(BlueprintCallable, Category="FF2019|Pets") FName GetSelectedPet() const { return SelectedPet; }
    UFUNCTION(BlueprintCallable, Category="FF2019|Royale") FBRRoyaleResult SpinLuckRoyale(EBRLuckRoyaleType Type, bool bUseDiamonds);
    UFUNCTION(BlueprintCallable, Category="FF2019|Royale") int32 GetRoyaleSpinCount(EBRLuckRoyaleType Type) const;
    UFUNCTION(BlueprintCallable, Category="FF2019|Inventory") TArray<FName> GetOwnedItems() const { return OwnedItems; }
    UFUNCTION(BlueprintCallable, Category="FF2019|Inventory") TArray<FName> GetEquippedItems() const { return EquippedItems; }

    UFUNCTION(BlueprintCallable, Category="FF2019|Profile") bool SetNickname(const FString& NewName);
    UFUNCTION(BlueprintCallable, Category="FF2019|Profile") void AddExperience(int32 Amount);
    UFUNCTION(BlueprintCallable, Category="FF2019|Modes") TArray<EBRGameMode> GetAvailableModes() const;
    UFUNCTION(BlueprintCallable, Category="FF2019|Modes") TArray<FBRModeDefinition> GetModeDefinitions() const;
    UFUNCTION(BlueprintCallable, Category="FF2019|Maps") TArray<EBRMapId> GetAvailableMaps() const;
    UFUNCTION(BlueprintCallable, Category="FF2019|Maps") void SelectMap(EBRMapId Map);
    UFUNCTION(BlueprintCallable, Category="FF2019|Maps") EBRMapId GetSelectedMap() const { return SelectedMap; }
    UFUNCTION(BlueprintCallable, Category="FF2019|LuckRoyale") TArray<FBRLuckRoyaleOffer> GetLuckRoyaleOffers() const;
    UFUNCTION(BlueprintCallable, Category="FF2019|Modes") void SelectMode(EBRGameMode Mode);
    UFUNCTION(BlueprintCallable, Category="FF2019|Modes") EBRGameMode GetSelectedMode() const { return SelectedMode; }
    UFUNCTION(BlueprintCallable, Category="FF2019|Store") TArray<FBRStoreItem> GetStoreCatalog() const { return StoreCatalog; }
    UFUNCTION(BlueprintCallable, Category="FF2019|Store") bool PurchaseItem(FName ItemId, bool bUseDiamonds);
    UFUNCTION(BlueprintCallable, Category="FF2019|Store") bool EquipItem(FName ItemId);
    UFUNCTION(BlueprintCallable, Category="FF2019|Store") bool OwnsItem(FName ItemId) const { return OwnedItems.Contains(ItemId); }
    UFUNCTION(BlueprintCallable, Category="FF2019|Settings") FBRGameSettings GetSettings() const { return Settings; }
    UFUNCTION(BlueprintCallable, Category="FF2019|Settings") void SetSettings(const FBRGameSettings& NewSettings);
    UFUNCTION(BlueprintCallable, Category="FF2019|Profile") void RecordMatchResult(bool bClashSquad, bool bWon);
    UFUNCTION(BlueprintCallable, Category="FF2019|Save") void SaveProgress();
    UFUNCTION(BlueprintCallable, Category="FF2019|Save") void LoadProgress();
private:
    void BuildCatalog();
    void BuildLuckRoyaleOffers();
    const FBRStoreItem* FindItem(FName ItemId) const;
    UPROPERTY() FBRPlayerProfile Profile;
    UPROPERTY() FBRGameSettings Settings;
    UPROPERTY() TArray<FBRStoreItem> StoreCatalog;
    UPROPERTY() TArray<FBRLuckRoyaleOffer> LuckRoyaleOffers;
    UPROPERTY() TArray<FName> OwnedItems;
    UPROPERTY() TArray<FName> EquippedItems;
    UPROPERTY() EBRGameMode SelectedMode = EBRGameMode::BRClassic;
    UPROPERTY() EBRMapId SelectedMap = EBRMapId::Bermuda;
    UPROPERTY() FName SelectedCharacter = TEXT("char_recruit");
    UPROPERTY() FName SelectedPet = NAME_None;
    UPROPERTY() TMap<uint8, int32> RoyaleSpinCounts;
    TArray<FBRCharacterDefinition> CharacterCatalog;
    TArray<FBRPetDefinition> PetCatalog;
};
