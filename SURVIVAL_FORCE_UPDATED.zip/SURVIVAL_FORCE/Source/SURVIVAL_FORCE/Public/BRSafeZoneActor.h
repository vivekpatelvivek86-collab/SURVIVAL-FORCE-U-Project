#pragma once
#include "CoreMinimal.h"
#include "GameFramework/Actor.h"
#include "BRSafeZoneActor.generated.h"
UCLASS()
class SURVIVAL_FORCE_API ABRSafeZoneActor : public AActor
{
    GENERATED_BODY()
public:
    ABRSafeZoneActor();
    virtual void Tick(float DeltaSeconds) override;
    UPROPERTY(EditAnywhere, BlueprintReadWrite, Category="Safe Zone") float Radius = 12000.f;
    UPROPERTY(EditAnywhere, BlueprintReadWrite, Category="Safe Zone") float MinimumRadius = 1500.f;
    UPROPERTY(EditAnywhere, BlueprintReadWrite, Category="Safe Zone") float ShrinkPerSecond = 12.f;
    UPROPERTY(EditAnywhere, BlueprintReadWrite, Category="Safe Zone") float DamagePerSecond = 4.f;
    UPROPERTY(EditAnywhere, BlueprintReadWrite, Category="Safe Zone") float DamageInterval = 1.f;
protected:
    virtual void BeginPlay() override;
private:
    float DamageClock = 0.f;
};
