#pragma once
#include "CoreMinimal.h"
#include "GameFramework/Character.h"
#include "BRBotCharacter.generated.h"
UCLASS()
class SURVIVAL_FORCE_API ABRBotCharacter : public ACharacter
{
    GENERATED_BODY()
public:
    ABRBotCharacter();
    virtual void Tick(float DeltaSeconds) override;
    UFUNCTION(BlueprintCallable) void ReceiveDamage(float Amount);
    UPROPERTY(EditAnywhere, BlueprintReadWrite, Category="Bot") float Health = 100.f;
    UPROPERTY(EditAnywhere, BlueprintReadWrite, Category="Bot") float MoveSpeed = 260.f;
    UPROPERTY(EditAnywhere, BlueprintReadWrite, Category="Bot") float AttackRange = 1000.f;
    UPROPERTY(EditAnywhere, BlueprintReadWrite, Category="Bot", meta=(ClampMin="500", ClampMax="30000")) float AwarenessRange = 18000.f;
    UPROPERTY(EditAnywhere, BlueprintReadWrite, Category="Bot", meta=(ClampMin="0", ClampMax="1")) float CombatMoveScale = 0.35f;
    UPROPERTY(EditAnywhere, BlueprintReadWrite, Category="Bot") float AttackDamage = 5.f;
    UPROPERTY(EditAnywhere, BlueprintReadWrite, Category="Bot") float AttackInterval = 1.3f;
    UPROPERTY(EditAnywhere, BlueprintReadWrite, Category="Team") int32 TeamId = 2;
    UPROPERTY(EditAnywhere, BlueprintReadWrite, Category="Team") bool bCanAttackBots = true;
protected:
    virtual void BeginPlay() override;
private:
    float NextAttackTime = 0.f;
    float TargetRefreshClock = 0.f;
    float StrafeChangeClock = 0.f;
    float StrafeSign = 1.f;
    TWeakObjectPtr<AActor> CurrentTarget;
    void RefreshTarget();
    void DropLoot();
};
