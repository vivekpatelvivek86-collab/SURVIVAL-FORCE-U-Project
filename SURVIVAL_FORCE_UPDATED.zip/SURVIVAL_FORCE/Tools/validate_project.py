#!/usr/bin/env python3
"""Static validation for SURVIVAL FORCE; Unreal Engine compilation is still required."""
from pathlib import Path
import json, re, sys
ROOT=Path(__file__).resolve().parents[1]
checks=[]
def check(name, ok, detail=""):
    checks.append((name,bool(ok),detail))
try:
    project=json.loads((ROOT/"SURVIVAL_FORCE.uproject").read_text())
    check("uproject JSON parses", True)
    check("runtime module matches source", any(m.get("Name")=="SURVIVAL_FORCE" and m.get("Type")=="Runtime" for m in project.get("Modules",[])))
except Exception as e:
    check("uproject JSON parses",False,str(e))
try:
    spec=json.loads((ROOT/"Build/Android/BuildSpec.json").read_text())
    check("Android BuildSpec JSON parses",True)
    check("BuildSpec matches project",spec.get("uproject")=="SURVIVAL_FORCE.uproject" and spec.get("module")=="SURVIVAL_FORCE" and spec.get("packageName")=="com.vivekpatel.survivalforce" and spec.get("displayName")=="SURVIVAL FORCE")
except Exception as e: check("Android BuildSpec JSON parses",False,str(e))
check("game target exists",(ROOT/"Source/SURVIVAL_FORCE.Target.cs").is_file())
check("editor target exists",(ROOT/"Source/SURVIVAL_FORCEEditor.Target.cs").is_file())
module=ROOT/"Source/SURVIVAL_FORCE"
headers=list((module/"Public").glob("*.h")); cpps=list((module/"Private").glob("*.cpp"))
check("native headers present",len(headers)>=8,str(len(headers)))
check("native cpp files present",len(cpps)>=8,str(len(cpps)))
check("game mode header exists",(module/"Public/TargetGameMode.h").is_file())
check("game module entry point exists",(module/"Private/SURVIVAL_FORCE.cpp").is_file())
engine=(ROOT/"Config/DefaultEngine.ini").read_text()
check("Android package configured","PackageName=com.vivekpatel.survivalforce" in engine)
check("game mode path configured","/Script/SURVIVAL_FORCE.TargetGameMode" in engine)
check("project display name configured","ApplicationDisplayName=SURVIVAL FORCE" in engine)
for p in list(module.rglob("*.cpp"))+list(module.rglob("*.h")):
    content=p.read_text(errors="replace")
    names={q.name for q in module.rglob("*") if q.is_file()}
    for inc in re.findall(r'^\s*#include\s+"([^"]+)"',content,re.M):
        if inc.endswith(".generated.h"): continue
        if inc.startswith(("BR","Target")): check("include resolves: "+inc,Path(inc).name in names)
    t=re.sub(r'/\*.*?\*/|//[^\n]*',' ',content,flags=re.S)
    t=re.sub(r'"(?:\\.|[^"\\])*"','""',t)
    stack=[]; pairs={")":"(","]":"[","}":"{"}; ok=True
    for ch in t:
        if ch in "([{": stack.append(ch)
        elif ch in ")]}":
            if not stack or stack.pop()!=pairs[ch]: ok=False; break
    check("delimiter balance: "+p.name,ok and not stack)
# Verify shipped launcher and splash assets exist and are non-empty.
for rel in ["Build/Android/res/mipmap-mdpi/ic_launcher.png","Build/Android/res/mipmap-xxxhdpi/ic_launcher.png","Build/Android/res/drawable/splashscreen_landscape.png","Build/Android/res/drawable/splashscreen_portrait.png"]:
    f=ROOT/rel; check("branding asset exists: "+rel,f.is_file() and f.stat().st_size>0)
failed=[x for x in checks if not x[1]]
for name,ok,detail in checks: print(("PASS" if ok else "FAIL")+" | "+name+(" | "+detail if detail else ""))
print(f"RESULT: {len(checks)-len(failed)}/{len(checks)} checks passed")
sys.exit(1 if failed else 0)
