#!/usr/bin/env python3
"""Report whether the local environment appears ready to package SURVIVAL FORCE for Android.
This is a diagnostic only; it never claims that a build succeeded."""
from pathlib import Path
import os, shutil, sys

root = Path(__file__).resolve().parents[1]
project = root / 'SURVIVAL_FORCE.uproject'
print('SURVIVAL FORCE Android build preflight')
print(f'Project file: {project} | exists={project.is_file()}')
engine = os.environ.get('UE_ROOT') or os.environ.get('UNREAL_ENGINE_ROOT')
if engine:
    engine_path = Path(engine)
    candidates = [engine_path / 'Engine' / 'Build' / 'BatchFiles' / 'RunUAT.bat',
                  engine_path / 'Engine' / 'Build' / 'BatchFiles' / 'RunUAT.sh',
                  engine_path / 'Engine' / 'Binaries' / 'DotNET' / 'UnrealBuildTool' / 'UnrealBuildTool.dll']
    print(f'Engine root: {engine_path} | exists={engine_path.exists()}')
    print('Build tools: ' + ', '.join(f'{p.name}={p.exists()}' for p in candidates))
else:
    print('Engine root: NOT SET (set UE_ROOT or UNREAL_ENGINE_ROOT to the Unreal Engine installation)')
for key in ('ANDROID_HOME', 'ANDROID_SDK_ROOT', 'JAVA_HOME', 'NDKROOT'):
    value = os.environ.get(key)
    print(f'{key}: {value if value else "NOT SET"}')
for exe in ('java', 'adb', 'clang++'):
    print(f'{exe}: {shutil.which(exe) or "NOT FOUND on PATH"}')
print('RESULT: diagnostic only; this script does not compile, package, install, or test an APK.')
