"""Run inside Unreal Editor with the Python Editor Script Plugin enabled.
Imports source assets as real Unreal assets so they can be referenced by packaged builds.
"""
import os
import unreal

PROJECT_DIR = unreal.Paths.project_dir()
CONTENT_DIR = os.path.join(PROJECT_DIR, 'Content')

ASSETS = [
    (os.path.join(CONTENT_DIR, 'Audio', 'SURVIVAL_FORCE_Lobby_Ringtone.wav'), '/Game/Audio'),
    (os.path.join(CONTENT_DIR, 'Branding', 'SURVIVAL_FORCE_Logo.png'), '/Game/Branding'),
    (os.path.join(CONTENT_DIR, 'Branding', 'SURVIVAL_FORCE_SplashScreen.png'), '/Game/Branding'),
    (os.path.join(CONTENT_DIR, 'Branding', 'SURVIVAL_FORCE_AppIcon_512.png'), '/Game/Branding'),
]

factory = unreal.SoundFactory() if hasattr(unreal, 'SoundFactory') else None
for source, destination in ASSETS:
    if not os.path.isfile(source):
        unreal.log_warning('SURVIVAL FORCE: source asset missing: ' + source)
        continue
    task = unreal.AssetImportTask()
    task.filename = source
    task.destination_path = destination
    task.automated = True
    task.replace_existing = True
    task.save = True
    unreal.AssetToolsHelpers.get_asset_tools().import_asset_tasks([task])
    if task.imported_object_paths:
        unreal.log('SURVIVAL FORCE: imported ' + source + ' -> ' + ', '.join(task.imported_object_paths))
    else:
        unreal.log_warning('SURVIVAL FORCE: import did not return an asset for ' + source)

unreal.EditorLoadingAndSavingUtils.save_dirty_packages(True, True)
unreal.log('SURVIVAL FORCE: asset import pass finished; inspect Output Log for warnings.')
