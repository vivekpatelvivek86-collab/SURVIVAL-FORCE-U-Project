SURVIVAL FORCE — Android build/test notes
========================================

Important status
----------------
This is an offline battle-royale prototype. It does not include third-party proprietary
character models, animations, maps, UI assets, sounds, or source code.

This environment does not have Unreal Engine 5.4 / UnrealBuildTool installed, so an APK
could not be compiled or run-tested here. Static project checks are not a substitute for
an Unreal compile or device test.

Before building
---------------
1. Extract the ZIP to a writable folder (do not build from inside the ZIP).
2. Open SURVIVAL_FORCE.uproject in Unreal Engine 5.4.
3. If prompted, allow Unreal to rebuild the C++ project. If it reports a compiler error,
   save the full Output Log and fix that before packaging.
4. Enable the Python Editor Script Plugin only if you want to run Tools/import_unreal_assets.py.
   In the Unreal Editor Python console, execute that file to import WAV/PNG files as Unreal
   assets. Check the Output Log and confirm the assets appear in /Game/Audio and /Game/Branding.
5. Open the project map configured in Config/DefaultEngine.ini and verify the frontend and
   gameplay map are assigned. Press Play in the editor and test navigation, match start,
   shooting, reload, healing, bots, safe zone and map selection.
6. For Android, configure Android SDK/NDK per Unreal 5.4's requirements, set the Android
   device target, then use Platforms > Android > Package Project. BuildAndroidDevelopment
   scripts are helper scripts, not proof that the build succeeds.
7. Install the resulting APK on the phone and test launch, touch controls, screen scaling,
   audio, performance, pause/resume and a full offline match.

Offline requirements
--------------------
The intended scope remains offline-only: no login, online multiplayer, or friends system.

Validation
----------
Run: python Tools/validate_project.py
This checks project structure/configuration and source delimiters only. It does not compile
C++, validate Unreal assets, or prove that the APK launches.
